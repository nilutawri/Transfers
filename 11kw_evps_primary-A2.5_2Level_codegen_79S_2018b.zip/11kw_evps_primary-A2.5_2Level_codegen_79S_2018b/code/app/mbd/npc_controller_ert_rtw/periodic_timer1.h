/*
 * File: periodic_timer1.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.30
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri May 26 11:55:14 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_periodic_timer1_h_
#define RTW_HEADER_periodic_timer1_h_
#ifndef npc_controller_COMMON_INCLUDES_
#define npc_controller_COMMON_INCLUDES_
#include <string.h>
#include <math.h>
#include "rtwtypes.h"
#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "IQmathLib.h"
#include "can_message.h"
#include "F2837xS_device.h"
#include "MW_c2000DAC.h"
#include "MW_c28xCMPSS.h"
#endif                                 /* npc_controller_COMMON_INCLUDES_ */

extern void npc_control_periodic_timer1(uint16_T *rtd_cnt_1ms);

#endif                                 /* RTW_HEADER_periodic_timer1_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
