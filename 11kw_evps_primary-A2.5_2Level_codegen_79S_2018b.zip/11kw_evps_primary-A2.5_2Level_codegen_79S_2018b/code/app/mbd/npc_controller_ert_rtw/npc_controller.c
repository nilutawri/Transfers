/*
 * File: npc_controller.c
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.30
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri May 26 11:55:14 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "npc_controller.h"
#include "rtwtypes.h"
#include "npc_controller_private.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "CANRX.h"
#include "periodic_timer1.h"
#include "cla_header.h"
#include <string.h>
#define npc_controller_IN_Burst        (1U)
#define npc_controller_IN_Contineous   (2U)
#define npc_controller_IN_init         (1U)
#define npc_controller_IN_n2p          (2U)
#define npc_controller_IN_neg          (3U)
#define npc_controller_IN_neg_peak     (4U)
#define npc_controller_IN_p2n          (5U)
#define npc_controller_IN_pos          (6U)
#define npc_controller_IN_pos_peak     (7U)

/* Exported data definition */

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Definition for custom storage class: Cla1DataRam */
#if defined(PRAGMA_FLAG_cla_pida_temp1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla_pida_temp1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_cla_pida_temp1) || !defined(__TMS320C28XX_CLA__)

real32_T cla_pida_temp1;               /* '<S33>/In1' */

#endif

#if !defined(PRAGMA_FLAG_cla_pida_temp1)
#define PRAGMA_FLAG_cla_pida_temp1
#endif

#if defined(PRAGMA_FLAG_cla_pida_temp2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla_pida_temp2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_cla_pida_temp2) || !defined(__TMS320C28XX_CLA__)

real32_T cla_pida_temp2;               /* '<S34>/Gain' */

#endif

#if !defined(PRAGMA_FLAG_cla_pida_temp2)
#define PRAGMA_FLAG_cla_pida_temp2
#endif

#if defined(PRAGMA_FLAG_ia_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid1;                      /* '<S23>/ia_pid1' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid1)
#define PRAGMA_FLAG_ia_pid1
#endif

#if defined(PRAGMA_FLAG_ia_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid2;                      /* '<S23>/ia_pid2' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid2)
#define PRAGMA_FLAG_ia_pid2
#endif

#if defined(PRAGMA_FLAG_ia_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid3;                      /* '<S23>/ia_pid3' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid3)
#define PRAGMA_FLAG_ia_pid3
#endif

#if defined(PRAGMA_FLAG_ia_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid4;                      /* '<S23>/ia_pid4' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid4)
#define PRAGMA_FLAG_ia_pid4
#endif

#if defined(PRAGMA_FLAG_ib_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid1;                      /* '<S24>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid1)
#define PRAGMA_FLAG_ib_pid1
#endif

#if defined(PRAGMA_FLAG_ib_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid2;                      /* '<S24>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid2)
#define PRAGMA_FLAG_ib_pid2
#endif

#if defined(PRAGMA_FLAG_ib_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid3;                      /* '<S24>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid3)
#define PRAGMA_FLAG_ib_pid3
#endif

#if defined(PRAGMA_FLAG_ib_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid4;                      /* '<S24>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid4)
#define PRAGMA_FLAG_ib_pid4
#endif

#if defined(PRAGMA_FLAG_ic_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid1;                      /* '<S25>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid1)
#define PRAGMA_FLAG_ic_pid1
#endif

#if defined(PRAGMA_FLAG_ic_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid2;                      /* '<S25>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid2)
#define PRAGMA_FLAG_ic_pid2
#endif

#if defined(PRAGMA_FLAG_ic_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid3;                      /* '<S25>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid3)
#define PRAGMA_FLAG_ic_pid3
#endif

#if defined(PRAGMA_FLAG_ic_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid4;                      /* '<S25>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid4)
#define PRAGMA_FLAG_ic_pid4
#endif

#if defined(PRAGMA_FLAG_ss_delay_temp) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ss_delay_temp,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ss_delay_temp) || !defined(__TMS320C28XX_CLA__)

real32_T ss_delay_temp;                /* '<S35>/Delay' */

#endif

#if !defined(PRAGMA_FLAG_ss_delay_temp)
#define PRAGMA_FLAG_ss_delay_temp
#endif

#if defined(PRAGMA_FLAG_vbulk_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid1;                   /* '<S27>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid1)
#define PRAGMA_FLAG_vbulk_pid1
#endif

#if defined(PRAGMA_FLAG_vbulk_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid2;                   /* '<S27>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid2)
#define PRAGMA_FLAG_vbulk_pid2
#endif

#if defined(PRAGMA_FLAG_vbulk_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid3;                   /* '<S27>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid3)
#define PRAGMA_FLAG_vbulk_pid3
#endif

#if defined(PRAGMA_FLAG_vbulk_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid4;                   /* '<S27>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid4)
#define PRAGMA_FLAG_vbulk_pid4
#endif

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Definition for custom storage class: Cla1ToCpuMsgRAM */
#if defined(PRAGMA_FLAG_cla2cpu_Ipk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla2cpu_Ipk,"Cla1ToCpuMsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Ipk) || !defined(__TMS320C28XX_CLA__)

real32_T cla2cpu_Ipk;                  /* '<S53>/Switch2' */

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Ipk)
#define PRAGMA_FLAG_cla2cpu_Ipk
#endif

#if defined(PRAGMA_FLAG_cla2cpu_Vpk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla2cpu_Vpk,"Cla1ToCpuMsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Vpk) || !defined(__TMS320C28XX_CLA__)

real_T cla2cpu_Vpk;

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Vpk)
#define PRAGMA_FLAG_cla2cpu_Vpk
#endif

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Definition for custom storage class: CpuToCla1MsgRAM */
#if defined(PRAGMA_FLAG_cpu2cla_angle) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_angle,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_angle) || !defined(__TMS320C28XX_CLA__)

real_T cpu2cla_angle;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_angle)
#define PRAGMA_FLAG_cpu2cla_angle
#endif

#if defined(PRAGMA_FLAG_cpu2cla_control_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_control_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_control_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_control_en;          /* '<S2>/Data Store Read' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_control_en)
#define PRAGMA_FLAG_cpu2cla_control_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ia) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ia,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ia) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ia;                   /* '<S81>/vabc3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ia)
#define PRAGMA_FLAG_cpu2cla_ia
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ib) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ib,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ib) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ib;                   /* '<S80>/vabc3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ib)
#define PRAGMA_FLAG_cpu2cla_ib
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ic) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ic,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ic) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ic;                   /* '<S79>/vabc3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ic)
#define PRAGMA_FLAG_cpu2cla_ic
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pfc_ok2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pfc_ok2,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pfc_ok2) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pfc_ok2;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pfc_ok2)
#define PRAGMA_FLAG_cpu2cla_pfc_ok2
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pha_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pha_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pha_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pha_en;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pha_en)
#define PRAGMA_FLAG_cpu2cla_pha_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_phb_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_phb_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phb_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_phb_en;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phb_en)
#define PRAGMA_FLAG_cpu2cla_phb_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_phc_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_phc_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phc_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_phc_en;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phc_en)
#define PRAGMA_FLAG_cpu2cla_phc_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ref) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ref,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ref) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ref; /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ref)
#define PRAGMA_FLAG_cpu2cla_ref
#endif

#if defined(PRAGMA_FLAG_cpu2cla_van) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_van,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_van) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_van;                  /* '<S82>/vabc3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_van)
#define PRAGMA_FLAG_cpu2cla_van
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vbn) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vbn,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbn) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vbn;                  /* '<S76>/vabc3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbn)
#define PRAGMA_FLAG_cpu2cla_vbn
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vbulk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vbulk,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbulk) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vbulk;                /* '<S66>/ADC3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbulk)
#define PRAGMA_FLAG_cpu2cla_vbulk
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vcn) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vcn,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vcn) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vcn;                  /* '<S77>/vabc3' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vcn)
#define PRAGMA_FLAG_cpu2cla_vcn
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vmid) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vmid,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vmid) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vmid;                 /* '<S66>/ADC4' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vmid)
#define PRAGMA_FLAG_cpu2cla_vmid
#endif

#if defined(PRAGMA_FLAG_cpu2cla_zc_a) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_zc_a,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_zc_a) || !defined(__TMS320C28XX_CLA__)

real_T cpu2cla_zc_a;                   /* '<S111>/Chart' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_zc_a)
#define PRAGMA_FLAG_cpu2cla_zc_a
#endif

/* Block signals (default storage) */
BlockIO_npc_controller npc_controller_B;

/* Block states (default storage) */
D_Work_npc_controller npc_controller_DWork;

/* External inputs (root inport signals with default storage) */
ExternalInputs_npc_controller npc_controller_U;

/* Real-time model */
static RT_MODEL_npc_controller npc_controller_M_;
RT_MODEL_npc_controller *const npc_controller_M = &npc_controller_M_;
static void rate_monotonic_scheduler(void);

#ifndef __TMS320C28XX_CLA__

uint16_T MW_adcAInitFlag = 0;

#endif

#ifndef __TMS320C28XX_CLA__

uint16_T MW_adcBInitFlag = 0;

#endif

real32_T look1_iflf_binlxpw(real32_T u0, const real32_T bp0[], const real32_T
  table[], uint32_T maxIndex)
{
  real32_T frac;
  real32_T yL_0d0;
  uint32_T bpIdx;
  uint32_T iLeft;
  uint32_T iRght;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0UL]) {
    iLeft = 0UL;
    frac = (u0 - bp0[0UL]) / (bp0[1UL] - bp0[0UL]);
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search */
    bpIdx = maxIndex >> 1UL;
    iLeft = 0UL;
    iRght = maxIndex;
    while (iRght - iLeft > 1UL) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1UL;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1UL] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1UL;
    frac = (u0 - bp0[maxIndex - 1UL]) / (bp0[maxIndex] - bp0[maxIndex - 1UL]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1UL] - yL_0d0) * frac + yL_0d0;
}

/* Hardware Interrupt Block: '<Root>/C28x Hardware Interrupt2' */
void isr_int1pie1_task_fcn(void)
{
  if (1 == runModel) {
    /* Call the system: <Root>/CONTROL */
    {
      /* S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */

      /* Output and update for function-call system: '<Root>/CONTROL' */
      {
        real32_T rtb_Sum;
        real32_T rtb_Sum_b;
        real32_T rtb_Sum_ei;
        real32_T rtb_Sum_l;
        real32_T rtb_Sum_oi;
        real32_T rtb_Sum_pz;
        real32_T vabc3;
        real32_T vabc3_b;
        real32_T vabc3_g;
        int16_T tmp;
        uint16_T qY;
        boolean_T Constant1;
        boolean_T guard1 = false;
        boolean_T rtb_FixPtRelationalOperator;

        /* DataStoreRead: '<S2>/Data Store Read' */
        cpu2cla_control_en = npc_controller_DWork.control_en;

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/GET_ADC'
         */
        /* S-Function (fcgen): '<S64>/Function-Call Generator' incorporates:
         *  SubSystem: '<S64>/ADCA'
         */
        /* S-Function (c2802xadc): '<S65>/ADC18' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC18 = (AdcaResultRegs.ADCRESULT0);
        }

        /* DataStoreWrite: '<S76>/Data Store Write3' */
        npc_controller_DWork.adc_vb = npc_controller_B.ADC18;

        /* Sum: '<S76>/vabc3' incorporates:
         *  DataStoreRead: '<S76>/Data Store Read4'
         */
        cpu2cla_vbn = npc_controller_B.ADC18 -
          npc_controller_DWork.adc_offset_vb;

        /* S-Function (c2802xadc): '<S65>/ADC5' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC5_b = (AdcaResultRegs.ADCRESULT4);
        }

        /* If: '<S79>/If3' incorporates:
         *  DataStoreRead: '<S79>/Data Store Read6'
         */
        if (!npc_controller_DWork.ac_ok) {
          /* Outputs for IfAction SubSystem: '<S79>/If Action Subsystem2' incorporates:
           *  ActionPort: '<S84>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem' incorporates:
           *  ActionPort: '<S86>/Action Port'
           */
          /* If: '<S84>/If' incorporates:
           *  DataStoreWrite: '<S86>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasec = ((npc_controller_B.ADC5_b > 3705.0F)
            || (npc_controller_B.ADC5_b < 798.0F) ||
            npc_controller_DWork.tfv_iphasec);

          /* End of Outputs for SubSystem: '<S84>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S79>/If Action Subsystem2' */
        } else {
          /* Outputs for IfAction SubSystem: '<S79>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S83>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S83>/If Action Subsystem' incorporates:
           *  ActionPort: '<S85>/Action Port'
           */
          /* If: '<S83>/If2' incorporates:
           *  DataStoreWrite: '<S85>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasec = ((npc_controller_B.ADC5_b > 3342.0F)
            || (npc_controller_B.ADC5_b < 1162.0F) ||
            npc_controller_DWork.tfv_iphasec);

          /* End of Outputs for SubSystem: '<S83>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S79>/If Action Subsystem1' */
        }

        /* End of If: '<S79>/If3' */

        /* Sum: '<S79>/vabc3' incorporates:
         *  DataStoreRead: '<S79>/Data Store Read4'
         */
        cpu2cla_ic = npc_controller_B.ADC5_b -
          npc_controller_DWork.adc_offset_ic;

        /* S-Function (c2802xadc): '<S65>/ADC7' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC7 = (AdcaResultRegs.ADCRESULT3);
        }

        /* DataStoreWrite: '<S77>/Data Store Write3' */
        npc_controller_DWork.adc_vc = npc_controller_B.ADC7;

        /* Sum: '<S77>/vabc3' incorporates:
         *  DataStoreRead: '<S77>/Data Store Read4'
         */
        cpu2cla_vcn = npc_controller_B.ADC7 - npc_controller_DWork.adc_offset_vc;

        /* S-Function (c2802xadc): '<S65>/ADC3' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC3 = (AdcaResultRegs.ADCRESULT2);
        }

        /* If: '<S81>/If3' incorporates:
         *  DataStoreRead: '<S81>/Data Store Read6'
         */
        if (!npc_controller_DWork.ac_ok) {
          /* Outputs for IfAction SubSystem: '<S81>/If Action Subsystem2' incorporates:
           *  ActionPort: '<S92>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S92>/If Action Subsystem' incorporates:
           *  ActionPort: '<S94>/Action Port'
           */
          /* If: '<S92>/If' incorporates:
           *  DataStoreWrite: '<S94>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasea = ((npc_controller_B.ADC3 > 3705.0F) ||
            (npc_controller_B.ADC3 < 798.0F) || npc_controller_DWork.tfv_iphasea);

          /* End of Outputs for SubSystem: '<S92>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S81>/If Action Subsystem2' */
        } else {
          /* Outputs for IfAction SubSystem: '<S81>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S91>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S91>/If Action Subsystem' incorporates:
           *  ActionPort: '<S93>/Action Port'
           */
          /* If: '<S91>/If2' incorporates:
           *  DataStoreWrite: '<S93>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasea = ((npc_controller_B.ADC3 > 3342.0F) ||
            (npc_controller_B.ADC3 < 1162.0F) ||
            npc_controller_DWork.tfv_iphasea);

          /* End of Outputs for SubSystem: '<S91>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S81>/If Action Subsystem1' */
        }

        /* End of If: '<S81>/If3' */

        /* Sum: '<S81>/vabc3' incorporates:
         *  DataStoreRead: '<S81>/Data Store Read4'
         */
        cpu2cla_ia = npc_controller_B.ADC3 - npc_controller_DWork.adc_offset_ia;

        /* S-Function (c2802xadc): '<S65>/ADC6' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC6_b = (AdcaResultRegs.ADCRESULT5);
        }

        /* DataTypeConversion: '<S82>/Cast To Single4' incorporates:
         *  DataStoreWrite: '<S82>/Data Store Write2'
         */
        vabc3 = (real32_T)floor(npc_controller_B.ADC6_b);
        if (rtIsNaNF(vabc3) || rtIsInfF(vabc3)) {
          vabc3 = 0.0F;
        } else {
          vabc3 = (real32_T)fmod(vabc3, 65536.0);
        }

        npc_controller_DWork.u16Debug3 = vabc3 < 0.0F ? (uint16_T)-(int16_T)
          (uint16_T)-vabc3 : (uint16_T)vabc3;

        /* End of DataTypeConversion: '<S82>/Cast To Single4' */

        /* DataStoreWrite: '<S82>/Data Store Write3' */
        npc_controller_DWork.adc_va = npc_controller_B.ADC6_b;

        /* Sum: '<S82>/vabc3' incorporates:
         *  DataStoreRead: '<S82>/Data Store Read4'
         */
        cpu2cla_van = npc_controller_B.ADC6_b -
          npc_controller_DWork.adc_offset_va;

        /* S-Function (c2802xadc): '<S65>/ADC17' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC17 = (AdcaResultRegs.ADCRESULT6);
        }

        /* If: '<S80>/If3' incorporates:
         *  DataStoreRead: '<S80>/Data Store Read6'
         */
        if (!npc_controller_DWork.ac_ok) {
          /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem2' incorporates:
           *  ActionPort: '<S88>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S88>/If Action Subsystem' incorporates:
           *  ActionPort: '<S90>/Action Port'
           */
          /* If: '<S88>/If' incorporates:
           *  DataStoreWrite: '<S90>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphaseb = ((npc_controller_B.ADC17 > 3705.0F)
            || (npc_controller_B.ADC17 < 798.0F) ||
            npc_controller_DWork.tfv_iphaseb);

          /* End of Outputs for SubSystem: '<S88>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S80>/If Action Subsystem2' */
        } else {
          /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S87>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S87>/If Action Subsystem' incorporates:
           *  ActionPort: '<S89>/Action Port'
           */
          /* If: '<S87>/If2' incorporates:
           *  DataStoreWrite: '<S89>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphaseb = ((npc_controller_B.ADC17 > 3342.0F)
            || (npc_controller_B.ADC17 < 1162.0F) ||
            npc_controller_DWork.tfv_iphaseb);

          /* End of Outputs for SubSystem: '<S87>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S80>/If Action Subsystem1' */
        }

        /* End of If: '<S80>/If3' */

        /* Sum: '<S80>/vabc3' incorporates:
         *  DataStoreRead: '<S80>/Data Store Read4'
         */
        cpu2cla_ib = npc_controller_B.ADC17 - npc_controller_DWork.adc_offset_ib;

        /* S-Function (c2802xadc): '<S65>/ADC8' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC8 = (AdcaResultRegs.ADCRESULT7);
        }

        /* DataStoreWrite: '<S78>/Data Store Write12' */
        npc_controller_DWork.adc_vaux = npc_controller_B.ADC8;

        /* S-Function (fcgen): '<S64>/Function-Call Generator' incorporates:
         *  SubSystem: '<S64>/ADCC'
         */
        /* S-Function (c2802xadc): '<S66>/ADC6' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC0 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC6 = (AdcbResultRegs.ADCRESULT0);
        }

        /* DataStoreWrite: '<S97>/Data Store Write' */
        npc_controller_DWork.adc_temp_npca = npc_controller_B.ADC6;

        /* Sum: '<S97>/vabc3' incorporates:
         *  DataStoreRead: '<S97>/Data Store Read4'
         */
        vabc3 = npc_controller_B.ADC6 - npc_controller_DWork.adc_offset_ia;

        /* S-Function (c2802xadc): '<S66>/ADC2' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC1 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC2 = (AdcbResultRegs.ADCRESULT1);
        }

        /* DataStoreWrite: '<S98>/Data Store Write' */
        npc_controller_DWork.adc_temp_npcb = npc_controller_B.ADC2;

        /* Sum: '<S98>/vabc3' incorporates:
         *  DataStoreRead: '<S98>/Data Store Read4'
         */
        vabc3_g = npc_controller_B.ADC2 - npc_controller_DWork.adc_offset_ib;

        /* S-Function (c2802xadc): '<S66>/ADC5' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC2 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC5 = (AdcbResultRegs.ADCRESULT2);
        }

        /* DataStoreWrite: '<S99>/Data Store Write' */
        npc_controller_DWork.adc_temp_npcc = npc_controller_B.ADC5;

        /* Sum: '<S99>/vabc3' incorporates:
         *  DataStoreRead: '<S99>/Data Store Read4'
         */
        vabc3_b = npc_controller_B.ADC5 - npc_controller_DWork.adc_offset_ic;

        /* S-Function (c2802xadc): '<S66>/ADC3' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC3 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          cpu2cla_vbulk = (AdcbResultRegs.ADCRESULT3);
        }

        /* DataStoreWrite: '<S96>/Data Store Write6' */
        npc_controller_DWork.adc_vbulk = cpu2cla_vbulk;

        /* S-Function (c2802xadc): '<S66>/ADC4' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC4 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          cpu2cla_vmid = (AdcbResultRegs.ADCRESULT4);
        }

        /* DataStoreWrite: '<S95>/Data Store Write8' */
        npc_controller_DWork.adc_vmid = cpu2cla_vmid;

        /* End of Outputs for S-Function (fcgen): '<S64>/Function-Call Generator' */

        /* Sum: '<S106>/Sum' incorporates:
         *  Constant: '<S73>/Offset7'
         *  Constant: '<S73>/Offset8'
         *  Delay: '<S106>/Delay'
         *  Gain: '<S106>/1 - Lambda'
         *  Gain: '<S106>/Lambda'
         *  Product: '<S73>/Product'
         *  Product: '<S73>/Product1'
         *  RelationalOperator: '<S73>/Less Than'
         *  RelationalOperator: '<S73>/Less Than1'
         *  Sum: '<S73>/vabc7'
         */
        vabc3 = ((real32_T)(vabc3 > 0.0F) * vabc3 - (real32_T)(vabc3 < 0.0F) *
                 vabc3) * 0.00015384F + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_f;

        /* Gain: '<S73>/Gain' incorporates:
         *  DataStoreWrite: '<S73>/Data Store Write3'
         */
        npc_controller_DWork.rms_iphasea = 1.11F * vabc3;

        /* Sum: '<S107>/Sum' incorporates:
         *  Constant: '<S74>/Offset7'
         *  Constant: '<S74>/Offset8'
         *  Delay: '<S107>/Delay'
         *  Gain: '<S107>/1 - Lambda'
         *  Gain: '<S107>/Lambda'
         *  Product: '<S74>/Product'
         *  Product: '<S74>/Product1'
         *  RelationalOperator: '<S74>/Less Than'
         *  RelationalOperator: '<S74>/Less Than1'
         *  Sum: '<S74>/vabc7'
         */
        vabc3_g = ((real32_T)(vabc3_g > 0.0F) * vabc3_g - (real32_T)(vabc3_g <
                    0.0F) * vabc3_g) * 0.00015384F + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_l;

        /* Gain: '<S74>/Gain' incorporates:
         *  DataStoreWrite: '<S74>/Data Store Write3'
         */
        npc_controller_DWork.rms_iphaseb = 1.11F * vabc3_g;

        /* Sum: '<S108>/Sum' incorporates:
         *  Constant: '<S75>/Offset7'
         *  Constant: '<S75>/Offset8'
         *  Delay: '<S108>/Delay'
         *  Gain: '<S108>/1 - Lambda'
         *  Gain: '<S108>/Lambda'
         *  Product: '<S75>/Product'
         *  Product: '<S75>/Product1'
         *  RelationalOperator: '<S75>/Less Than'
         *  RelationalOperator: '<S75>/Less Than1'
         *  Sum: '<S75>/vabc7'
         */
        vabc3_b = ((real32_T)(vabc3_b > 0.0F) * vabc3_b - (real32_T)(vabc3_b <
                    0.0F) * vabc3_b) * 0.00015384F + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_k;

        /* Gain: '<S75>/Gain' incorporates:
         *  DataStoreWrite: '<S75>/Data Store Write3'
         */
        npc_controller_DWork.rms_iphasec = 1.11F * vabc3_b;

        /* Sum: '<S100>/Sum' incorporates:
         *  Constant: '<S67>/Offset7'
         *  Constant: '<S67>/Offset8'
         *  Delay: '<S100>/Delay'
         *  Gain: '<S100>/1 - Lambda'
         *  Gain: '<S100>/Lambda'
         *  Product: '<S67>/Product'
         *  Product: '<S67>/Product1'
         *  RelationalOperator: '<S67>/Less Than'
         *  RelationalOperator: '<S67>/Less Than1'
         *  Sum: '<S67>/vabc7'
         */
        rtb_Sum = ((real32_T)(cpu2cla_van > 0.0F) * cpu2cla_van - (real32_T)
                   (cpu2cla_van < 0.0F) * cpu2cla_van) * 0.00015384F +
          0.99984616F * npc_controller_DWork.Delay_DSTATE_j;

        /* Gain: '<S67>/Gain' incorporates:
         *  DataStoreWrite: '<S67>/Data Store Write3'
         */
        npc_controller_DWork.rms_va = 1.11F * rtb_Sum;

        /* Sum: '<S101>/Sum' incorporates:
         *  Constant: '<S68>/Offset7'
         *  Constant: '<S68>/Offset8'
         *  Delay: '<S101>/Delay'
         *  Gain: '<S101>/1 - Lambda'
         *  Gain: '<S101>/Lambda'
         *  Product: '<S68>/Product'
         *  Product: '<S68>/Product1'
         *  RelationalOperator: '<S68>/Less Than'
         *  RelationalOperator: '<S68>/Less Than1'
         *  Sum: '<S68>/vabc7'
         */
        rtb_Sum_b = ((real32_T)(cpu2cla_vbn > 0.0F) * cpu2cla_vbn - (real32_T)
                     (cpu2cla_vbn < 0.0F) * cpu2cla_vbn) * 0.00015384F +
          0.99984616F * npc_controller_DWork.Delay_DSTATE_lx;

        /* Gain: '<S68>/Gain' incorporates:
         *  DataStoreWrite: '<S68>/Data Store Write3'
         */
        npc_controller_DWork.rms_vb = 1.11F * rtb_Sum_b;

        /* Sum: '<S102>/Sum' incorporates:
         *  Constant: '<S69>/Offset7'
         *  Constant: '<S69>/Offset8'
         *  Delay: '<S102>/Delay'
         *  Gain: '<S102>/1 - Lambda'
         *  Gain: '<S102>/Lambda'
         *  Product: '<S69>/Product'
         *  Product: '<S69>/Product1'
         *  RelationalOperator: '<S69>/Less Than'
         *  RelationalOperator: '<S69>/Less Than1'
         *  Sum: '<S69>/vabc7'
         */
        rtb_Sum_oi = ((real32_T)(cpu2cla_vcn > 0.0F) * cpu2cla_vcn - (real32_T)
                      (cpu2cla_vcn < 0.0F) * cpu2cla_vcn) * 0.00015384F +
          0.99984616F * npc_controller_DWork.Delay_DSTATE_m;

        /* Gain: '<S69>/Gain' incorporates:
         *  DataStoreWrite: '<S69>/Data Store Write3'
         */
        npc_controller_DWork.rms_vc = 1.11F * rtb_Sum_oi;

        /* Sum: '<S103>/Sum' incorporates:
         *  Constant: '<S70>/Offset7'
         *  Constant: '<S70>/Offset8'
         *  Delay: '<S103>/Delay'
         *  Gain: '<S103>/1 - Lambda'
         *  Gain: '<S103>/Lambda'
         *  Product: '<S70>/Product'
         *  Product: '<S70>/Product1'
         *  RelationalOperator: '<S70>/Less Than'
         *  RelationalOperator: '<S70>/Less Than1'
         *  Sum: '<S70>/vabc7'
         */
        rtb_Sum_pz = ((real32_T)(cpu2cla_ia > 0.0F) * cpu2cla_ia - (real32_T)
                      (cpu2cla_ia < 0.0F) * cpu2cla_ia) * 0.00015384F +
          0.99984616F * npc_controller_DWork.Delay_DSTATE_e4;

        /* Gain: '<S70>/Gain' incorporates:
         *  DataStoreWrite: '<S70>/Data Store Write3'
         */
        npc_controller_DWork.rms_ia = 1.11F * rtb_Sum_pz;

        /* Sum: '<S104>/Sum' incorporates:
         *  Constant: '<S71>/Offset7'
         *  Constant: '<S71>/Offset8'
         *  Delay: '<S104>/Delay'
         *  Gain: '<S104>/1 - Lambda'
         *  Gain: '<S104>/Lambda'
         *  Product: '<S71>/Product'
         *  Product: '<S71>/Product1'
         *  RelationalOperator: '<S71>/Less Than'
         *  RelationalOperator: '<S71>/Less Than1'
         *  Sum: '<S71>/vabc7'
         */
        rtb_Sum_l = ((real32_T)(cpu2cla_ib > 0.0F) * cpu2cla_ib - (real32_T)
                     (cpu2cla_ib < 0.0F) * cpu2cla_ib) * 0.00015384F +
          0.99984616F * npc_controller_DWork.Delay_DSTATE_ef;

        /* Gain: '<S71>/Gain' incorporates:
         *  DataStoreWrite: '<S71>/Data Store Write3'
         */
        npc_controller_DWork.rms_ib = 1.11F * rtb_Sum_l;

        /* Sum: '<S105>/Sum' incorporates:
         *  Constant: '<S72>/Offset7'
         *  Constant: '<S72>/Offset8'
         *  Delay: '<S105>/Delay'
         *  Gain: '<S105>/1 - Lambda'
         *  Gain: '<S105>/Lambda'
         *  Product: '<S72>/Product'
         *  Product: '<S72>/Product1'
         *  RelationalOperator: '<S72>/Less Than'
         *  RelationalOperator: '<S72>/Less Than1'
         *  Sum: '<S72>/vabc7'
         */
        rtb_Sum_ei = ((real32_T)(cpu2cla_ic > 0.0F) * cpu2cla_ic - (real32_T)
                      (cpu2cla_ic < 0.0F) * cpu2cla_ic) * 0.00015384F +
          0.99984616F * npc_controller_DWork.Delay_DSTATE_d;

        /* Gain: '<S72>/Gain' incorporates:
         *  DataStoreWrite: '<S72>/Data Store Write3'
         */
        npc_controller_DWork.rms_ic = 1.11F * rtb_Sum_ei;

        /* Update for Delay: '<S106>/Delay' */
        npc_controller_DWork.Delay_DSTATE_f = vabc3;

        /* Update for Delay: '<S107>/Delay' */
        npc_controller_DWork.Delay_DSTATE_l = vabc3_g;

        /* Update for Delay: '<S108>/Delay' */
        npc_controller_DWork.Delay_DSTATE_k = vabc3_b;

        /* Update for Delay: '<S100>/Delay' */
        npc_controller_DWork.Delay_DSTATE_j = rtb_Sum;

        /* Update for Delay: '<S101>/Delay' */
        npc_controller_DWork.Delay_DSTATE_lx = rtb_Sum_b;

        /* Update for Delay: '<S102>/Delay' */
        npc_controller_DWork.Delay_DSTATE_m = rtb_Sum_oi;

        /* Update for Delay: '<S103>/Delay' */
        npc_controller_DWork.Delay_DSTATE_e4 = rtb_Sum_pz;

        /* Update for Delay: '<S104>/Delay' */
        npc_controller_DWork.Delay_DSTATE_ef = rtb_Sum_l;

        /* Update for Delay: '<S105>/Delay' */
        npc_controller_DWork.Delay_DSTATE_d = rtb_Sum_ei;

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/CONTROL'
         */
        /* If: '<S8>/If' incorporates:
         *  DataStoreRead: '<S8>/Data Store Read'
         */
        if (npc_controller_DWork.u8PriFutEnable == 0U) {
          /* Outputs for IfAction SubSystem: '<S8>/false' incorporates:
           *  ActionPort: '<S13>/Action Port'
           */
          /* S-Function (c2000cla): '<S13>/CLA Task1' */
          Cla1ForceTask1();

          /* End of Outputs for S-Function (c2000cla): '<S13>/CLA Task1' */
          /* End of Outputs for SubSystem: '<S8>/false' */
        }

        /* End of If: '<S8>/If' */

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/STATE-MACHINE'
         */
        /* Gain: '<S12>/Gain3' incorporates:
         *  DataStoreRead: '<S12>/Data Store Read5'
         */
        vabc3 = 1.414F * npc_controller_DWork.rms_va;

        /* Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
         *  Constant: '<S12>/Constant'
         *  If: '<S118>/If1'
         *  Logic: '<S117>/OR'
         */
        /* Gateway: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3 */
        /* During: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3 */
        /* Entry Internal: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3 */
        /* Transition: '<S112>:599' */
        guard1 = false;
        if (npc_controller_DWork.start_cnt > 63333.0) {
          /* Transition: '<S112>:600' */
          /* 50cycles for codegen */
          if (npc_controller_B.calib_ok) {
            /* Outputs for Function Call SubSystem: '<S112>/detectUvpOvp' */
            /* Chart: '<S117>/OVP' incorporates:
             *  Constant: '<S12>/Constant'
             */
            /* Transition: '<S112>:417' */
            /* Simulink Function 'detectUvpOvp': '<S112>:799' */
            /* Gateway: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/OVP */
            /* During: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/OVP */
            /* Entry Internal: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/OVP */
            /* Transition: '<S123>:17' */
            if (vabc3 > 244.93333333333334) {
              /* Transition: '<S123>:15' */
              /* Transition: '<S123>:16' */
              npc_controller_B.tfv_v_Ovp = 1.0;

              /* Transition: '<S123>:14' */
            } else if (vabc3 < 219.6) {
              /* Transition: '<S123>:10' */
              /* Transition: '<S123>:11' */
              npc_controller_B.tfv_v_Ovp = 0.0;
            } else {
              /* Transition: '<S123>:8' */
              /* Transition: '<S123>:9' */

              /* Transition: '<S123>:12' */
            }

            /* End of Chart: '<S117>/OVP' */

            /* Chart: '<S117>/UVP' incorporates:
             *  Constant: '<S12>/Constant'
             */
            /* Gateway: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/UVP */
            /* During: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/UVP */
            /* Entry Internal: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/UVP */
            /* Transition: '<S124>:35' */
            if (vabc3 < 134.4) {
              /* Transition: '<S124>:27' */
              /* Transition: '<S124>:25' */
              npc_controller_B.tfv_v_Uvp = 1.0;

              /* Transition: '<S124>:24' */
            } else if (vabc3 > 151.46666666666667) {
              /* Transition: '<S124>:31' */
              /* Transition: '<S124>:30' */
              npc_controller_B.tfv_v_Uvp = 0.0;
            } else {
              /* Transition: '<S124>:21' */
              /* Transition: '<S124>:32' */

              /* Transition: '<S124>:29' */
            }

            /* End of Chart: '<S117>/UVP' */
            npc_controller_B.tfv_v_UvpOvp = ((npc_controller_B.tfv_v_Ovp != 0.0)
              || (npc_controller_B.tfv_v_Uvp != 0.0));

            /* End of Outputs for SubSystem: '<S112>/detectUvpOvp' */

            /* Outputs for Function Call SubSystem: '<S112>/readCmpssOcp' */
            /* Simulink Function 'readCmpssOcp': '<S112>:790' */

            /* user code (Output function Body for TID3) */

            /* System '<S112>/readCmpssOcp' */

            /*read Digital Compare EVT1 Tz Flag*/
            npc_controller_DWork.tz_cmpssocp = EPwm2Regs.TZFLG.bit.DCAEVT1 |
              EPwm2Regs.TZFLG.bit.DCBEVT1 | EPwm7Regs.TZFLG.bit.DCAEVT1 |
              EPwm7Regs.TZFLG.bit.DCBEVT1 | EPwm8Regs.TZFLG.bit.DCAEVT1 |
              EPwm8Regs.TZFLG.bit.DCBEVT1 | EPwm9Regs.TZFLG.bit.DCAEVT1 |
              EPwm9Regs.TZFLG.bit.DCBEVT1| EPwm10Regs.TZFLG.bit.DCAEVT1 |
              EPwm10Regs.TZFLG.bit.DCBEVT1 | EPwm11Regs.TZFLG.bit.DCAEVT1 |
              EPwm11Regs.TZFLG.bit.DCBEVT1;

            /* End of Outputs for SubSystem: '<S112>/readCmpssOcp' */
            /* Transition: '<S112>:532' */
            /* fault latch|| tfv_vtop */
            if (npc_controller_DWork.tfv_va || npc_controller_DWork.tfv_vb ||
                npc_controller_DWork.tfv_vc || npc_controller_DWork.tfv_iphasea ||
                npc_controller_DWork.tfv_iphaseb ||
                npc_controller_DWork.tfv_iphasec ||
                npc_controller_DWork.tfv_vbulk || npc_controller_DWork.tfv_vmid ||
                npc_controller_DWork.tfv_vaux || (npc_controller_DWork.tz_ocp !=
                 0U) || (npc_controller_DWork.tz_ovp != 0U) ||
                (npc_controller_DWork.tz_cmpssocp != 0U) ||
                npc_controller_DWork.fault) {
              /* Transition: '<S112>:4' */
              npc_controller_DWork.fault = true;
              npc_controller_B.state = 1U;

              /* turn OFF */
              /* Transition: '<S112>:420' */
              /* {calib_ok = false;} //calib_ok resets at fault or CAN command */
              /* Transition: '<S112>:763' */
              guard1 = true;

              /* Transition: '<S112>:671' */
              /* Transition: '<S112>:543' */
            } else if ((int16_T)npc_controller_DWork.u8PriFutEnable != 0) {
              /* Transition: '<S112>:502' */
              if (!npc_controller_DWork.fut_en) {
                /* Outputs for Function Call SubSystem: '<S112>/configFutEn' */
                /* Transition: '<S112>:493' */
                /* Transition: '<S112>:499' */
                /* Simulink Function 'configFutEn': '<S112>:496' */

                /* user code (Output function Body for TID3) */

                /* System '<S112>/configFutEn' */
                /*Disable forced PWM*/
                EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);

                /*Input unique %duty*/
                EPwm2Regs.CMPA.bit.CMPA = (uint16_T)(461.4F);//S1
                EPwm7Regs.CMPB.bit.CMPB = (uint16_T)(461.4F);//S2
                EPwm2Regs.CMPB.bit.CMPB = (uint16_T)(461.4F);//S3
                EPwm7Regs.CMPA.bit.CMPA = (uint16_T)(461.4F);//S4
                EPwm8Regs.CMPB.bit.CMPB = (uint16_T)(922.8F);//S1
                EPwm9Regs.CMPB.bit.CMPB = (uint16_T)(922.8F);//S2
                EPwm8Regs.CMPA.bit.CMPA = (uint16_T)(922.8F);//S3
                EPwm9Regs.CMPA.bit.CMPA = (uint16_T)(922.8F);//S4
                EPwm10Regs.CMPB.bit.CMPB = (uint16_T)(1384.2F);//S1
                EPwm11Regs.CMPB.bit.CMPB = (uint16_T)(1384.2F);//S2
                EPwm10Regs.CMPA.bit.CMPA = (uint16_T)(1384.2F);//S3
                EPwm11Regs.CMPA.bit.CMPA = (uint16_T)(1384.2F);//S4

                /* End of Outputs for SubSystem: '<S112>/configFutEn' */
                npc_controller_DWork.fut_en = true;
              } else {
                /* Transition: '<S112>:495' */
                /* Transition: '<S112>:503' */
              }

              /* Transition: '<S112>:517' */
              npc_controller_B.state = 2U;

              /* Transition: '<S112>:732' */
              /* Transition: '<S112>:782' */
              /* Transition: '<S112>:708' */
              /* Transition: '<S112>:667' */
              /* Transition: '<S112>:718' */
              /* Transition: '<S112>:761' */
              /* Transition: '<S112>:535' */
            } else {
              /* Transition: '<S112>:719' */
              if (npc_controller_DWork.fut_en) {
                /* Outputs for Function Call SubSystem: '<S112>/configFutDis' */
                /* Transition: '<S112>:507' */
                /* Transition: '<S112>:509' */
                /* Simulink Function 'configFutDis': '<S112>:497' */

                /* user code (Output function Body for TID3) */

                /* System '<S112>/configFutDis' */
                /*Force PWM to LOW*/
                EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

                /* End of Outputs for SubSystem: '<S112>/configFutDis' */
                npc_controller_DWork.fut_en = false;

                /* Transition: '<S112>:518' */
              } else {
                /* Transition: '<S112>:513' */
              }

              /* Transition: '<S112>:741' */
              if ((!npc_controller_B.tfv_v_UvpOvp) &&
                  (!(npc_controller_DWork.otp_fault != 0.0F))) {
                /* Transition: '<S112>:730' */
                /* check ac_ok at start */
                /* Transition: '<S112>:737' */
                if (!npc_controller_DWork.pfc_en) {
                  /* Transition: '<S112>:715' */
                  npc_controller_B.state = 6U;

                  /* turn OFF
                     relay OFF */
                  /* Transition: '<S112>:717' */
                  guard1 = true;

                  /* Transition: '<S112>:723' */
                } else if (npc_controller_DWork.delay_cnt > 2666.0) {
                  /* Transition: '<S112>:779' */
                  if (!npc_controller_B.control_en) {
                    /* Transition: '<S112>:677' */
                    if (1.9797 * vabc3 - cpu2cla_vbulk < 50.0) {
                      /* Transition: '<S112>:344' */
                      /* Transition: '<S112>:660' */
                      npc_controller_B.relay_ctrl = true;

                      /* pre-charge relay ON */
                    } else {
                      /* Transition: '<S112>:566' */
                      /* Transition: '<S112>:663' */
                    }

                    /* Transition: '<S112>:682' */
                  } else {
                    /* Transition: '<S112>:680' */
                    /* Transition: '<S112>:681' */
                  }

                  if (npc_controller_B.relay_ctrl) {
                    /* Transition: '<S112>:661' */
                    if (npc_controller_DWork.relay_cnt > 3300.0) {
                      /* Transition: '<S112>:617' */
                      /* PWM ON with 40ms delay */
                      if (!npc_controller_B.control_en) {
                        /* Transition: '<S112>:618' */
                        if (cpu2cla_vbulk > 353.333344F) {
                          /* Transition: '<S112>:688' */
                          /* 80//160//300V */
                          /* Transition: '<S112>:704' */
                          npc_controller_B.control_en = true;

                          /* PWM ON */
                          cpu2cla_ref = cpu2cla_vbulk;

                          /* enDigCmpMode();
                             enCmpssTz(); */

                          /* Transition: '<S112>:697' */
                        } else if (cpu2cla_vbulk < 294.4F) {
                          /* Transition: '<S112>:687' */
                          /* 66.66V//133.33V//250V */
                          /* Transition: '<S112>:694' */
                          npc_controller_B.control_en = false;
                        } else {
                          /* Transition: '<S112>:690' */
                          /* Transition: '<S112>:700' */

                          /* Transition: '<S112>:705' */
                        }

                        /* Transition: '<S112>:703' */
                      } else {
                        /* Transition: '<S112>:755' */
                        /* Transition: '<S112>:756' */
                      }

                      if (npc_controller_B.control_en) {
                        /* Transition: '<S112>:115' */
                        if (cpu2cla_vbulk > 989.6F) {
                          /* Transition: '<S112>:120' */
                          /* 224V//448V//840V */
                          /* Transition: '<S112>:274' */
                          npc_controller_B.eoss = false;
                          npc_controller_B.burst_en = true;

                          /* Transition: '<S112>:255' */
                        } else if (cpu2cla_vbulk < 928.0F) {
                          /* Transition: '<S112>:265' */
                          /* 210V//420V//787V */
                          /* Transition: '<S112>:272' */
                          npc_controller_B.burst_en = false;
                        } else {
                          /* Transition: '<S112>:268' */
                          /* Transition: '<S112>:271' */

                          /* Transition: '<S112>:275' */
                        }

                        if (npc_controller_B.burst_en) {
                          /* Outputs for Function Call SubSystem: '<S112>/disablePwm' */
                          /* Transition: '<S112>:277' */
                          /* Transition: '<S112>:279' */
                          /* Simulink Function 'disablePwm': '<S112>:24' */

                          /* user code (Output function Body for TID3) */

                          /* System '<S112>/disablePwm' */
                          /*Force PWM to LOW*/
                          EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

                          /* End of Outputs for SubSystem: '<S112>/disablePwm' */
                          /* forced zero */
                          cpu2cla_pha_en = false;
                          cpu2cla_phb_en = false;
                          cpu2cla_phc_en = false;
                          npc_controller_B.state = 5U;

                          /* Transition: '<S112>:534' */
                        } else {
                          /* Transition: '<S112>:280' */
                          if (npc_controller_B.eoss) {
                            /* Transition: '<S112>:257' */
                            /* {tfv_v_UvpOvp = detectUvpOvp(Vpk, V_select)} */
                            if (npc_controller_DWork.eoss_cnt > 6667.0) {
                              /* Transition: '<S112>:649' */
                              /* 5cycles delay after SS for PFC_OK */
                              /* Transition: '<S112>:652' */
                              cpu2cla_pfc_ok2 = true;

                              /* eoss_cnt = 13100; */
                            } else {
                              /* Transition: '<S112>:653' */
                              npc_controller_DWork.eoss_cnt++;
                              cpu2cla_pfc_ok2 = false;

                              /* Transition: '<S112>:650' */
                            }

                            /* Transition: '<S112>:259' */
                          } else if (cpu2cla_ref < 883.733337F) {
                            /* Transition: '<S112>:91' */
                            /* (single(222//444//883)-vbulk) > single(50)] //11V ripple */
                            /* Transition: '<S112>:107' */
                            cpu2cla_ref = cpu2cla_ref + 0.00266666664F;
                            npc_controller_B.eoss = false;

                            /* Transition: '<S112>:90' */
                          } else if (cpu2cla_vbulk >= cpu2cla_ref - 50.0F) {
                            /* Transition: '<S112>:104' */
                            cpu2cla_ref = 883.733337F;

                            /* 200V//400V//750V */
                            npc_controller_B.eoss = true;

                            /* Transition: '<S112>:88' */
                          } else {
                            /* Transition: '<S112>:858' */

                            /* Transition: '<S112>:99' */
                            /* Transition: '<S112>:87' */
                            /* Transition: '<S112>:650' */
                          }

                          if (cpu2cla_pha_en) {
                            /* Outputs for Function Call SubSystem: '<S112>/updateSequencePhA_burst' */
                            /* S-Function (fcgen): '<S122>/Function-Call Generator' incorporates:
                             *  SubSystem: '<S122>/updateSequencePhA_burst'
                             */
                            /* S-Function (fcgen): '<S138>/Function-Call Generator' incorporates:
                             *  SubSystem: '<S138>/pol_vxn1'
                             */
                            /* Abs: '<S139>/Abs' */
                            /* Transition: '<S112>:353' */
                            /* Transition: '<S112>:355' */
                            /* Simulink Function 'updateSequencePhA_burst': '<S112>:817' */
                            vabc3 = (real32_T)fabs(cpu2cla_van);

                            /* Abs: '<S139>/Abs2' */
                            vabc3_g = (real32_T)fabs(cla2cpu_Ipk);

                            /* If: '<S143>/If1' incorporates:
                             *  Constant: '<S146>/Constant1'
                             *  Constant: '<S147>/Constant'
                             *  Constant: '<S148>/Constant'
                             *  RelationalOperator: '<S148>/Compare'
                             */
                            if ((cpu2cla_van > -16.0F) && (cpu2cla_van < 16.0F))
                            {
                              /* Outputs for IfAction SubSystem: '<S143>/true' incorporates:
                               *  ActionPort: '<S147>/Action Port'
                               */
                              tmp = 1;

                              /* End of Outputs for SubSystem: '<S143>/true' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S143>/false' incorporates:
                               *  ActionPort: '<S146>/Action Port'
                               */
                              tmp = -1;

                              /* End of Outputs for SubSystem: '<S143>/false' */
                            }

                            Constant1 = (tmp > 0);

                            /* End of If: '<S143>/If1' */

                            /* RelationalOperator: '<S145>/FixPt Relational Operator' incorporates:
                             *  UnitDelay: '<S145>/Delay Input1'
                             */
                            rtb_FixPtRelationalOperator = ((int16_T)Constant1 >
                              (int16_T)npc_controller_DWork.DelayInput1_DSTATE);

                            /* Chart: '<S139>/Chart2' incorporates:
                             *  Constant: '<S139>/2A'
                             *  DataTypeConversion: '<S143>/Data Type Conversion'
                             */
                            /* Gateway: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/Chart2 */
                            /* During: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/Chart2 */
                            if (npc_controller_DWork.is_active_c18_npc_controller
                                == 0U) {
                              /* Entry: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/Chart2 */
                              npc_controller_DWork.is_active_c18_npc_controller =
                                1U;

                              /* Entry Internal: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/Chart2 */
                              /* Transition: '<S140>:2' */
                              npc_controller_DWork.is_c18_npc_controller =
                                npc_controller_IN_Contineous;

                              /* Entry 'Contineous': '<S140>:1' */
                              vabc3_g = 1.0F;
                            } else if
                                (npc_controller_DWork.is_c18_npc_controller ==
                                 1U) {
                              /* During 'Burst': '<S140>:3' */
                              if ((vabc3_g > 37.5F) &&
                                  rtb_FixPtRelationalOperator) {
                                /* Transition: '<S140>:6' */
                                npc_controller_DWork.is_c18_npc_controller =
                                  npc_controller_IN_Contineous;

                                /* Entry 'Contineous': '<S140>:1' */
                                vabc3_g = 1.0F;
                              } else {
                                vabc3_g = 0.0F;
                              }

                              /* During 'Contineous': '<S140>:1' */
                            } else if ((vabc3_g < 12.5F) &&
                                       rtb_FixPtRelationalOperator) {
                              /* Transition: '<S140>:4' */
                              npc_controller_DWork.is_c18_npc_controller =
                                npc_controller_IN_Burst;

                              /* Entry 'Burst': '<S140>:3' */
                              vabc3_g = 0.0F;
                            } else {
                              vabc3_g = 1.0F;
                            }

                            /* End of Chart: '<S139>/Chart2' */

                            /* If: '<S139>/If2' */
                            if ((vabc3 < 48.0F) || (vabc3_g < 0.5F)) {
                              /* Outputs for IfAction SubSystem: '<S139>/zero' incorporates:
                               *  ActionPort: '<S142>/Action Port'
                               */

                              /* user code (Output function Body for TID3) */

                              /* System '<S139>/zero' */
                              /*Force PWM to LOW*/
                              EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S139>/zero' */
                            } else if (vabc3 >= 48.0F) {
                              /* Outputs for IfAction SubSystem: '<S139>/enable' incorporates:
                               *  ActionPort: '<S141>/Action Port'
                               */
                              /* Outputs for Atomic SubSystem: '<S141>/PWM_and_SR_ON' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S141>/PWM_and_SR_ON' */
                              /*Enable PWM*/
                              EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                              EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S141>/PWM_and_SR_ON' */
                              /* End of Outputs for SubSystem: '<S139>/enable' */
                            }

                            /* End of If: '<S139>/If2' */

                            /* Update for UnitDelay: '<S145>/Delay Input1' */
                            npc_controller_DWork.DelayInput1_DSTATE = Constant1;

                            /* End of Outputs for S-Function (fcgen): '<S138>/Function-Call Generator' */
                            /* End of Outputs for S-Function (fcgen): '<S122>/Function-Call Generator' */
                            /* End of Outputs for SubSystem: '<S112>/updateSequencePhA_burst' */
                          } else {
                            /* Outputs for Function Call SubSystem: '<S112>/detectZCPhA' */
                            /* Transition: '<S112>:357' */
                            /* Simulink Function 'detectZCPhA': '<S112>:459' */
                            cpu2cla_pha_en = ((cpu2cla_van > -5.0F) &&
                                              (cpu2cla_van < 5.0F));

                            /* End of Outputs for SubSystem: '<S112>/detectZCPhA' */
                            /* Transition: '<S112>:358' */
                          }

                          /* Transition: '<S112>:852' */
                          /* Transition: '<S112>:374' */
                          npc_controller_B.state = 4U;

                          /* Transition: '<S112>:328' */
                          /* Transition: '<S112>:534' */
                        }
                      } else {
                        /* Transition: '<S112>:666' */
                        /* exit */
                        /* Transition: '<S112>:761' */
                        /* Transition: '<S112>:535' */
                      }
                    } else {
                      /* Transition: '<S112>:619' */
                      npc_controller_DWork.relay_cnt++;

                      /* exit */
                      /* Transition: '<S112>:718' */
                      /* Transition: '<S112>:761' */
                      /* Transition: '<S112>:535' */
                    }
                  } else {
                    /* Transition: '<S112>:709' */
                    /* exit */
                    /* Transition: '<S112>:667' */
                    /* Transition: '<S112>:718' */
                    /* Transition: '<S112>:761' */
                    /* Transition: '<S112>:535' */
                  }
                } else {
                  /* Transition: '<S112>:781' */
                  npc_controller_DWork.delay_cnt++;

                  /* exit */
                  /* Transition: '<S112>:708' */
                  /* Transition: '<S112>:667' */
                  /* Transition: '<S112>:718' */
                  /* Transition: '<S112>:761' */
                  /* Transition: '<S112>:535' */
                }
              } else {
                /* Transition: '<S112>:746' */
                /* Transition: '<S112>:729' */
                npc_controller_B.state = 7U;

                /* turn OFF */
                /* Transition: '<S112>:763' */
                guard1 = true;
              }
            }
          } else {
            /* Outputs for Function Call SubSystem: '<S112>/updateCalib' */
            /* If: '<S121>/Codegen1' incorporates:
             *  Constant: '<S135>/Constant1'
             */
            /* Transition: '<S112>:438' */
            /* Simulink Function 'updateCalib': '<S112>:408' */
            if (npc_controller_DWork.cnt_calib > 65000U) {
              /* Outputs for IfAction SubSystem: '<S121>/done' incorporates:
               *  ActionPort: '<S128>/Action Port'
               */
              /* S-Function (fcgen): '<S128>/Function-Call Generator' incorporates:
               *  SubSystem: '<S128>/AUTO-CALIB_DONE'
               */
              /* DataStoreWrite: '<S135>/Data Store Write2' incorporates:
               *  Constant: '<S135>/Constant2'
               */
              npc_controller_DWork.cnt_calib = 1U;

              /* DataStoreWrite: '<S135>/Data Store Write' incorporates:
               *  DataStoreRead: '<S135>/Data Store Read'
               */
              npc_controller_DWork.adc_offset_ib =
                npc_controller_DWork.adc_offset_ib_tmp;

              /* DataStoreWrite: '<S135>/Data Store Write1' incorporates:
               *  DataStoreRead: '<S135>/Data Store Read1'
               */
              npc_controller_DWork.adc_offset_ic =
                npc_controller_DWork.adc_offset_ic_tmp;

              /* DataStoreWrite: '<S135>/Data Store Write3' incorporates:
               *  DataStoreRead: '<S135>/Data Store Read2'
               */
              npc_controller_DWork.adc_offset_va =
                npc_controller_DWork.adc_offset_va_tmp;

              /* DataStoreWrite: '<S135>/Data Store Write4' incorporates:
               *  DataStoreRead: '<S135>/Data Store Read3'
               */
              npc_controller_DWork.adc_offset_vb =
                npc_controller_DWork.adc_offset_vb_tmp;

              /* DataStoreWrite: '<S135>/Data Store Write5' incorporates:
               *  DataStoreRead: '<S135>/Data Store Read4'
               */
              npc_controller_DWork.adc_offset_vc =
                npc_controller_DWork.adc_offset_vc_tmp;

              /* DataStoreWrite: '<S135>/Data Store Write6' incorporates:
               *  DataStoreRead: '<S135>/Data Store Read5'
               */
              npc_controller_DWork.adc_offset_ia =
                npc_controller_DWork.adc_offset_ia_tmp;
              Constant1 = true;

              /* S-Function (fcgen): '<S128>/Function-Call Generator' incorporates:
               *  SubSystem: '<S128>/RESET_TZ'
               */

              /* user code (Output function Body for TID3) */

              /* System '<S128>/RESET_TZ' */

              //npc_controller_DWork.tz_ocp = 0b0;
              EALLOW;

              /*Disabled tripzone action*/
              EPwm2Regs.TZCTL.bit.TZA = (uint16_T)(0b11);//do nothing
              EPwm2Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm7Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm7Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm8Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm8Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm9Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm9Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm10Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm10Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm11Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm11Regs.TZCTL.bit.TZB = (uint16_T)(0b11);

              /*Disabled Digital Compare Out A and Out B Event1*/
              //EPwm2Regs.TZCTL.bit.DCAEVT1 = 0b11; //do nothing
              //EPwm2Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm7Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm7Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm8Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm8Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm9Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm9Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm10Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm10Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm11Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm11Regs.TZCTL.bit.DCBEVT1 = 0b11;
              /*Disabled Digital Compare Out A and Out B Event1 */
              EPwm2Regs.TZSEL.bit.DCAEVT1 = 0b0;//disable DCAEVT1 for the ePWM module
              EPwm2Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm7Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm7Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm8Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm8Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm9Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm9Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm10Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm10Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm11Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm11Regs.TZSEL.bit.DCBEVT1 = 0b0;

              /*Clear grouped OST TZ flags*/
              EPwm2Regs.TZCLR.bit.OST = 0b1;//clear trip
              EPwm7Regs.TZCLR.bit.OST = 0b1;
              EPwm8Regs.TZCLR.bit.OST = 0b1;
              EPwm9Regs.TZCLR.bit.OST = 0b1;
              EPwm10Regs.TZCLR.bit.OST = 0b1;
              EPwm11Regs.TZCLR.bit.OST = 0b1;

              /*Clear Digital Compare Out A and B Event1 flags */
              EPwm2Regs.TZCLR.bit.DCAEVT1 = 0b1;//clear trip
              EPwm2Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm7Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm7Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm8Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm8Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm9Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm9Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm10Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm10Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm11Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm11Regs.TZCLR.bit.DCBEVT1 = 0b1;

              /*Enabled Digital Compare Out A and Out B Event1 */
              EPwm2Regs.TZSEL.bit.DCAEVT1 = 0b1;//enabled DCAEVT1 for the ePWM module
              EPwm2Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm7Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm7Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm8Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm8Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm9Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm9Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm10Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm10Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm11Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm11Regs.TZSEL.bit.DCBEVT1 = 0b1;

              /*Clear individual OST TZ flags*/
              EPwm2Regs.TZOSTCLR.bit.OST1 = 0b1;//clear trip
              EPwm2Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm7Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm7Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm8Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm8Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm9Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm9Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm10Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm10Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm11Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm11Regs.TZOSTCLR.bit.OST2 = 0b1;

              /*Enable tripzone action*/
              EPwm2Regs.TZCTL.bit.TZA = (uint16_T)(0b10);//force to LOW
              EPwm2Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm7Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm7Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm8Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm8Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm9Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm9Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm10Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm10Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm11Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm11Regs.TZCTL.bit.TZB = (uint16_T)(0b10);

              /*Enabled Digital Compare Out A and Out B Event1*/
              //EPwm2Regs.TZCTL.bit.DCAEVT1 = 0b10; //force to LOW
              //EPwm2Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm7Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm7Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm8Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm8Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm9Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm9Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm10Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm10Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm11Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm11Regs.TZCTL.bit.DCBEVT1 = 0b10;
              EDIS;

              /* S-Function (fcgen): '<S128>/Function-Call Generator' incorporates:
               *  SubSystem: '<S128>/CLEAR_FAULTS'
               */
              /* DataStoreWrite: '<S136>/Data Store Write1' incorporates:
               *  Constant: '<S135>/Constant1'
               *  Constant: '<S136>/Constant1'
               */
              npc_controller_DWork.tz_cmpssocp = 0U;

              /* DataStoreWrite: '<S136>/Data Store Write7' incorporates:
               *  Constant: '<S136>/Constant3'
               */
              npc_controller_DWork.tfv_iphasea = false;

              /* DataStoreWrite: '<S136>/Data Store Write8' incorporates:
               *  Constant: '<S136>/Constant4'
               */
              npc_controller_DWork.tfv_iphaseb = false;

              /* DataStoreWrite: '<S136>/Data Store Write9' incorporates:
               *  Constant: '<S136>/Constant5'
               */
              npc_controller_DWork.tfv_iphasec = false;

              /* DataStoreWrite: '<S136>/Data Store Write10' incorporates:
               *  Constant: '<S136>/Constant6'
               */
              npc_controller_DWork.tz_ocp = 0U;

              /* DataStoreWrite: '<S136>/Data Store Write11' incorporates:
               *  Constant: '<S136>/Constant7'
               */
              npc_controller_DWork.tz_ovp = 0U;

              /* End of Outputs for S-Function (fcgen): '<S128>/Function-Call Generator' */
              /* End of Outputs for SubSystem: '<S121>/done' */
            } else {
              /* Outputs for IfAction SubSystem: '<S121>/cnt' incorporates:
               *  ActionPort: '<S127>/Action Port'
               */
              /* Sum: '<S127>/Add' incorporates:
               *  Constant: '<S127>/Constant'
               *  DataStoreWrite: '<S127>/Data Store Write2'
               */
              npc_controller_DWork.cnt_calib++;

              /* Sum: '<S134>/Add4' incorporates:
               *  Constant: '<S134>/Constant4'
               *  DataStoreRead: '<S134>/Data Store Read4'
               *  DataStoreWrite: '<S127>/Data Store Write5'
               *  DataTypeConversion: '<S134>/Cast To Single'
               *  Delay: '<S134>/Delay2'
               *  Product: '<S134>/Divide3'
               *  Product: '<S134>/Divide4'
               *  Sum: '<S134>/Subtract1'
               */
              npc_controller_DWork.adc_offset_va_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE / (real32_T)
                npc_controller_DWork.cnt_calib + cpu2cla_van / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S133>/Add4' incorporates:
               *  Constant: '<S133>/Constant4'
               *  DataStoreRead: '<S133>/Data Store Read4'
               *  DataStoreWrite: '<S127>/Data Store Write6'
               *  DataTypeConversion: '<S133>/Cast To Single'
               *  Delay: '<S133>/Delay2'
               *  Product: '<S133>/Divide3'
               *  Product: '<S133>/Divide4'
               *  Sum: '<S133>/Subtract1'
               */
              npc_controller_DWork.adc_offset_vb_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_j / (real32_T)
                npc_controller_DWork.cnt_calib + cpu2cla_vbn / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S132>/Add4' incorporates:
               *  Constant: '<S132>/Constant4'
               *  DataStoreRead: '<S132>/Data Store Read4'
               *  DataStoreWrite: '<S127>/Data Store Write3'
               *  DataTypeConversion: '<S132>/Cast To Single'
               *  Delay: '<S132>/Delay2'
               *  Product: '<S132>/Divide3'
               *  Product: '<S132>/Divide4'
               *  Sum: '<S132>/Subtract1'
               */
              npc_controller_DWork.adc_offset_vc_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_l / (real32_T)
                npc_controller_DWork.cnt_calib + cpu2cla_vcn / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S131>/Add4' incorporates:
               *  Constant: '<S131>/Constant4'
               *  DataStoreRead: '<S131>/Data Store Read4'
               *  DataStoreWrite: '<S127>/Data Store Write4'
               *  DataTypeConversion: '<S131>/Cast To Single'
               *  Delay: '<S131>/Delay2'
               *  Product: '<S131>/Divide3'
               *  Product: '<S131>/Divide4'
               *  Sum: '<S131>/Subtract1'
               */
              npc_controller_DWork.adc_offset_ia_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_h / (real32_T)
                npc_controller_DWork.cnt_calib + cpu2cla_ia / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S130>/Add4' incorporates:
               *  Constant: '<S130>/Constant4'
               *  DataStoreRead: '<S130>/Data Store Read4'
               *  DataStoreWrite: '<S127>/Data Store Write'
               *  DataTypeConversion: '<S130>/Cast To Single'
               *  Delay: '<S130>/Delay2'
               *  Product: '<S130>/Divide3'
               *  Product: '<S130>/Divide4'
               *  Sum: '<S130>/Subtract1'
               */
              npc_controller_DWork.adc_offset_ib_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_k / (real32_T)
                npc_controller_DWork.cnt_calib + cpu2cla_ib / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S129>/Add4' incorporates:
               *  Constant: '<S129>/Constant4'
               *  DataStoreRead: '<S129>/Data Store Read4'
               *  DataStoreWrite: '<S127>/Data Store Write1'
               *  DataTypeConversion: '<S129>/Cast To Single'
               *  Delay: '<S129>/Delay2'
               *  Product: '<S129>/Divide3'
               *  Product: '<S129>/Divide4'
               *  Sum: '<S129>/Subtract1'
               */
              npc_controller_DWork.adc_offset_ic_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_a / (real32_T)
                npc_controller_DWork.cnt_calib + cpu2cla_ic / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Merge: '<S121>/Merge' incorporates:
               *  Constant: '<S127>/Constant1'
               */
              Constant1 = false;

              /* Update for Delay: '<S134>/Delay2' incorporates:
               *  DataStoreWrite: '<S127>/Data Store Write5'
               */
              npc_controller_DWork.Delay2_DSTATE =
                npc_controller_DWork.adc_offset_va_tmp;

              /* Update for Delay: '<S133>/Delay2' incorporates:
               *  DataStoreWrite: '<S127>/Data Store Write6'
               */
              npc_controller_DWork.Delay2_DSTATE_j =
                npc_controller_DWork.adc_offset_vb_tmp;

              /* Update for Delay: '<S132>/Delay2' incorporates:
               *  DataStoreWrite: '<S127>/Data Store Write3'
               */
              npc_controller_DWork.Delay2_DSTATE_l =
                npc_controller_DWork.adc_offset_vc_tmp;

              /* Update for Delay: '<S131>/Delay2' incorporates:
               *  DataStoreWrite: '<S127>/Data Store Write4'
               */
              npc_controller_DWork.Delay2_DSTATE_h =
                npc_controller_DWork.adc_offset_ia_tmp;

              /* Update for Delay: '<S130>/Delay2' incorporates:
               *  DataStoreWrite: '<S127>/Data Store Write'
               */
              npc_controller_DWork.Delay2_DSTATE_k =
                npc_controller_DWork.adc_offset_ib_tmp;

              /* Update for Delay: '<S129>/Delay2' incorporates:
               *  DataStoreWrite: '<S127>/Data Store Write1'
               */
              npc_controller_DWork.Delay2_DSTATE_a =
                npc_controller_DWork.adc_offset_ic_tmp;

              /* End of Outputs for SubSystem: '<S121>/cnt' */
            }

            /* End of If: '<S121>/Codegen1' */
            /* End of Outputs for SubSystem: '<S112>/updateCalib' */
            npc_controller_B.calib_ok = Constant1;
            npc_controller_B.state = 0U;

            /* exit */
            /* Transition: '<S112>:540' */
            /* Transition: '<S112>:732' */
            /* Transition: '<S112>:782' */
            /* Transition: '<S112>:708' */
            /* Transition: '<S112>:667' */
            /* Transition: '<S112>:718' */
            /* Transition: '<S112>:761' */
            /* Transition: '<S112>:535' */
          }
        } else {
          /* Transition: '<S112>:602' */
          npc_controller_DWork.start_cnt++;

          /* disCmpssTz();
             exit */
          /* Transition: '<S112>:603' */
          /* Transition: '<S112>:540' */
          /* Transition: '<S112>:732' */
          /* Transition: '<S112>:782' */
          /* Transition: '<S112>:708' */
          /* Transition: '<S112>:667' */
          /* Transition: '<S112>:718' */
          /* Transition: '<S112>:761' */
          /* Transition: '<S112>:535' */
        }

        if (guard1) {
          /* Outputs for Function Call SubSystem: '<S112>/disablePwm' */
          /* Transition: '<S112>:714' */
          /* Transition: '<S112>:436' */
          /* Simulink Function 'disablePwm': '<S112>:24' */

          /* user code (Output function Body for TID3) */

          /* System '<S112>/disablePwm' */
          /*Force PWM to LOW*/
          EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

          /* End of Outputs for SubSystem: '<S112>/disablePwm' */
          npc_controller_B.eoss = false;

          /* disDigCmpMode(); */
          cpu2cla_pha_en = false;
          cpu2cla_phb_en = false;
          cpu2cla_phc_en = false;
          cpu2cla_ref = cpu2cla_vbulk;

          /* state = 3; */
          cpu2cla_pfc_ok2 = false;
          npc_controller_B.control_en = false;
          if ((!npc_controller_DWork.pfc_en) || npc_controller_B.tfv_v_UvpOvp) {
            /* Transition: '<S112>:758' */
            if (npc_controller_DWork.relayOff_cnt > 2600.0) {
              /* Transition: '<S112>:629' */
              /* 40ms delay to turn-OFF pre-charge relay */
              npc_controller_B.relay_ctrl = false;

              /* pre-charge relay OFF */
              npc_controller_DWork.relayOff_cnt = 0.0;
              npc_controller_DWork.relay_cnt = 0.0;
              npc_controller_DWork.eoss_cnt = 0.0;
              npc_controller_DWork.delay_cnt = 0.0;
            } else {
              /* Transition: '<S112>:640' */
              npc_controller_DWork.relayOff_cnt++;

              /* Transition: '<S112>:633' */
              /* Transition: '<S112>:634' */
            }

            /* Transition: '<S112>:328' */
            /* Transition: '<S112>:534' */
          } else {
            /* Transition: '<S112>:760' */
            /* Transition: '<S112>:535' */
          }
        }

        /* End of Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */

        /* DataStoreWrite: '<S12>/Data Store Write' */
        npc_controller_DWork.u16Debug1 = npc_controller_B.state;

        /* DataStoreWrite: '<S12>/Data Store Write12' */
        npc_controller_DWork.relay_ctrl = npc_controller_B.relay_ctrl;

        /* DataStoreWrite: '<S12>/Data Store Write13' */
        npc_controller_DWork.pfc_ok = cpu2cla_pfc_ok2;

        /* Logic: '<S12>/NOT' incorporates:
         *  DataStoreWrite: '<S12>/Data Store Write3'
         */
        npc_controller_DWork.ac_ok = !npc_controller_B.tfv_v_UvpOvp;

        /* S-Function (c280xgpio_di): '<S150>/PFC_EN_GPIO60' */
        {
          npc_controller_B.PFC_EN_GPIO60 = GpioDataRegs.GPBDAT.bit.GPIO60;
        }

        /* MATLABSystem: '<S151>/Validate_DI' incorporates:
         *  Constant: '<S151>/Constant'
         *  Constant: '<S151>/Constant1'
         *  DataStoreWrite: '<S12>/Data Store Write4'
         */
        /*  din -> Digital Input Signal from GPIO */
        /*  assert_logic -> true - Assert if GPIO is High and Set State */
        /*                  false - Assert if GPIO is Low and Set State */
        /*  assert_dly -> Delay in 1mS Counter to Assert Din Signal     */
        /*  deassert_dly -> Delay in 1mS Counter to DeAssert Din Signal                  */
        /* if Assert Logic is True */
        if (!npc_controller_DWork.obj_k.din_state) {
          /* Din State is Low */
          if (npc_controller_B.PFC_EN_GPIO60) {
            qY = npc_controller_DWork.obj_k.cnt + 1U;
            if (npc_controller_DWork.obj_k.cnt + 1U <
                npc_controller_DWork.obj_k.cnt) {
              qY = MAX_uint16_T;
            }

            npc_controller_DWork.obj_k.cnt = qY;
            if (npc_controller_DWork.obj_k.cnt >= 67U) {
              npc_controller_DWork.obj_k.din_state = true;

              /* Assert Signal State */
              npc_controller_DWork.obj_k.cnt = 0U;
            }
          } else {
            npc_controller_DWork.obj_k.cnt = 0U;
          }
        } else if (!npc_controller_B.PFC_EN_GPIO60) {
          qY = npc_controller_DWork.obj_k.cnt + 1U;
          if (npc_controller_DWork.obj_k.cnt + 1U <
              npc_controller_DWork.obj_k.cnt) {
            qY = MAX_uint16_T;
          }

          npc_controller_DWork.obj_k.cnt = qY;
          if (npc_controller_DWork.obj_k.cnt >= 67U) {
            npc_controller_DWork.obj_k.din_state = false;

            /* DeAssert Signal State */
            npc_controller_DWork.obj_k.cnt = 0U;
          }
        } else {
          npc_controller_DWork.obj_k.cnt = 0U;
        }

        npc_controller_DWork.pfc_en = npc_controller_DWork.obj_k.din_state;

        /* End of MATLABSystem: '<S151>/Validate_DI' */

        /* Chart: '<S111>/Chart' incorporates:
         *  Constant: '<S111>/Constant'
         *  Constant: '<S111>/Constant12'
         */
        /* Gateway: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Chart */
        /* During: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Chart */
        if (npc_controller_DWork.is_active_c20_npc_controller == 0U) {
          /* Entry: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Chart */
          npc_controller_DWork.is_active_c20_npc_controller = 1U;

          /* Entry Internal: CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Chart */
          /* Transition: '<S113>:2' */
          npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_init;

          /* Entry 'init': '<S113>:1' */
          cpu2cla_zc_a = 0.0;
        } else {
          switch (npc_controller_DWork.is_c20_npc_controller) {
           case npc_controller_IN_init:
            /* During 'init': '<S113>:1' */
            if (cpu2cla_van > 48.0F) {
              /* Transition: '<S113>:7' */
              npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_pos;

              /* Entry 'pos': '<S113>:3' */
              cpu2cla_zc_a = 0.0;
            } else if (cpu2cla_van < -48.0F) {
              /* Transition: '<S113>:9' */
              npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_neg;

              /* Entry 'neg': '<S113>:4' */
              cpu2cla_zc_a = 0.0;
            } else {
              cpu2cla_zc_a = 0.0;
            }
            break;

           case npc_controller_IN_n2p:
            /* During 'n2p': '<S113>:6' */
            if (cpu2cla_van > 48.0F) {
              /* Transition: '<S113>:12' */
              npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_pos;

              /* Entry 'pos': '<S113>:3' */
              cpu2cla_zc_a = 0.0;
            } else {
              cpu2cla_zc_a = 1.0;
            }
            break;

           case npc_controller_IN_neg:
            /* During 'neg': '<S113>:4' */
            if (cpu2cla_van < -96.8F) {
              /* Transition: '<S113>:22' */
              npc_controller_DWork.is_c20_npc_controller =
                npc_controller_IN_neg_peak;

              /* Entry 'neg_peak': '<S113>:18' */
              cpu2cla_zc_a = 0.0;
            } else {
              cpu2cla_zc_a = 0.0;
            }
            break;

           case npc_controller_IN_neg_peak:
            /* During 'neg_peak': '<S113>:18' */
            if (cpu2cla_van > -48.0F) {
              /* Transition: '<S113>:11' */
              npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_n2p;

              /* Entry 'n2p': '<S113>:6' */
              cpu2cla_zc_a = 1.0;
            } else {
              cpu2cla_zc_a = 0.0;
            }
            break;

           case npc_controller_IN_p2n:
            /* During 'p2n': '<S113>:5' */
            if (cpu2cla_van < -48.0F) {
              /* Transition: '<S113>:25' */
              npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_neg;

              /* Entry 'neg': '<S113>:4' */
              cpu2cla_zc_a = 0.0;
            } else {
              cpu2cla_zc_a = 1.0;
            }
            break;

           case npc_controller_IN_pos:
            /* During 'pos': '<S113>:3' */
            if (cpu2cla_van > 96.8F) {
              /* Transition: '<S113>:19' */
              npc_controller_DWork.is_c20_npc_controller =
                npc_controller_IN_pos_peak;

              /* Entry 'pos_peak': '<S113>:17' */
              cpu2cla_zc_a = 0.0;
            } else {
              cpu2cla_zc_a = 0.0;
            }
            break;

           default:
            /* During 'pos_peak': '<S113>:17' */
            if (cpu2cla_van < 48.0F) {
              /* Transition: '<S113>:23' */
              npc_controller_DWork.is_c20_npc_controller = npc_controller_IN_p2n;

              /* Entry 'p2n': '<S113>:5' */
              cpu2cla_zc_a = 1.0;
            } else {
              cpu2cla_zc_a = 0.0;
            }
            break;
          }
        }

        /* End of Chart: '<S111>/Chart' */

        /* SignalConversion generated from: '<S12>/angle' */
        cpu2cla_angle = 0.0;

        /* End of Outputs for S-Function (fcgen): '<S2>/Function-Call Generator' */

        /* DataStoreWrite: '<S2>/Data Store Write' */
        npc_controller_DWork.control_en = npc_controller_B.control_en;
      }

      /* End of Outputs for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
    }
  }
}

/* Hardware Interrupt Block: '<Root>/C28x Hardware Interrupt2' */
void isr_int9pie5_task_fcn(void)
{
  if (1 == runModel) {
    /* Call the system: <Root>/CANRX */
    {
      /* S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
      npc_controller_CANRX(&npc_controller_DWork.b05_MB10Received,
                           &npc_controller_DWork.b06_MB11Received,
                           &npc_controller_DWork.b07_MB12Received,
                           npc_controller_DWork.u8CanDataRx10,
                           npc_controller_DWork.u8CanDataRx11,
                           npc_controller_DWork.u8CanDataRx12,
                           &npc_controller_B.CANRX);

      /* End of Outputs for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
    }
  }
}

/* Idle Task Block: '<S152>/Idle Task' */
void idle_num1_task_fcn(void)
{
  /* Call the system: <S152>/IDLE */
  {
    /* S-Function (idletask): '<S152>/Idle Task' */

    /* Output and update for function-call system: '<S152>/IDLE' */
    {
      real_T tmp;
      real_T tmp_e;
      real_T tmp_i;
      real_T tmp_p;
      real32_T rtb_Saturation;
      real32_T rtb_Sum;
      real32_T rtb_Sum_c;
      real32_T rtb_Sum_kn;

      /* S-Function (fcgen): '<S155>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S155>/idle_task'
       */
      /* SwitchCase: '<S261>/Switch Case' incorporates:
       *  DataStoreRead: '<S261>/Data Store Read'
       *  DataStoreRead: '<S264>/Data Store Read10'
       *  DataStoreRead: '<S264>/Data Store Read11'
       *  DataStoreRead: '<S264>/Data Store Read32'
       *  DataStoreRead: '<S264>/Data Store Read5'
       *  DataStoreRead: '<S264>/Data Store Read6'
       *  DataStoreRead: '<S264>/Data Store Read7'
       *  DataStoreRead: '<S264>/Data Store Read8'
       *  DataStoreRead: '<S264>/Data Store Read9'
       *  DataStoreRead: '<S267>/Data Store Read10'
       *  DataStoreRead: '<S267>/Data Store Read13'
       *  DataStoreRead: '<S267>/Data Store Read5'
       *  DataStoreRead: '<S267>/Data Store Read7'
       *  DataTypeConversion: '<S264>/Cast To Boolean4'
       *  DataTypeConversion: '<S264>/Cast To Boolean5'
       *  DataTypeConversion: '<S264>/Cast To Boolean6'
       *  DataTypeConversion: '<S264>/Cast To Boolean7'
       *  DataTypeConversion: '<S264>/Cast To Boolean8'
       *  DataTypeConversion: '<S267>/Data Type Conversion1'
       *  DataTypeConversion: '<S267>/Data Type Conversion2'
       *  DataTypeConversion: '<S267>/Data Type Conversion3'
       *  DataTypeConversion: '<S267>/Data Type Conversion4'
       *  DataTypeConversion: '<S267>/Data Type Conversion5'
       *  DataTypeConversion: '<S267>/Data Type Conversion6'
       *  DataTypeConversion: '<S267>/Data Type Conversion7'
       *  DataTypeConversion: '<S267>/Data Type Conversion8'
       */
      switch ((int32_T)npc_controller_DWork.cnt_idle) {
       case 0L:
        /* Outputs for IfAction SubSystem: '<S261>/report_status_flag_bits' incorporates:
         *  ActionPort: '<S267>/Action Port'
         */
        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift1' */
        npc_controller_BitShift1((uint16_T)npc_controller_DWork.pfc_en,
          &npc_controller_B.BitShift1);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift1' */

        /* DataTypeConversion: '<S267>/Data Type Conversion2' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read10'
         *  DataStoreRead: '<S267>/Data Store Read12'
         *  DataTypeConversion: '<S267>/Data Type Conversion1'
         */
        tmp_i = floor(npc_controller_DWork.rec_en);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift2' */
        npc_controller_BitShift2(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift2);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift2' */

        /* DataTypeConversion: '<S267>/Data Type Conversion3' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read4'
         *  DataTypeConversion: '<S267>/Data Type Conversion2'
         */
        tmp_i = floor(npc_controller_DWork.inv_en);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift3' */
        npc_controller_BitShift3(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift3);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift3' */

        /* DataTypeConversion: '<S267>/Data Type Conversion4' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read14'
         *  DataTypeConversion: '<S267>/Data Type Conversion3'
         */
        tmp_i = floor(npc_controller_DWork.can_on_cmd);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift6' */
        npc_controller_BitShift6(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift6);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift6' */

        /* DataTypeConversion: '<S267>/Data Type Conversion5' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read1'
         *  DataTypeConversion: '<S267>/Data Type Conversion4'
         */
        tmp_i = floor(npc_controller_DWork.pos_seq);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift4' */
        npc_controller_BitShift4(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift4);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift4' */

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift5' */
        npc_controller_BitShift5((uint16_T)npc_controller_DWork.relay_ctrl,
          &npc_controller_B.BitShift5);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift5' */

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift7' */
        npc_controller_BitShift7((uint16_T)npc_controller_DWork.ac_ok,
          &npc_controller_B.BitShift7);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift7' */

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift8' */
        npc_controller_BitShift8((uint16_T)npc_controller_DWork.pfc_ok,
          &npc_controller_B.BitShift8);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift8' */

        /* DataTypeConversion: '<S267>/Data Type Conversion' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read13'
         *  DataStoreRead: '<S267>/Data Store Read5'
         *  DataStoreRead: '<S267>/Data Store Read6'
         *  DataStoreRead: '<S267>/Data Store Read7'
         *  DataTypeConversion: '<S267>/Data Type Conversion5'
         *  DataTypeConversion: '<S267>/Data Type Conversion6'
         *  DataTypeConversion: '<S267>/Data Type Conversion7'
         *  DataTypeConversion: '<S267>/Data Type Conversion8'
         */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S338>:1' */
        /* '<S338>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S328>:1' */
        /* '<S328>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S329>:1' */
        /* '<S329>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S330>:1' */
        /* '<S330>:1:6' */
        tmp_i = floor(npc_controller_DWork.state_control);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* DataTypeConversion: '<S267>/Data Type Conversion9' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read2'
         */
        tmp = floor(npc_controller_DWork.clllc_ok);
        if (rtIsNaN(tmp) || rtIsInf(tmp)) {
          tmp = 0.0;
        } else {
          tmp = fmod(tmp, 65536.0);
        }

        /* DataTypeConversion: '<S267>/Data Type Conversion10' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read3'
         */
        tmp_p = floor(npc_controller_DWork.npc_fault);
        if (rtIsNaN(tmp_p) || rtIsInf(tmp_p)) {
          tmp_p = 0.0;
        } else {
          tmp_p = fmod(tmp_p, 65536.0);
        }

        /* DataTypeConversion: '<S267>/Data Type Conversion11' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read'
         */
        rtb_Saturation = (real32_T)floor(npc_controller_DWork.otp_fault);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 65536.0);
        }

        /* DataTypeConversion: '<S267>/Data Type Conversion12' incorporates:
         *  DataStoreRead: '<S267>/Data Store Read9'
         */
        tmp_e = floor(npc_controller_DWork.can_timeout);
        if (rtIsNaN(tmp_e) || rtIsInf(tmp_e)) {
          tmp_e = 0.0;
        } else {
          tmp_e = fmod(tmp_e, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift9' */
        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift10' */
        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift11' */
        /* Outputs for Atomic SubSystem: '<S267>/Bit Shift12' */
        /* Sum: '<S267>/Add' incorporates:
         *  DataStoreWrite: '<S267>/Data Store Write'
         *  DataTypeConversion: '<S267>/Data Type Conversion'
         *  DataTypeConversion: '<S267>/Data Type Conversion10'
         *  DataTypeConversion: '<S267>/Data Type Conversion11'
         *  DataTypeConversion: '<S267>/Data Type Conversion12'
         *  DataTypeConversion: '<S267>/Data Type Conversion9'
         *  MATLAB Function: '<S316>/bit_shift'
         *  MATLAB Function: '<S317>/bit_shift'
         *  MATLAB Function: '<S318>/bit_shift'
         *  MATLAB Function: '<S326>/bit_shift'
         */
        npc_controller_DWork.sPriStatus = ((((((((((((tmp_i < 0.0 ? (uint16_T)
          -(int16_T)(uint16_T)-tmp_i : (uint16_T)tmp_i) +
          npc_controller_B.BitShift1.y) + npc_controller_B.BitShift2.y) +
          npc_controller_B.BitShift3.y) + npc_controller_B.BitShift6.y) +
          npc_controller_B.BitShift4.y) + npc_controller_B.BitShift5.y) +
          npc_controller_B.BitShift7.y) + npc_controller_B.BitShift8.y) + ((tmp <
          0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)tmp) << 12)) +
          ((tmp_p < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp_p : (uint16_T)tmp_p)
           << 13)) + ((rtb_Saturation < 0.0F ? (uint16_T)-(int16_T)(uint16_T)
                       -rtb_Saturation : (uint16_T)rtb_Saturation) << 14)) +
          ((tmp_e < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp_e : (uint16_T)tmp_e)
           << 15);

        /* End of Outputs for SubSystem: '<S267>/Bit Shift12' */
        /* End of Outputs for SubSystem: '<S267>/Bit Shift11' */
        /* End of Outputs for SubSystem: '<S267>/Bit Shift10' */
        /* End of Outputs for SubSystem: '<S267>/Bit Shift9' */
        /* End of Outputs for SubSystem: '<S261>/report_status_flag_bits' */
        break;

       case 1L:
        /* Outputs for IfAction SubSystem: '<S261>/watchdog' incorporates:
         *  ActionPort: '<S268>/Action Port'
         */
        /* S-Function (c28xwatchdog): '<S268>/Watchdog' */
        {
          KickDog();
        }

        /* End of Outputs for SubSystem: '<S261>/watchdog' */
        break;

       case 2L:
        /* Outputs for IfAction SubSystem: '<S261>/hkeep' incorporates:
         *  ActionPort: '<S265>/Action Port'
         */
        /* S-Function (fcgen): '<S265>/Function-Call Generator1' incorporates:
         *  SubSystem: '<S265>/tz'
         */

        /* user code (Output function Body for TID5) */

        /* System '<S265>/tz' */
        npc_controller_DWork.tz_ocp = EPwm2Regs.TZOSTFLG.bit.OST1;
        npc_controller_DWork.tz_ovp = EPwm2Regs.TZOSTFLG.bit.OST2;

        /*npc_controller_DWork.tz_cmpssocp = EPwm2Regs.TZOSTFLG.bit.DCAEVT1 | EPwm2Regs.TZOSTFLG.bit.DCBEVT1 | EPwm7Regs.TZOSTFLG.bit.DCAEVT1 | EPwm7Regs.TZOSTFLG.bit.DCBEVT1 | EPwm8Regs.TZOSTFLG.bit.DCAEVT1 | EPwm8Regs.TZOSTFLG.bit.DCBEVT1 | EPwm9Regs.TZOSTFLG.bit.DCAEVT1 | EPwm9Regs.TZOSTFLG.bit.DCBEVT1| EPwm10Regs.TZOSTFLG.bit.DCAEVT1 | EPwm10Regs.TZOSTFLG.bit.DCBEVT1 | EPwm11Regs.TZOSTFLG.bit.DCAEVT1 | EPwm11Regs.TZOSTFLG.bit.DCBEVT1;*/
        /*npc_controller_DWork.tz_cmpssocp = EPwm2Regs.TZFLG.bit.DCAEVT1 | EPwm2Regs.TZFLG.bit.DCBEVT1 | EPwm7Regs.TZFLG.bit.DCAEVT1 | EPwm7Regs.TZFLG.bit.DCBEVT1 | EPwm8Regs.TZFLG.bit.DCAEVT1 | EPwm8Regs.TZFLG.bit.DCBEVT1 | EPwm9Regs.TZFLG.bit.DCAEVT1 | EPwm9Regs.TZFLG.bit.DCBEVT1| EPwm10Regs.TZFLG.bit.DCAEVT1 | EPwm10Regs.TZFLG.bit.DCBEVT1 | EPwm11Regs.TZFLG.bit.DCAEVT1 | EPwm11Regs.TZFLG.bit.DCBEVT1;*/
        /*npc_controller_DWork.tz_ocp = EPwm7Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm7Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm8Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm8Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm9Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm9Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm10Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm10Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm11Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm11Regs.TZOSTFLG.bit.OST2;*/

        /* S-Function (fcgen): '<S265>/Function-Call Generator1' incorporates:
         *  SubSystem: '<S265>/tfv'
         */
        /* Chart: '<S291>/hkeep1' incorporates:
         *  DataStoreRead: '<S294>/Data Store Read'
         *  DataStoreRead: '<S295>/Data Store Read'
         *  DataStoreRead: '<S296>/Data Store Read'
         *  DataStoreRead: '<S297>/Data Store Read'
         *  DataStoreRead: '<S298>/Data Store Read'
         *  DataStoreRead: '<S299>/Data Store Read'
         *  DataTypeConversion: '<S294>/Data Type Conversion'
         *  DataTypeConversion: '<S295>/Data Type Conversion'
         *  DataTypeConversion: '<S296>/Data Type Conversion'
         *  DataTypeConversion: '<S297>/Data Type Conversion'
         *  DataTypeConversion: '<S298>/Data Type Conversion'
         *  DataTypeConversion: '<S299>/Data Type Conversion'
         */
        /* Gateway: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
        /* During: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
        if (npc_controller_DWork.is_active_c23_npc_controller == 0U) {
          /* Entry: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
          npc_controller_DWork.is_active_c23_npc_controller = 1U;

          /* Entry Internal: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
          /* Transition: '<S293>:390' */
          /* Entry 'HKEEP': '<S293>:1' */
        } else {
          /* During 'HKEEP': '<S293>:1' */
          npc_controller_B.input = (uint16_T)npc_controller_DWork.adc_va;
          npc_controller_B.assert_lim = 2940U;
          npc_controller_B.assert_vld = 3U;
          npc_controller_B.deassert_lim = 1U;
          npc_controller_B.deassert_vld = 3U;

          /* Outputs for Function Call SubSystem: '<S293>/HKEEP.tfvVa' */
          /* Simulink Function 'tfvVa': '<S293>:304' */
          npc_controller_MATLABSystem(npc_controller_B.input, 2940U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem,
            &npc_controller_DWork.MATLABSystem);
          npc_controller_DWork.tfv_va =
            (npc_controller_B.MATLABSystem.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S293>/HKEEP.tfvVa' */
          /* 400Vac,pk */
          npc_controller_B.input_a = (uint16_T)npc_controller_DWork.adc_vb;
          npc_controller_B.assert_lim_h = 2940U;
          npc_controller_B.assert_vld_f = 3U;
          npc_controller_B.deassert_lim_c = 1U;
          npc_controller_B.deassert_vld_o = 3U;

          /* Outputs for Function Call SubSystem: '<S293>/HKEEP.tfvVb' */
          /* Simulink Function 'tfvVb': '<S293>:311' */
          npc_controller_MATLABSystem(npc_controller_B.input_a, 2940U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n,
            &npc_controller_DWork.MATLABSystem_n);
          npc_controller_DWork.tfv_vb =
            (npc_controller_B.MATLABSystem_n.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S293>/HKEEP.tfvVb' */
          /* 400Vac,pk */
          npc_controller_B.input_n = (uint16_T)npc_controller_DWork.adc_vc;
          npc_controller_B.assert_lim_c = 2940U;
          npc_controller_B.assert_vld_d = 3U;
          npc_controller_B.deassert_lim_e = 1U;
          npc_controller_B.deassert_vld_n = 3U;

          /* Outputs for Function Call SubSystem: '<S293>/HKEEP.tfvVc' */
          /* Simulink Function 'tfvVc': '<S293>:318' */
          npc_controller_MATLABSystem(npc_controller_B.input_n, 2940U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2,
            &npc_controller_DWork.MATLABSystem_n2);
          npc_controller_DWork.tfv_vc =
            (npc_controller_B.MATLABSystem_n2.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S293>/HKEEP.tfvVc' */
          /* 400Vac,pk
             tfv_iphasea = tfvIphaseA(uint16(adc_iphasea), uint16(2100), uint16(1), uint16(1), uint16(3)); //2A
             tfv_iphaseb = tfvIphaseB(uint16(adc_iphaseb), uint16(2100), uint16(1), uint16(1), uint16(3)); //2A
             tfv_iphasec = tfvIphaseC(uint16(adc_iphasec), uint16(2100), uint16(1), uint16(1), uint16(3)); //2A */
          npc_controller_B.input_j = (uint16_T)npc_controller_DWork.adc_vbulk;
          npc_controller_B.assert_lim_p = 3821U;
          npc_controller_B.assert_vld_h = 3U;
          npc_controller_B.deassert_lim_b = 1U;
          npc_controller_B.deassert_vld_e = 3U;

          /* Outputs for Function Call SubSystem: '<S293>/HKEEP.tfvVbulk' */
          /* Simulink Function 'tfvVbulk': '<S293>:297' */
          npc_controller_MATLABSystem(npc_controller_B.input_j, 3821U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2n,
            &npc_controller_DWork.MATLABSystem_n2n);
          npc_controller_DWork.tfv_vbulk =
            (npc_controller_B.MATLABSystem_n2n.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S293>/HKEEP.tfvVbulk' */
          /* 850V */
          npc_controller_B.input_m = (uint16_T)npc_controller_DWork.adc_vmid;
          npc_controller_B.assert_lim_b = 3443U;
          npc_controller_B.assert_vld_m = 3U;
          npc_controller_B.deassert_lim_p = 1U;
          npc_controller_B.deassert_vld_c = 3U;

          /* Outputs for Function Call SubSystem: '<S293>/HKEEP.tfvVmid' */
          /* Simulink Function 'tfvVmid': '<S293>:71' */
          npc_controller_MATLABSystem(npc_controller_B.input_m, 3443U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2nv,
            &npc_controller_DWork.MATLABSystem_n2nv);
          npc_controller_DWork.tfv_vmid =
            (npc_controller_B.MATLABSystem_n2nv.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S293>/HKEEP.tfvVmid' */
          /* 430V */
          npc_controller_B.input_ah = (uint16_T)npc_controller_DWork.adc_vaux;
          npc_controller_B.assert_lim_m = 3722U;
          npc_controller_B.assert_vld_k = 3U;
          npc_controller_B.deassert_lim_py = 1U;
          npc_controller_B.deassert_vld_j = 3U;

          /* Outputs for Function Call SubSystem: '<S293>/HKEEP.tfvVaux' */
          /* Simulink Function 'tfvVaux': '<S293>:389' */
          npc_controller_MATLABSystem(npc_controller_B.input_ah, 3722U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2nvq,
            &npc_controller_DWork.MATLABSystem_n2nvq);
          npc_controller_DWork.tfv_vaux =
            (npc_controller_B.MATLABSystem_n2nvq.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S293>/HKEEP.tfvVaux' */
          /* 3V */
        }

        /* End of Chart: '<S291>/hkeep1' */
        /* End of Outputs for S-Function (fcgen): '<S265>/Function-Call Generator1' */
        /* End of Outputs for SubSystem: '<S261>/hkeep' */
        break;

       case 3L:
        /* Outputs for IfAction SubSystem: '<S261>/report_adc' incorporates:
         *  ActionPort: '<S266>/Action Port'
         */
        /* Sum: '<S301>/Sum' incorporates:
         *  Delay: '<S301>/Delay'
         *  Delay: '<S301>/Delay1'
         *  Gain: '<S301>/1 - Lambda'
         *  Gain: '<S301>/Lambda'
         */
        rtb_Sum = 0.008F * npc_controller_DWork.Delay1_DSTATE + 0.992F *
          npc_controller_DWork.Delay_DSTATE;

        /* DataTypeConversion: '<S266>/Cast To Single3' incorporates:
         *  DataStoreWrite: '<S266>/Data Store Write3'
         */
        rtb_Saturation = (real32_T)floor(rtb_Sum);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 256.0);
        }

        npc_controller_DWork.u8TnpcB = (uint16_T)(int16_T)rtb_Saturation & 255U;

        /* End of DataTypeConversion: '<S266>/Cast To Single3' */

        /* Sum: '<S302>/Sum' incorporates:
         *  Delay: '<S302>/Delay'
         *  Delay: '<S302>/Delay1'
         *  Gain: '<S302>/1 - Lambda'
         *  Gain: '<S302>/Lambda'
         */
        rtb_Sum_c = 0.008F * npc_controller_DWork.Delay1_DSTATE_e + 0.992F *
          npc_controller_DWork.Delay_DSTATE_e;

        /* DataTypeConversion: '<S266>/Cast To Single4' incorporates:
         *  DataStoreWrite: '<S266>/Data Store Write4'
         */
        rtb_Saturation = (real32_T)floor(rtb_Sum_c);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 256.0);
        }

        npc_controller_DWork.u8TnpcC = (uint16_T)(int16_T)rtb_Saturation & 255U;

        /* End of DataTypeConversion: '<S266>/Cast To Single4' */

        /* Sum: '<S300>/Sum' incorporates:
         *  Delay: '<S300>/Delay'
         *  Delay: '<S300>/Delay1'
         *  Gain: '<S300>/1 - Lambda'
         *  Gain: '<S300>/Lambda'
         */
        rtb_Sum_kn = 0.008F * npc_controller_DWork.Delay1_DSTATE_eo + 0.992F *
          npc_controller_DWork.Delay_DSTATE_h;

        /* DataTypeConversion: '<S266>/Cast To Single2' incorporates:
         *  DataStoreWrite: '<S266>/Data Store Write'
         */
        rtb_Saturation = (real32_T)floor(rtb_Sum_kn);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 256.0);
        }

        npc_controller_DWork.u8TnpcA = (uint16_T)(int16_T)rtb_Saturation & 255U;

        /* End of DataTypeConversion: '<S266>/Cast To Single2' */

        /* Sum: '<S304>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read23'
         *  DataStoreRead: '<S266>/Data Store Read31'
         */
        rtb_Saturation = npc_controller_DWork.rms_ia -
          npc_controller_DWork.f32OffsetLineCurrentCS;

        /* Saturate: '<S304>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S304>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read'
         *  DataStoreWrite: '<S266>/Data Store Write13'
         *  Saturate: '<S304>/Saturation'
         */
        npc_controller_DWork.f32IinA = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentCS;

        /* Sum: '<S307>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read2'
         *  DataStoreRead: '<S266>/Data Store Read25'
         */
        rtb_Saturation = npc_controller_DWork.rms_ib -
          npc_controller_DWork.f32OffsetLineCurrentCS;

        /* Saturate: '<S307>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S307>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read1'
         *  DataStoreWrite: '<S266>/Data Store Write12'
         *  Saturate: '<S307>/Saturation'
         */
        npc_controller_DWork.f32IinB = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentCS;

        /* Sum: '<S313>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read13'
         *  DataStoreRead: '<S266>/Data Store Read7'
         */
        rtb_Saturation = npc_controller_DWork.rms_vb -
          npc_controller_DWork.f32OffsetLineVoltage;

        /* Saturate: '<S313>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S313>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read10'
         *  DataStoreWrite: '<S266>/Data Store Write18'
         *  Saturate: '<S313>/Saturation'
         */
        npc_controller_DWork.f32VinB = rtb_Saturation *
          npc_controller_DWork.f32GainLineVoltage;

        /* Product: '<S314>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read11'
         *  DataStoreRead: '<S266>/Data Store Read36'
         *  DataStoreWrite: '<S266>/Data Store Write42'
         */
        npc_controller_DWork.f32Vpfc = npc_controller_DWork.adc_vbulk *
          npc_controller_DWork.f32GainVbulk;

        /* Sum: '<S306>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read15'
         *  DataStoreRead: '<S266>/Data Store Read9'
         */
        rtb_Saturation = npc_controller_DWork.rms_vc -
          npc_controller_DWork.f32OffsetLineVoltage;

        /* Saturate: '<S306>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S306>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read12'
         *  DataStoreWrite: '<S266>/Data Store Write45'
         *  Saturate: '<S306>/Saturation'
         */
        npc_controller_DWork.f32VinC = rtb_Saturation *
          npc_controller_DWork.f32GainLineVoltage;

        /* Gain: '<S266>/Gain' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read14'
         *  DataStoreWrite: '<S266>/Data Store Write44'
         */
        npc_controller_DWork.f32Vaux = 0.000805860793F *
          npc_controller_DWork.adc_vaux;

        /* Product: '<S305>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read16'
         *  DataStoreRead: '<S266>/Data Store Read37'
         *  DataStoreWrite: '<S266>/Data Store Write41'
         */
        npc_controller_DWork.f32VpfcMid = npc_controller_DWork.adc_vmid *
          npc_controller_DWork.f32GainVmid;

        /* Sum: '<S309>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read17'
         *  DataStoreRead: '<S266>/Data Store Read19'
         */
        rtb_Saturation = npc_controller_DWork.rms_iphasea -
          npc_controller_DWork.f32OffsetLineCurrentHE;

        /* Saturate: '<S309>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S309>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read18'
         *  DataStoreWrite: '<S266>/Data Store Write43'
         *  Saturate: '<S309>/Saturation'
         */
        npc_controller_DWork.f32IphaseA = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentHE;

        /* Sum: '<S312>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read20'
         *  DataStoreRead: '<S266>/Data Store Read35'
         */
        rtb_Saturation = npc_controller_DWork.rms_iphasec -
          npc_controller_DWork.f32OffsetLineCurrentHE;

        /* Saturate: '<S312>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S312>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read34'
         *  DataStoreWrite: '<S266>/Data Store Write40'
         *  Saturate: '<S312>/Saturation'
         */
        npc_controller_DWork.f32IphaseC = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentHE;

        /* Sum: '<S310>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read22'
         *  DataStoreRead: '<S266>/Data Store Read33'
         */
        rtb_Saturation = npc_controller_DWork.rms_iphaseb -
          npc_controller_DWork.f32OffsetLineCurrentHE;

        /* Saturate: '<S310>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S310>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read32'
         *  DataStoreWrite: '<S266>/Data Store Write23'
         *  Saturate: '<S310>/Saturation'
         */
        npc_controller_DWork.f32IphaseB = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentHE;

        /* Sum: '<S308>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read27'
         *  DataStoreRead: '<S266>/Data Store Read6'
         */
        rtb_Saturation = npc_controller_DWork.rms_ic -
          npc_controller_DWork.f32OffsetLineCurrentCS;

        /* Saturate: '<S308>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S308>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read4'
         *  DataStoreWrite: '<S266>/Data Store Write24'
         *  Saturate: '<S308>/Saturation'
         */
        npc_controller_DWork.f32IinC = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentCS;

        /* Sum: '<S311>/Subtract' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read3'
         *  DataStoreRead: '<S266>/Data Store Read5'
         */
        rtb_Saturation = npc_controller_DWork.rms_va -
          npc_controller_DWork.f32OffsetLineVoltage;

        /* Saturate: '<S311>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S311>/Product6' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read8'
         *  DataStoreWrite: '<S266>/Data Store Write19'
         *  Saturate: '<S311>/Saturation'
         */
        npc_controller_DWork.f32VinA = rtb_Saturation *
          npc_controller_DWork.f32GainLineVoltage;

        /* Chart: '<S266>/OTP' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read41'
         *  DataStoreRead: '<S266>/Data Store Read42'
         *  DataStoreRead: '<S266>/Data Store Read43'
         */
        /* Gateway: IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP */
        /* During: IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP */
        /* Entry Internal: IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP */
        /* Transition: '<S303>:17' */
        if (((int16_T)npc_controller_DWork.u8TnpcA > 90) || ((int16_T)
             npc_controller_DWork.u8TnpcB > 90) || ((int16_T)
             npc_controller_DWork.u8TnpcC > 90)) {
          /* Transition: '<S303>:15' */
          /* Transition: '<S303>:16' */
          npc_controller_B.tfv_v_Otp = 1.0F;

          /* Transition: '<S303>:14' */
        } else if (((int16_T)npc_controller_DWork.u8TnpcA < 80) && ((int16_T)
                    npc_controller_DWork.u8TnpcB < 80) && ((int16_T)
                    npc_controller_DWork.u8TnpcC < 80)) {
          /* Transition: '<S303>:10' */
          /* Transition: '<S303>:11' */
          npc_controller_B.tfv_v_Otp = 0.0F;
        } else {
          /* Transition: '<S303>:8' */
          /* Transition: '<S303>:9' */

          /* Transition: '<S303>:12' */
        }

        /* End of Chart: '<S266>/OTP' */

        /* DataStoreWrite: '<S266>/Data Store Write5' */
        npc_controller_DWork.otp_fault = npc_controller_B.tfv_v_Otp;

        /* S-Function (c280xgpio_do): '<S266>/GPIO86' incorporates:
         *  Constant: '<S266>/Constant8'
         */
        {
          GpioDataRegs.GPCTOGGLE.bit.GPIO86 = (uint16_T)((1.0F) != 0);
        }

        /* Update for Delay: '<S301>/Delay1' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read28'
         *  Lookup_n-D: '<S266>/1-D Lookup Table1'
         */
        npc_controller_DWork.Delay1_DSTATE = look1_iflf_binlxpw
          (npc_controller_DWork.adc_temp_npcb, npc_controller_ConstP.pooled30,
           npc_controller_ConstP.pooled29, 190UL);

        /* Update for Delay: '<S301>/Delay' */
        npc_controller_DWork.Delay_DSTATE = rtb_Sum;

        /* Update for Delay: '<S302>/Delay1' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read29'
         *  Lookup_n-D: '<S266>/1-D Lookup Table2'
         */
        npc_controller_DWork.Delay1_DSTATE_e = look1_iflf_binlxpw
          (npc_controller_DWork.adc_temp_npcc, npc_controller_ConstP.pooled30,
           npc_controller_ConstP.pooled29, 190UL);

        /* Update for Delay: '<S302>/Delay' */
        npc_controller_DWork.Delay_DSTATE_e = rtb_Sum_c;

        /* Update for Delay: '<S300>/Delay1' incorporates:
         *  DataStoreRead: '<S266>/Data Store Read26'
         *  Lookup_n-D: '<S266>/1-D Lookup Table3'
         */
        npc_controller_DWork.Delay1_DSTATE_eo = look1_iflf_binlxpw
          (npc_controller_DWork.adc_temp_npca, npc_controller_ConstP.pooled30,
           npc_controller_ConstP.pooled29, 190UL);

        /* Update for Delay: '<S300>/Delay' */
        npc_controller_DWork.Delay_DSTATE_h = rtb_Sum_kn;

        /* End of Outputs for SubSystem: '<S261>/report_adc' */
        break;

       case 4L:
       case 5L:
        break;

       case 6L:
        /* Outputs for IfAction SubSystem: '<S261>/fault_bitwise' incorporates:
         *  ActionPort: '<S264>/Action Port'
         */
        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift3' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S280>:1' */
        /* '<S280>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S281>:1' */
        /* '<S281>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S282>:1' */
        /* '<S282>:1:6' */
        npc_controller_BitShift1((uint16_T)npc_controller_DWork.tfv_iphaseb,
          &npc_controller_B.BitShift3_g);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift3' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift4' */
        npc_controller_BitShift2((uint16_T)npc_controller_DWork.tfv_iphasec,
          &npc_controller_B.BitShift4_b);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift4' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift5' */
        npc_controller_BitShift3((uint16_T)npc_controller_DWork.tfv_vbulk,
          &npc_controller_B.BitShift5_o);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift5' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift6' */
        npc_controller_BitShift6((uint16_T)npc_controller_DWork.tfv_vmid,
          &npc_controller_B.BitShift6_l);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift6' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift7' */
        npc_controller_BitShift4((uint16_T)npc_controller_DWork.tfv_vaux,
          &npc_controller_B.BitShift7_h);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift7' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift8' */
        npc_controller_BitShift5(npc_controller_DWork.tz_ocp,
          &npc_controller_B.BitShift8_h);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift8' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift9' */
        npc_controller_BitShift7(npc_controller_DWork.tz_ovp,
          &npc_controller_B.BitShift9_l);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift9' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift27' */
        npc_controller_BitShift8(npc_controller_DWork.tz_cmpssocp,
          &npc_controller_B.BitShift27);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift27' */

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift' */
        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift1' */
        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift2' */
        /* Sum: '<S264>/Add' incorporates:
         *  DataStoreRead: '<S264>/Data Store Read1'
         *  DataStoreRead: '<S264>/Data Store Read10'
         *  DataStoreRead: '<S264>/Data Store Read11'
         *  DataStoreRead: '<S264>/Data Store Read2'
         *  DataStoreRead: '<S264>/Data Store Read3'
         *  DataStoreRead: '<S264>/Data Store Read32'
         *  DataStoreRead: '<S264>/Data Store Read4'
         *  DataStoreRead: '<S264>/Data Store Read5'
         *  DataStoreRead: '<S264>/Data Store Read6'
         *  DataStoreRead: '<S264>/Data Store Read7'
         *  DataStoreRead: '<S264>/Data Store Read8'
         *  DataStoreRead: '<S264>/Data Store Read9'
         *  DataStoreWrite: '<S264>/Data Store Write1'
         *  DataTypeConversion: '<S264>/Cast To Boolean'
         *  DataTypeConversion: '<S264>/Cast To Boolean1'
         *  DataTypeConversion: '<S264>/Cast To Boolean2'
         *  DataTypeConversion: '<S264>/Cast To Boolean3'
         *  DataTypeConversion: '<S264>/Cast To Boolean4'
         *  DataTypeConversion: '<S264>/Cast To Boolean5'
         *  DataTypeConversion: '<S264>/Cast To Boolean6'
         *  DataTypeConversion: '<S264>/Cast To Boolean7'
         *  DataTypeConversion: '<S264>/Cast To Boolean8'
         *  MATLAB Function: '<S269>/bit_shift'
         *  MATLAB Function: '<S270>/bit_shift'
         *  MATLAB Function: '<S271>/bit_shift'
         */
        npc_controller_DWork.u16Debug0 = ((((((((((((uint16_T)
          npc_controller_DWork.tfv_vb << 1) + npc_controller_DWork.tfv_va) +
          ((uint16_T)npc_controller_DWork.tfv_vc << 2)) + ((uint16_T)
          npc_controller_DWork.tfv_iphasea << 3)) +
          npc_controller_B.BitShift3_g.y) + npc_controller_B.BitShift4_b.y) +
          npc_controller_B.BitShift5_o.y) + npc_controller_B.BitShift6_l.y) +
          npc_controller_B.BitShift7_h.y) + npc_controller_B.BitShift8_h.y) +
          npc_controller_B.BitShift9_l.y) + npc_controller_B.BitShift27.y;

        /* End of Outputs for SubSystem: '<S264>/Bit Shift2' */
        /* End of Outputs for SubSystem: '<S264>/Bit Shift1' */
        /* End of Outputs for SubSystem: '<S264>/Bit Shift' */

        /* DataStoreWrite: '<S264>/Data Store Write4' */
        npc_controller_DWork.u8ThermalFlags = 0U;

        /* DataStoreWrite: '<S264>/Data Store Write5' */
        npc_controller_DWork.u8Reserved1 = 0U;

        /* DataStoreWrite: '<S264>/Data Store Write6' */
        npc_controller_DWork.u16Reserved1 = 0U;

        /* End of Outputs for SubSystem: '<S261>/fault_bitwise' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of SwitchCase: '<S261>/Switch Case' */

      /* S-Function (fcgen): '<S155>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S155>/cnt_idle'
       */
      /* If: '<S260>/If' incorporates:
       *  DataStoreRead: '<S260>/Data Store Read'
       */
      if (npc_controller_DWork.cnt_idle < 6U) {
        /* Outputs for IfAction SubSystem: '<S260>/cnt_idle' incorporates:
         *  ActionPort: '<S262>/Action Port'
         */
        /* DataStoreWrite: '<S262>/Data Store Write' incorporates:
         *  Constant: '<S262>/Constant'
         *  DataStoreRead: '<S262>/Data Store Read1'
         *  Sum: '<S262>/Add'
         */
        npc_controller_DWork.cnt_idle++;

        /* End of Outputs for SubSystem: '<S260>/cnt_idle' */
      } else {
        /* Outputs for IfAction SubSystem: '<S260>/cnt_idle_sat' incorporates:
         *  ActionPort: '<S263>/Action Port'
         */
        /* DataStoreWrite: '<S263>/Data Store Write' incorporates:
         *  Constant: '<S263>/Constant'
         */
        npc_controller_DWork.cnt_idle = 0U;

        /* End of Outputs for SubSystem: '<S260>/cnt_idle_sat' */
      }

      /* End of If: '<S260>/If' */
      /* End of Outputs for S-Function (fcgen): '<S155>/Function-Call Generator1' */
    }

    /* End of Outputs for S-Function (idletask): '<S152>/Idle Task' */
  }
}

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to remember which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void npc_controller_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(npc_controller_M, 1));
  eventFlags[2] = ((boolean_T)rtmStepTask(npc_controller_M, 2));
}

/*
 *         This function updates active task flag for each subrate
 *         and rate transition flags for tasks that exchange data.
 *         The function assumes rate-monotonic multitasking scheduler.
 *         The function must be called at model base rate so that
 *         the generated code self-manages all its subrates and rate
 *         transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (npc_controller_M->Timing.TaskCounters.TID[2])++;
  if ((npc_controller_M->Timing.TaskCounters.TID[2]) > 19) {/* Sample time: [0.02s, 0.0s] */
    npc_controller_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/*
 * Output and update for atomic system:
 *    '<S191>/Bit Shift'
 *    '<S192>/Bit Shift'
 *    '<S193>/Bit Shift'
 *    '<S200>/Bit Shift'
 *    '<S201>/Bit Shift'
 *    '<S202>/Bit Shift'
 *    '<S214>/Bit Shift'
 *    '<S215>/Bit Shift'
 *    '<S216>/Bit Shift'
 *    '<S218>/Bit Shift'
 *    ...
 */
void npc_controller_BitShift(uint16_T rtu_u, rtB_BitShift_npc_controller *localB)
{
  /* MATLAB Function: '<S194>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S195>:1' */
  /* '<S195>:1:8' */
  localB->y = rtu_u >> 8;
}

/* Output and update for function-call system: '<S152>/CAN_Task' */
void npc_controller_CAN_Task(boolean_T *rtd_b00_DebugEnabled, boolean_T
  *rtd_b01_ReadRequest, boolean_T *rtd_b05_MB10Received, boolean_T
  *rtd_b06_MB11Received, boolean_T *rtd_b07_MB12Received, const real32_T
  *rtd_f32IinA, const real32_T *rtd_f32IinB, const real32_T *rtd_f32IinC,
  real32_T *rtd_f32IoutTarget, const real32_T *rtd_f32IphaseA, const real32_T
  *rtd_f32IphaseB, const real32_T *rtd_f32IphaseC, real32_T *rtd_f32V2GPwrTarget,
  const real32_T *rtd_f32Vaux, const real32_T *rtd_f32VinA, const real32_T
  *rtd_f32VinB, const real32_T *rtd_f32VinC, real32_T *rtd_f32VoutTarget, const
  real32_T *rtd_f32Vpfc, const real32_T *rtd_f32VpfcMid, const uint16_T
  *rtd_sPriFault, const uint16_T *rtd_sPriStatus, const uint16_T *rtd_u16Debug0,
  const uint16_T *rtd_u16Debug1, const uint16_T *rtd_u16Debug2, const uint16_T
  *rtd_u16Debug3, const uint16_T *rtd_u16Debug4, const uint16_T *rtd_u16Debug5,
  const uint16_T *rtd_u16Reserved1, uint16_T *rtd_u16TxDelayCount, uint16_T
  *rtd_u8AliveCounter, const uint16_T rtd_u8CanDataRx10[8], const uint16_T
  rtd_u8CanDataRx11[8], const uint16_T rtd_u8CanDataRx12[8], uint16_T
  *rtd_u8CanTxIndex, const uint16_T rtd_u8FwRevData[8], uint16_T
  *rtd_u8GridPhaseType, uint16_T *rtd_u8ModeCmd, uint16_T *rtd_u8PriFutEnable,
  uint16_T *rtd_u8RdReqMsgPntr, uint16_T *rtd_u8RedunModeCmd, const uint16_T
  *rtd_u8Reserved1, uint16_T *rtd_u8SinglePhaseLeg, const uint16_T
  *rtd_u8TclllcP1, const uint16_T *rtd_u8TclllcP2, const uint16_T
  *rtd_u8ThermalFlags, const uint16_T *rtd_u8TnpcA, const uint16_T *rtd_u8TnpcB,
  const uint16_T *rtd_u8TnpcC, rtB_CAN_Task_npc_controller *localB)
{
  real32_T tmp;
  int16_T i;
  uint16_T rtb_y_a;

  /* S-Function (fcgen): '<S153>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S153>/Rx_Handler'
   */
  /* If: '<S158>/If' */
  if (*rtd_b05_MB10Received) {
    /* Outputs for IfAction SubSystem: '<S158>/ ProcessMB10' incorporates:
     *  ActionPort: '<S160>/Action Port'
     */
    /* DataStoreWrite: '<S160>/Data Store Write2' incorporates:
     *  Constant: '<S160>/Constant'
     *  Constant: '<S160>/Constant3'
     *  Constant: '<S160>/Constant4'
     *  DataStoreRead: '<S160>/Data Store Read'
     *  DataTypeConversion: '<S160>/Data Type Conversion3'
     *  DataTypeConversion: '<S160>/Data Type Conversion4'
     *  Gain: '<S160>/Multiply1'
     *  Product: '<S160>/Divide'
     *  Selector: '<S160>/Selector2'
     *  Selector: '<S160>/Selector3'
     *  Sum: '<S160>/Sum'
     */
    *rtd_f32VoutTarget = (real32_T)((real32_T)(((uint32_T)rtd_u8CanDataRx10[2] <<
      7U) + ((uint32_T)rtd_u8CanDataRx10[3] << 15U)) * 0.0078125F / 10.0);

    /* DataStoreWrite: '<S160>/Data Store Write3' incorporates:
     *  Constant: '<S160>/Constant5'
     *  Constant: '<S160>/Constant6'
     *  Constant: '<S160>/Constant7'
     *  DataStoreRead: '<S160>/Data Store Read'
     *  DataTypeConversion: '<S160>/Data Type Conversion7'
     *  DataTypeConversion: '<S160>/Data Type Conversion8'
     *  Gain: '<S160>/Multiply2'
     *  Product: '<S160>/Divide1'
     *  Selector: '<S160>/Selector4'
     *  Selector: '<S160>/Selector5'
     *  Sum: '<S160>/Sum1'
     */
    *rtd_f32IoutTarget = (real32_T)((real32_T)(((uint32_T)rtd_u8CanDataRx10[4] <<
      7U) + ((uint32_T)rtd_u8CanDataRx10[5] << 15U)) * 0.0078125F / 100.0);

    /* DataStoreWrite: '<S160>/Data Store Write4' incorporates:
     *  Constant: '<S160>/Constant10'
     *  Constant: '<S160>/Constant9'
     *  DataStoreRead: '<S160>/Data Store Read'
     *  DataTypeConversion: '<S160>/Data Type Conversion11'
     *  Gain: '<S160>/Multiply3'
     *  Selector: '<S160>/Selector6'
     *  Selector: '<S160>/Selector7'
     *  Sum: '<S160>/Sum2'
     */
    *rtd_f32V2GPwrTarget = (real32_T)(((uint32_T)rtd_u8CanDataRx10[6] << 7U) +
      ((uint32_T)rtd_u8CanDataRx10[7] << 15U)) * 0.0078125F;

    /* DataStoreWrite: '<S160>/Data Store Write1' incorporates:
     *  Constant: '<S160>/Constant1'
     */
    *rtd_b05_MB10Received = false;

    /* Outputs for Atomic SubSystem: '<S160>/Bit Shift' */
    /* MATLAB Function: '<S164>/bit_shift' incorporates:
     *  Constant: '<S160>/Constant11'
     *  DataStoreRead: '<S160>/Data Store Read'
     *  S-Function (sfix_bitop): '<S160>/Bitwise AND1'
     *  Selector: '<S160>/Selector8'
     */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S171>:1' */
    /* '<S171>:1:8' */
    rtb_y_a = (rtd_u8CanDataRx10[1] & 14U) >> 1;

    /* End of Outputs for SubSystem: '<S160>/Bit Shift' */

    /* If: '<S160>/If2' */
    if (rtb_y_a == 1U) {
      /* Outputs for IfAction SubSystem: '<S160>/Leg A' incorporates:
       *  ActionPort: '<S165>/Action Port'
       */
      /* DataStoreWrite: '<S165>/Data Store Write1' incorporates:
       *  Constant: '<S165>/Leg A'
       */
      *rtd_u8SinglePhaseLeg = 1U;

      /* End of Outputs for SubSystem: '<S160>/Leg A' */
    } else if (rtb_y_a == 2U) {
      /* Outputs for IfAction SubSystem: '<S160>/Leg B' incorporates:
       *  ActionPort: '<S166>/Action Port'
       */
      /* DataStoreWrite: '<S166>/Data Store Write1' incorporates:
       *  Constant: '<S166>/Leg B'
       */
      *rtd_u8SinglePhaseLeg = 2U;

      /* End of Outputs for SubSystem: '<S160>/Leg B' */
    } else if (rtb_y_a == 3U) {
      /* Outputs for IfAction SubSystem: '<S160>/Leg C' incorporates:
       *  ActionPort: '<S167>/Action Port'
       */
      /* DataStoreWrite: '<S167>/Data Store Write1' incorporates:
       *  Constant: '<S167>/Leg C'
       */
      *rtd_u8SinglePhaseLeg = 3U;

      /* End of Outputs for SubSystem: '<S160>/Leg C' */
    } else if (rtb_y_a == 4U) {
      /* Outputs for IfAction SubSystem: '<S160>/All Legs' incorporates:
       *  ActionPort: '<S163>/Action Port'
       */
      /* DataStoreWrite: '<S163>/Data Store Write1' incorporates:
       *  Constant: '<S163>/Leg All'
       */
      *rtd_u8SinglePhaseLeg = 4U;

      /* End of Outputs for SubSystem: '<S160>/All Legs' */
    }

    /* End of If: '<S160>/If2' */

    /* If: '<S160>/If' incorporates:
     *  Constant: '<S160>/Constant2'
     *  DataStoreRead: '<S160>/Data Store Read'
     *  Logic: '<S160>/OR'
     *  RelationalOperator: '<S160>/Equal'
     *  RelationalOperator: '<S160>/Equal1'
     *  RelationalOperator: '<S160>/Equal2'
     *  RelationalOperator: '<S160>/Equal3'
     *  RelationalOperator: '<S160>/Equal4'
     *  Selector: '<S160>/Selector1'
     */
    if ((rtd_u8CanDataRx10[0] == 160U) || (rtd_u8CanDataRx10[0] == 161U) ||
        (rtd_u8CanDataRx10[0] == 162U) || (rtd_u8CanDataRx10[0] == 163U) ||
        (rtd_u8CanDataRx10[0] == 164U)) {
      /* Outputs for IfAction SubSystem: '<S160>/Mode_Cmd' incorporates:
       *  ActionPort: '<S168>/Action Port'
       */
      /* DataStoreWrite: '<S168>/Data Store Write1' */
      *rtd_u8ModeCmd = rtd_u8CanDataRx10[0];

      /* End of Outputs for SubSystem: '<S160>/Mode_Cmd' */
    }

    /* End of If: '<S160>/If' */

    /* Outputs for IfAction SubSystem: '<S160>/Phase Type 3 Phase' incorporates:
     *  ActionPort: '<S170>/Action Port'
     */
    /* Outputs for IfAction SubSystem: '<S160>/Phase Type 1 Phase' incorporates:
     *  ActionPort: '<S169>/Action Port'
     */
    /* If: '<S160>/If1' incorporates:
     *  Constant: '<S160>/Constant11'
     *  DataStoreRead: '<S160>/Data Store Read'
     *  DataStoreWrite: '<S169>/Data Store Write1'
     *  DataStoreWrite: '<S170>/Data Store Write1'
     *  S-Function (sfix_bitop): '<S160>/Bitwise AND'
     *  Selector: '<S160>/Selector8'
     */
    *rtd_u8GridPhaseType = (uint16_T)((rtd_u8CanDataRx10[1] & 1U) == 1U);

    /* End of Outputs for SubSystem: '<S160>/Phase Type 1 Phase' */
    /* End of Outputs for SubSystem: '<S160>/Phase Type 3 Phase' */
    /* End of Outputs for SubSystem: '<S158>/ ProcessMB10' */
  } else if (*rtd_b06_MB11Received) {
    /* Outputs for IfAction SubSystem: '<S158>/ProcessMB11' incorporates:
     *  ActionPort: '<S161>/Action Port'
     */
    /* DataStoreWrite: '<S161>/Data Store Write1' incorporates:
     *  Constant: '<S161>/Constant'
     */
    *rtd_b06_MB11Received = false;

    /* DataStoreWrite: '<S161>/Data Store Write5' incorporates:
     *  Constant: '<S161>/Constant2'
     *  DataStoreRead: '<S161>/Data Store Read'
     *  Selector: '<S161>/Selector1'
     */
    *rtd_u8AliveCounter = rtd_u8CanDataRx11[0];

    /* If: '<S161>/If' incorporates:
     *  Constant: '<S161>/Constant1'
     *  DataStoreRead: '<S161>/Data Store Read'
     *  Logic: '<S161>/OR'
     *  RelationalOperator: '<S161>/Equal'
     *  RelationalOperator: '<S161>/Equal1'
     *  RelationalOperator: '<S161>/Equal2'
     *  RelationalOperator: '<S161>/Equal3'
     *  Selector: '<S161>/Selector2'
     */
    if ((rtd_u8CanDataRx11[1] == 176U) || (rtd_u8CanDataRx11[1] == 177U) ||
        (rtd_u8CanDataRx11[1] == 178U) || (rtd_u8CanDataRx11[1] == 179U)) {
      /* Outputs for IfAction SubSystem: '<S161>/Red_Mode_Cmd' incorporates:
       *  ActionPort: '<S172>/Action Port'
       */
      /* DataStoreWrite: '<S172>/Data Store Write1' */
      *rtd_u8RedunModeCmd = rtd_u8CanDataRx11[1];

      /* End of Outputs for SubSystem: '<S161>/Red_Mode_Cmd' */
    }

    /* End of If: '<S161>/If' */
    /* End of Outputs for SubSystem: '<S158>/ProcessMB11' */
  } else if (*rtd_b07_MB12Received) {
    /* Outputs for IfAction SubSystem: '<S158>/ProcessMB12' incorporates:
     *  ActionPort: '<S162>/Action Port'
     */
    /* DataStoreWrite: '<S162>/Data Store Write1' incorporates:
     *  Constant: '<S162>/Constant'
     */
    *rtd_b07_MB12Received = false;

    /* If: '<S162>/If' incorporates:
     *  Constant: '<S162>/Constant2'
     *  DataStoreRead: '<S162>/Data Store Read'
     *  Selector: '<S162>/Selector1'
     */
    if (rtd_u8CanDataRx12[0] == 0U) {
      /* Outputs for IfAction SubSystem: '<S162>/Debug_Read' incorporates:
       *  ActionPort: '<S174>/Action Port'
       */
      /* If: '<S174>/If' incorporates:
       *  Constant: '<S174>/Constant2'
       *  DataStoreRead: '<S174>/Data Store Read'
       *  Logic: '<S174>/OR'
       *  RelationalOperator: '<S174>/Equal'
       *  RelationalOperator: '<S174>/Equal1'
       *  RelationalOperator: '<S174>/Equal2'
       *  RelationalOperator: '<S174>/Equal3'
       *  Selector: '<S174>/Selector1'
       */
      if ((rtd_u8CanDataRx12[1] == 240U) || (rtd_u8CanDataRx12[1] == 208U) ||
          (rtd_u8CanDataRx12[1] == 209U) || (rtd_u8CanDataRx12[1] == 210U)) {
        /* Outputs for IfAction SubSystem: '<S174>/Debug_Cmd' incorporates:
         *  ActionPort: '<S182>/Action Port'
         */
        /* DataStoreWrite: '<S182>/Data Store Write2' */
        *rtd_u8RdReqMsgPntr = rtd_u8CanDataRx12[1];

        /* DataStoreWrite: '<S182>/Data Store Write1' incorporates:
         *  Constant: '<S182>/Constant'
         */
        *rtd_b01_ReadRequest = true;

        /* End of Outputs for SubSystem: '<S174>/Debug_Cmd' */
      }

      /* End of If: '<S174>/If' */
      /* End of Outputs for SubSystem: '<S162>/Debug_Read' */
    } else if ((rtd_u8CanDataRx12[0] != 1U) && (rtd_u8CanDataRx12[0] == 2U)) {
      /* Outputs for IfAction SubSystem: '<S162>/Debug_Cmd' incorporates:
       *  ActionPort: '<S173>/Action Port'
       */
      /* If: '<S173>/If1' incorporates:
       *  Constant: '<S173>/Constant3'
       *  DataStoreRead: '<S173>/Data Store Read1'
       *  Selector: '<S173>/Selector3'
       */
      if (rtd_u8CanDataRx12[1] == 218U) {
        /* Outputs for IfAction SubSystem: '<S173>/Debug En//Dis' incorporates:
         *  ActionPort: '<S176>/Action Port'
         */
        /* If: '<S176>/If' incorporates:
         *  Constant: '<S176>/Constant3'
         *  DataStoreRead: '<S176>/Data Store Read1'
         *  Selector: '<S176>/Selector3'
         */
        if (rtd_u8CanDataRx12[2] == 170U) {
          /* Outputs for IfAction SubSystem: '<S176>/Debug_En' incorporates:
           *  ActionPort: '<S179>/Action Port'
           */
          /* DataStoreWrite: '<S179>/Data Store Write1' incorporates:
           *  Constant: '<S179>/Constant'
           */
          *rtd_b00_DebugEnabled = true;

          /* End of Outputs for SubSystem: '<S176>/Debug_En' */
        } else if (rtd_u8CanDataRx12[2] == 85U) {
          /* Outputs for IfAction SubSystem: '<S176>/Debug_Dis' incorporates:
           *  ActionPort: '<S178>/Action Port'
           */
          /* DataStoreWrite: '<S178>/Data Store Write1' incorporates:
           *  Constant: '<S178>/Constant'
           */
          *rtd_b00_DebugEnabled = false;

          /* End of Outputs for SubSystem: '<S176>/Debug_Dis' */
        }

        /* End of If: '<S176>/If' */
        /* End of Outputs for SubSystem: '<S173>/Debug En//Dis' */
      } else if (rtd_u8CanDataRx12[1] == 219U) {
        /* Outputs for IfAction SubSystem: '<S173>/FUT En Dis' incorporates:
         *  ActionPort: '<S177>/Action Port'
         */
        /* If: '<S177>/If' incorporates:
         *  Constant: '<S177>/Constant3'
         *  DataStoreRead: '<S177>/Data Store Read1'
         *  Selector: '<S177>/Selector3'
         */
        if (rtd_u8CanDataRx12[2] == 187U) {
          /* Outputs for IfAction SubSystem: '<S177>/Enable FUT' incorporates:
           *  ActionPort: '<S181>/Action Port'
           */
          /* DataStoreWrite: '<S181>/Data Store Write1' incorporates:
           *  Constant: '<S181>/Constant'
           */
          *rtd_u8PriFutEnable = 1U;

          /* End of Outputs for SubSystem: '<S177>/Enable FUT' */
        } else if (rtd_u8CanDataRx12[2] == 68U) {
          /* Outputs for IfAction SubSystem: '<S177>/Disable FUT' incorporates:
           *  ActionPort: '<S180>/Action Port'
           */
          /* DataStoreWrite: '<S180>/Data Store Write1' incorporates:
           *  Constant: '<S180>/Constant'
           */
          *rtd_u8PriFutEnable = 0U;

          /* End of Outputs for SubSystem: '<S177>/Disable FUT' */
        }

        /* End of If: '<S177>/If' */
        /* End of Outputs for SubSystem: '<S173>/FUT En Dis' */
      }

      /* End of If: '<S173>/If1' */
      /* End of Outputs for SubSystem: '<S162>/Debug_Cmd' */
    }

    /* End of If: '<S162>/If' */
    /* End of Outputs for SubSystem: '<S158>/ProcessMB12' */
  }

  /* End of If: '<S158>/If' */

  /* S-Function (fcgen): '<S153>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S153>/Tx_Handler'
   */
  /* Sum: '<S183>/FixPt Sum1' incorporates:
   *  Constant: '<S183>/FixPt Constant'
   */
  rtb_y_a = *rtd_u16TxDelayCount + 1U;

  /* DataStoreWrite: '<S159>/Data Store Write1' incorporates:
   *  Constant: '<S183>/FixPt Constant'
   *  Sum: '<S183>/FixPt Sum1'
   */
  (*rtd_u16TxDelayCount)++;

  /* If: '<S159>/If2' incorporates:
   *  Constant: '<S159>/Constant4'
   */
  if (rtb_y_a == 10U) {
    /* Outputs for IfAction SubSystem: '<S159>/Run Tx Routine' incorporates:
     *  ActionPort: '<S184>/Action Port'
     */
    /* DataStoreWrite: '<S184>/Data Store Write1' incorporates:
     *  Constant: '<S184>/Constant1'
     */
    *rtd_u16TxDelayCount = 0U;

    /* If: '<S184>/If1' */
    if ((*rtd_b01_ReadRequest) && (*rtd_b00_DebugEnabled)) {
      /* Outputs for IfAction SubSystem: '<S184>/TxReadRequest' incorporates:
       *  ActionPort: '<S185>/Action Port'
       */
      /* DataStoreWrite: '<S185>/Data Store Write1' incorporates:
       *  Constant: '<S185>/Constant1'
       */
      *rtd_b01_ReadRequest = false;

      /* SwitchCase: '<S185>/Switch Case' incorporates:
       *  S-Function (sfix_bitop): '<S191>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S192>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S193>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S200>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S201>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S202>/Bitwise AND1'
       */
      switch ((int32_T)*rtd_u8RdReqMsgPntr) {
       case 240L:
        /* Outputs for IfAction SubSystem: '<S185>/ Tx FW Rev ID134' incorporates:
         *  ActionPort: '<S187>/Action Port'
         */
        for (i = 0; i < 8; i++) {
          /* DataStoreRead: '<S187>/Data Store Read2' */
          localB->DataStoreRead2[i] = rtd_u8FwRevData[i];
        }

        /* S-Function (scanpack): '<S187>/CAN Pack1' */
        /* S-Function (scanpack): '<S187>/CAN Pack1' */
        localB->CANPack1_l.ID = 308U;
        localB->CANPack1_l.Length = 8U;
        localB->CANPack1_l.Extended = 0U;
        localB->CANPack1_l.Remote = 0;
        localB->CANPack1_l.Data[0] = 0;
        localB->CANPack1_l.Data[1] = 0;
        localB->CANPack1_l.Data[2] = 0;
        localB->CANPack1_l.Data[3] = 0;
        localB->CANPack1_l.Data[4] = 0;
        localB->CANPack1_l.Data[5] = 0;
        localB->CANPack1_l.Data[6] = 0;
        localB->CANPack1_l.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_l.Data), &localB->DataStoreRead2[0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S187>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_l.Length;
          uint32_T messageID = localB->CANPack1_l.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_l.Data;
          uint16_T isExtended = localB->CANPack1_l.Extended;
          CAN_setupMessageObject(CANA_BASE, 6, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 6, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S185>/ Tx FW Rev ID134' */
        break;

       case 208L:
        break;

       case 209L:
        /* Outputs for IfAction SubSystem: '<S185>/Tx TxDeb Dat1 136' incorporates:
         *  ActionPort: '<S189>/Action Port'
         */
        /* DataTypeConversion: '<S191>/Data Type Conversion' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S191>/Bitwise AND'
         */
        localB->VectorConcatenate_b[0] = *rtd_u16Debug0 & 255U;

        /* Outputs for Atomic SubSystem: '<S191>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug0 & 65280U, &localB->BitShift_j);

        /* End of Outputs for SubSystem: '<S191>/Bit Shift' */

        /* DataTypeConversion: '<S191>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S191>/Bitwise AND1'
         */
        localB->VectorConcatenate_b[1] = localB->BitShift_j.y & 255U;

        /* DataTypeConversion: '<S193>/Data Type Conversion' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S193>/Bitwise AND'
         */
        localB->VectorConcatenate_b[2] = *rtd_u16Debug1 & 255U;

        /* Outputs for Atomic SubSystem: '<S193>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug1 & 65280U, &localB->BitShift_p);

        /* End of Outputs for SubSystem: '<S193>/Bit Shift' */

        /* DataTypeConversion: '<S193>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S193>/Bitwise AND1'
         */
        localB->VectorConcatenate_b[3] = localB->BitShift_p.y & 255U;

        /* DataTypeConversion: '<S192>/Data Type Conversion' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S192>/Bitwise AND'
         */
        localB->VectorConcatenate_b[4] = *rtd_u16Debug2 & 255U;

        /* Outputs for Atomic SubSystem: '<S192>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug2 & 65280U, &localB->BitShift_ji);

        /* End of Outputs for SubSystem: '<S192>/Bit Shift' */

        /* DataTypeConversion: '<S192>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S192>/Bitwise AND1'
         */
        localB->VectorConcatenate_b[5] = localB->BitShift_ji.y & 255U;

        /* SignalConversion generated from: '<S189>/Vector Concatenate' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  Constant: '<S189>/Constant4'
         */
        localB->VectorConcatenate_b[6] = 0U;

        /* SignalConversion generated from: '<S189>/Vector Concatenate' incorporates:
         *  Concatenate: '<S189>/Vector Concatenate'
         *  Constant: '<S189>/Constant4'
         */
        localB->VectorConcatenate_b[7] = 0U;

        /* S-Function (scanpack): '<S189>/CAN Pack1' */
        /* S-Function (scanpack): '<S189>/CAN Pack1' */
        localB->CANPack1_k.ID = 310U;
        localB->CANPack1_k.Length = 8U;
        localB->CANPack1_k.Extended = 0U;
        localB->CANPack1_k.Remote = 0;
        localB->CANPack1_k.Data[0] = 0;
        localB->CANPack1_k.Data[1] = 0;
        localB->CANPack1_k.Data[2] = 0;
        localB->CANPack1_k.Data[3] = 0;
        localB->CANPack1_k.Data[4] = 0;
        localB->CANPack1_k.Data[5] = 0;
        localB->CANPack1_k.Data[6] = 0;
        localB->CANPack1_k.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_k.Data), &localB->VectorConcatenate_b
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S189>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_k.Length;
          uint32_T messageID = localB->CANPack1_k.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_k.Data;
          uint16_T isExtended = localB->CANPack1_k.Extended;
          CAN_setupMessageObject(CANA_BASE, 8, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 8, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S185>/Tx TxDeb Dat1 136' */
        break;

       case 210L:
        /* Outputs for IfAction SubSystem: '<S185>/Tx TxDeb Dat2 137' incorporates:
         *  ActionPort: '<S190>/Action Port'
         */
        /* DataTypeConversion: '<S200>/Data Type Conversion' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S200>/Bitwise AND'
         */
        localB->VectorConcatenate_o[0] = *rtd_u16Debug3 & 255U;

        /* Outputs for Atomic SubSystem: '<S200>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug3 & 65280U, &localB->BitShift_e);

        /* End of Outputs for SubSystem: '<S200>/Bit Shift' */

        /* DataTypeConversion: '<S200>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S200>/Bitwise AND1'
         */
        localB->VectorConcatenate_o[1] = localB->BitShift_e.y & 255U;

        /* DataTypeConversion: '<S202>/Data Type Conversion' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S202>/Bitwise AND'
         */
        localB->VectorConcatenate_o[2] = *rtd_u16Debug4 & 255U;

        /* Outputs for Atomic SubSystem: '<S202>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug4 & 65280U, &localB->BitShift_eq);

        /* End of Outputs for SubSystem: '<S202>/Bit Shift' */

        /* DataTypeConversion: '<S202>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S202>/Bitwise AND1'
         */
        localB->VectorConcatenate_o[3] = localB->BitShift_eq.y & 255U;

        /* DataTypeConversion: '<S201>/Data Type Conversion' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S201>/Bitwise AND'
         */
        localB->VectorConcatenate_o[4] = *rtd_u16Debug5 & 255U;

        /* Outputs for Atomic SubSystem: '<S201>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug5 & 65280U, &localB->BitShift_f);

        /* End of Outputs for SubSystem: '<S201>/Bit Shift' */

        /* DataTypeConversion: '<S201>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S201>/Bitwise AND1'
         */
        localB->VectorConcatenate_o[5] = localB->BitShift_f.y & 255U;

        /* SignalConversion generated from: '<S190>/Vector Concatenate' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  Constant: '<S190>/Constant4'
         */
        localB->VectorConcatenate_o[6] = 0U;

        /* SignalConversion generated from: '<S190>/Vector Concatenate' incorporates:
         *  Concatenate: '<S190>/Vector Concatenate'
         *  Constant: '<S190>/Constant4'
         */
        localB->VectorConcatenate_o[7] = 0U;

        /* S-Function (scanpack): '<S190>/CAN Pack1' */
        /* S-Function (scanpack): '<S190>/CAN Pack1' */
        localB->CANPack1_h.ID = 311U;
        localB->CANPack1_h.Length = 8U;
        localB->CANPack1_h.Extended = 0U;
        localB->CANPack1_h.Remote = 0;
        localB->CANPack1_h.Data[0] = 0;
        localB->CANPack1_h.Data[1] = 0;
        localB->CANPack1_h.Data[2] = 0;
        localB->CANPack1_h.Data[3] = 0;
        localB->CANPack1_h.Data[4] = 0;
        localB->CANPack1_h.Data[5] = 0;
        localB->CANPack1_h.Data[6] = 0;
        localB->CANPack1_h.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_h.Data), &localB->VectorConcatenate_o
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S190>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_h.Length;
          uint32_T messageID = localB->CANPack1_h.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_h.Data;
          uint16_T isExtended = localB->CANPack1_h.Extended;
          CAN_setupMessageObject(CANA_BASE, 9, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 9, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S185>/Tx TxDeb Dat2 137' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of SwitchCase: '<S185>/Switch Case' */
      /* End of Outputs for SubSystem: '<S184>/TxReadRequest' */
    } else {
      /* Outputs for IfAction SubSystem: '<S184>/TxStatusData' incorporates:
       *  ActionPort: '<S186>/Action Port'
       */
      /* SwitchCase: '<S186>/Switch Case' incorporates:
       *  S-Function (sfix_bitop): '<S214>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S215>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S216>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S218>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S227>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S228>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S229>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S236>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S237>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S238>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S239>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S248>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S249>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S250>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S251>/Bitwise AND1'
       */
      switch ((int32_T)*rtd_u8CanTxIndex) {
       case 0L:
        /* Outputs for IfAction SubSystem: '<S186>/Tx Pri Status ID110' incorporates:
         *  ActionPort: '<S209>/Action Port'
         */
        /* DataTypeConversion: '<S218>/Data Type Conversion' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S218>/Bitwise AND'
         */
        localB->VectorConcatenate_c[0] = *rtd_sPriStatus & 255U;

        /* Outputs for Atomic SubSystem: '<S218>/Bit Shift' */
        npc_controller_BitShift(*rtd_sPriStatus & 65280U, &localB->BitShift_ed);

        /* End of Outputs for SubSystem: '<S218>/Bit Shift' */

        /* DataTypeConversion: '<S218>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S218>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[1] = localB->BitShift_ed.y & 255U;

        /* DataTypeConversion: '<S214>/Data Type Conversion2' incorporates:
         *  Constant: '<S209>/Constant1'
         *  Product: '<S214>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VinA / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S214>/Data Type Conversion2' */

        /* DataTypeConversion: '<S214>/Data Type Conversion' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S214>/Bitwise AND'
         */
        localB->VectorConcatenate_c[2] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S214>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_o);

        /* End of Outputs for SubSystem: '<S214>/Bit Shift' */

        /* DataTypeConversion: '<S214>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S214>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[3] = localB->BitShift_o.y & 255U;

        /* DataTypeConversion: '<S215>/Data Type Conversion2' incorporates:
         *  Constant: '<S209>/Constant3'
         *  Product: '<S215>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IinA / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S215>/Data Type Conversion2' */

        /* DataTypeConversion: '<S215>/Data Type Conversion' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S215>/Bitwise AND'
         */
        localB->VectorConcatenate_c[4] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S215>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_pb);

        /* End of Outputs for SubSystem: '<S215>/Bit Shift' */

        /* DataTypeConversion: '<S215>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S215>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[5] = localB->BitShift_pb.y & 255U;

        /* DataTypeConversion: '<S216>/Data Type Conversion2' incorporates:
         *  Constant: '<S209>/Constant4'
         *  Product: '<S216>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VpfcMid / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S216>/Data Type Conversion2' */

        /* DataTypeConversion: '<S216>/Data Type Conversion' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S216>/Bitwise AND'
         */
        localB->VectorConcatenate_c[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S216>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_d);

        /* End of Outputs for SubSystem: '<S216>/Bit Shift' */

        /* DataTypeConversion: '<S216>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S209>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S216>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[7] = localB->BitShift_d.y & 255U;

        /* S-Function (scanpack): '<S209>/CAN Pack1' */
        /* S-Function (scanpack): '<S209>/CAN Pack1' */
        localB->CANPack1_c.ID = 272U;
        localB->CANPack1_c.Length = 8U;
        localB->CANPack1_c.Extended = 0U;
        localB->CANPack1_c.Remote = 0;
        localB->CANPack1_c.Data[0] = 0;
        localB->CANPack1_c.Data[1] = 0;
        localB->CANPack1_c.Data[2] = 0;
        localB->CANPack1_c.Data[3] = 0;
        localB->CANPack1_c.Data[4] = 0;
        localB->CANPack1_c.Data[5] = 0;
        localB->CANPack1_c.Data[6] = 0;
        localB->CANPack1_c.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_c.Data), &localB->VectorConcatenate_c
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S209>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_c.Length;
          uint32_T messageID = localB->CANPack1_c.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_c.Data;
          uint16_T isExtended = localB->CANPack1_c.Extended;
          CAN_setupMessageObject(CANA_BASE, 1, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 1, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* If: '<S209>/If1' */
        if (*rtd_b00_DebugEnabled) {
          /* Outputs for IfAction SubSystem: '<S209>/TxReadRequest' incorporates:
           *  ActionPort: '<S217>/Action Port'
           */
          /* DataStoreWrite: '<S217>/Data Store Write1' incorporates:
           *  Constant: '<S217>/Constant1'
           */
          *rtd_u8CanTxIndex = 1U;

          /* End of Outputs for SubSystem: '<S209>/TxReadRequest' */
        }

        /* End of If: '<S209>/If1' */
        /* End of Outputs for SubSystem: '<S186>/Tx Pri Status ID110' */
        break;

       case 1L:
        /* Outputs for IfAction SubSystem: '<S186>/Tx Pri1 ID130' incorporates:
         *  ActionPort: '<S210>/Action Port'
         */
        /* DataStoreWrite: '<S210>/Data Store Write1' incorporates:
         *  Constant: '<S210>/Constant1'
         */
        *rtd_u8CanTxIndex = 2U;

        /* DataTypeConversion: '<S228>/Data Type Conversion' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S228>/Bitwise AND'
         */
        localB->VectorConcatenate_g[0] = *rtd_sPriFault & 255U;

        /* Outputs for Atomic SubSystem: '<S228>/Bit Shift' */
        npc_controller_BitShift(*rtd_sPriFault & 65280U, &localB->BitShift_i);

        /* End of Outputs for SubSystem: '<S228>/Bit Shift' */

        /* DataTypeConversion: '<S228>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S228>/Bitwise AND1'
         */
        localB->VectorConcatenate_g[1] = localB->BitShift_i.y & 255U;

        /* DataStoreRead: '<S210>/Data Store Read2' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         */
        localB->VectorConcatenate_g[2] = *rtd_u8ThermalFlags;

        /* DataStoreRead: '<S210>/Data Store Read4' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         */
        localB->VectorConcatenate_g[3] = *rtd_u8Reserved1;

        /* DataTypeConversion: '<S229>/Data Type Conversion' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S229>/Bitwise AND'
         */
        localB->VectorConcatenate_g[4] = *rtd_u16Reserved1 & 255U;

        /* Outputs for Atomic SubSystem: '<S229>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Reserved1 & 65280U, &localB->BitShift_c);

        /* End of Outputs for SubSystem: '<S229>/Bit Shift' */

        /* DataTypeConversion: '<S229>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S229>/Bitwise AND1'
         */
        localB->VectorConcatenate_g[5] = localB->BitShift_c.y & 255U;

        /* DataTypeConversion: '<S227>/Data Type Conversion2' incorporates:
         *  Constant: '<S210>/Constant4'
         *  Product: '<S227>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32Vaux / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S227>/Data Type Conversion2' */

        /* DataTypeConversion: '<S227>/Data Type Conversion' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S227>/Bitwise AND'
         */
        localB->VectorConcatenate_g[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S227>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_g);

        /* End of Outputs for SubSystem: '<S227>/Bit Shift' */

        /* DataTypeConversion: '<S227>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S210>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S227>/Bitwise AND1'
         */
        localB->VectorConcatenate_g[7] = localB->BitShift_g.y & 255U;

        /* S-Function (scanpack): '<S210>/CAN Pack1' */
        /* S-Function (scanpack): '<S210>/CAN Pack1' */
        localB->CANPack1_i.ID = 304U;
        localB->CANPack1_i.Length = 8U;
        localB->CANPack1_i.Extended = 0U;
        localB->CANPack1_i.Remote = 0;
        localB->CANPack1_i.Data[0] = 0;
        localB->CANPack1_i.Data[1] = 0;
        localB->CANPack1_i.Data[2] = 0;
        localB->CANPack1_i.Data[3] = 0;
        localB->CANPack1_i.Data[4] = 0;
        localB->CANPack1_i.Data[5] = 0;
        localB->CANPack1_i.Data[6] = 0;
        localB->CANPack1_i.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_i.Data), &localB->VectorConcatenate_g
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S210>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_i.Length;
          uint32_T messageID = localB->CANPack1_i.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_i.Data;
          uint16_T isExtended = localB->CANPack1_i.Extended;
          CAN_setupMessageObject(CANA_BASE, 2, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 2, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S186>/Tx Pri1 ID130' */
        break;

       case 2L:
        /* Outputs for IfAction SubSystem: '<S186>/Tx Pri2 ID131' incorporates:
         *  ActionPort: '<S211>/Action Port'
         */
        /* DataStoreWrite: '<S211>/Data Store Write1' incorporates:
         *  Constant: '<S211>/Constant1'
         */
        *rtd_u8CanTxIndex = 3U;

        /* DataTypeConversion: '<S239>/Data Type Conversion2' incorporates:
         *  Constant: '<S211>/Constant5'
         *  Product: '<S239>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VinB / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S239>/Data Type Conversion2' */

        /* DataTypeConversion: '<S239>/Data Type Conversion' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S239>/Bitwise AND'
         */
        localB->VectorConcatenate_e[0] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S239>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_a);

        /* End of Outputs for SubSystem: '<S239>/Bit Shift' */

        /* DataTypeConversion: '<S239>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S239>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[1] = localB->BitShift_a.y & 255U;

        /* DataTypeConversion: '<S236>/Data Type Conversion2' incorporates:
         *  Constant: '<S211>/Constant2'
         *  Product: '<S236>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VinC / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S236>/Data Type Conversion2' */

        /* DataTypeConversion: '<S236>/Data Type Conversion' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S236>/Bitwise AND'
         */
        localB->VectorConcatenate_e[2] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S236>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_du);

        /* End of Outputs for SubSystem: '<S236>/Bit Shift' */

        /* DataTypeConversion: '<S236>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S236>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[3] = localB->BitShift_du.y & 255U;

        /* DataTypeConversion: '<S237>/Data Type Conversion2' incorporates:
         *  Constant: '<S211>/Constant3'
         *  Product: '<S237>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IinB / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S237>/Data Type Conversion2' */

        /* DataTypeConversion: '<S237>/Data Type Conversion' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S237>/Bitwise AND'
         */
        localB->VectorConcatenate_e[4] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S237>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_b);

        /* End of Outputs for SubSystem: '<S237>/Bit Shift' */

        /* DataTypeConversion: '<S237>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S237>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[5] = localB->BitShift_b.y & 255U;

        /* DataTypeConversion: '<S238>/Data Type Conversion2' incorporates:
         *  Constant: '<S211>/Constant4'
         *  Product: '<S238>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IinC / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S238>/Data Type Conversion2' */

        /* DataTypeConversion: '<S238>/Data Type Conversion' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S238>/Bitwise AND'
         */
        localB->VectorConcatenate_e[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S238>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_ij);

        /* End of Outputs for SubSystem: '<S238>/Bit Shift' */

        /* DataTypeConversion: '<S238>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S211>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S238>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[7] = localB->BitShift_ij.y & 255U;

        /* S-Function (scanpack): '<S211>/CAN Pack1' */
        /* S-Function (scanpack): '<S211>/CAN Pack1' */
        localB->CANPack1_g.ID = 305U;
        localB->CANPack1_g.Length = 8U;
        localB->CANPack1_g.Extended = 0U;
        localB->CANPack1_g.Remote = 0;
        localB->CANPack1_g.Data[0] = 0;
        localB->CANPack1_g.Data[1] = 0;
        localB->CANPack1_g.Data[2] = 0;
        localB->CANPack1_g.Data[3] = 0;
        localB->CANPack1_g.Data[4] = 0;
        localB->CANPack1_g.Data[5] = 0;
        localB->CANPack1_g.Data[6] = 0;
        localB->CANPack1_g.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_g.Data), &localB->VectorConcatenate_e
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S211>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_g.Length;
          uint32_T messageID = localB->CANPack1_g.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_g.Data;
          uint16_T isExtended = localB->CANPack1_g.Extended;
          CAN_setupMessageObject(CANA_BASE, 3, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 3, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S186>/Tx Pri2 ID131' */
        break;

       case 3L:
        /* Outputs for IfAction SubSystem: '<S186>/Tx Pri3 ID132' incorporates:
         *  ActionPort: '<S212>/Action Port'
         */
        /* DataStoreWrite: '<S212>/Data Store Write1' incorporates:
         *  Constant: '<S212>/Constant1'
         */
        *rtd_u8CanTxIndex = 4U;

        /* DataTypeConversion: '<S251>/Data Type Conversion2' incorporates:
         *  Constant: '<S212>/Constant5'
         *  Product: '<S251>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IphaseA / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S251>/Data Type Conversion2' */

        /* DataTypeConversion: '<S251>/Data Type Conversion' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S251>/Bitwise AND'
         */
        localB->VectorConcatenate_d[0] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S251>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_ab);

        /* End of Outputs for SubSystem: '<S251>/Bit Shift' */

        /* DataTypeConversion: '<S251>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S251>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[1] = localB->BitShift_ab.y & 255U;

        /* DataTypeConversion: '<S248>/Data Type Conversion2' incorporates:
         *  Constant: '<S212>/Constant2'
         *  Product: '<S248>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IphaseB / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S248>/Data Type Conversion2' */

        /* DataTypeConversion: '<S248>/Data Type Conversion' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S248>/Bitwise AND'
         */
        localB->VectorConcatenate_d[2] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S248>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_jj);

        /* End of Outputs for SubSystem: '<S248>/Bit Shift' */

        /* DataTypeConversion: '<S248>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S248>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[3] = localB->BitShift_jj.y & 255U;

        /* DataTypeConversion: '<S249>/Data Type Conversion2' incorporates:
         *  Constant: '<S212>/Constant3'
         *  Product: '<S249>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IphaseC / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S249>/Data Type Conversion2' */

        /* DataTypeConversion: '<S249>/Data Type Conversion' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S249>/Bitwise AND'
         */
        localB->VectorConcatenate_d[4] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S249>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_g0);

        /* End of Outputs for SubSystem: '<S249>/Bit Shift' */

        /* DataTypeConversion: '<S249>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S249>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[5] = localB->BitShift_g0.y & 255U;

        /* DataTypeConversion: '<S250>/Data Type Conversion2' incorporates:
         *  Constant: '<S212>/Constant4'
         *  Product: '<S250>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32Vpfc / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S250>/Data Type Conversion2' */

        /* DataTypeConversion: '<S250>/Data Type Conversion' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S250>/Bitwise AND'
         */
        localB->VectorConcatenate_d[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S250>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_cy);

        /* End of Outputs for SubSystem: '<S250>/Bit Shift' */

        /* DataTypeConversion: '<S250>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S212>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S250>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[7] = localB->BitShift_cy.y & 255U;

        /* S-Function (scanpack): '<S212>/CAN Pack1' */
        /* S-Function (scanpack): '<S212>/CAN Pack1' */
        localB->CANPack1_p.ID = 306U;
        localB->CANPack1_p.Length = 8U;
        localB->CANPack1_p.Extended = 0U;
        localB->CANPack1_p.Remote = 0;
        localB->CANPack1_p.Data[0] = 0;
        localB->CANPack1_p.Data[1] = 0;
        localB->CANPack1_p.Data[2] = 0;
        localB->CANPack1_p.Data[3] = 0;
        localB->CANPack1_p.Data[4] = 0;
        localB->CANPack1_p.Data[5] = 0;
        localB->CANPack1_p.Data[6] = 0;
        localB->CANPack1_p.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_p.Data), &localB->VectorConcatenate_d
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S212>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_p.Length;
          uint32_T messageID = localB->CANPack1_p.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_p.Data;
          uint16_T isExtended = localB->CANPack1_p.Extended;
          CAN_setupMessageObject(CANA_BASE, 3, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 3, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S186>/Tx Pri3 ID132' */
        break;

       case 4L:
        /* Outputs for IfAction SubSystem: '<S186>/Tx Pri4 ID133' incorporates:
         *  ActionPort: '<S213>/Action Port'
         */
        /* DataStoreWrite: '<S213>/Data Store Write1' incorporates:
         *  Constant: '<S213>/Constant1'
         */
        *rtd_u8CanTxIndex = 0U;

        /* DataStoreRead: '<S213>/Data Store Read1' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         */
        localB->VectorConcatenate[0] = *rtd_u8TnpcA;

        /* DataStoreRead: '<S213>/Data Store Read3' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         */
        localB->VectorConcatenate[1] = *rtd_u8TnpcB;

        /* DataStoreRead: '<S213>/Data Store Read2' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         */
        localB->VectorConcatenate[2] = *rtd_u8TnpcC;

        /* DataStoreRead: '<S213>/Data Store Read6' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         */
        localB->VectorConcatenate[3] = *rtd_u8TclllcP1;

        /* DataStoreRead: '<S213>/Data Store Read4' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         */
        localB->VectorConcatenate[4] = *rtd_u8TclllcP2;

        /* SignalConversion generated from: '<S213>/Vector Concatenate' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         *  Constant: '<S213>/Constant2'
         */
        localB->VectorConcatenate[5] = 0U;

        /* SignalConversion generated from: '<S213>/Vector Concatenate' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         *  Constant: '<S213>/Constant2'
         */
        localB->VectorConcatenate[6] = 0U;

        /* SignalConversion generated from: '<S213>/Vector Concatenate' incorporates:
         *  Concatenate: '<S213>/Vector Concatenate'
         *  Constant: '<S213>/Constant2'
         */
        localB->VectorConcatenate[7] = 0U;

        /* S-Function (scanpack): '<S213>/CAN Pack1' */
        /* S-Function (scanpack): '<S213>/CAN Pack1' */
        localB->CANPack1.ID = 307U;
        localB->CANPack1.Length = 8U;
        localB->CANPack1.Extended = 0U;
        localB->CANPack1.Remote = 0;
        localB->CANPack1.Data[0] = 0;
        localB->CANPack1.Data[1] = 0;
        localB->CANPack1.Data[2] = 0;
        localB->CANPack1.Data[3] = 0;
        localB->CANPack1.Data[4] = 0;
        localB->CANPack1.Data[5] = 0;
        localB->CANPack1.Data[6] = 0;
        localB->CANPack1.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1.Data), &localB->VectorConcatenate[0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S213>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1.Length;
          uint32_T messageID = localB->CANPack1.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1.Data;
          uint16_T isExtended = localB->CANPack1.Extended;
          CAN_setupMessageObject(CANA_BASE, 4, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 4, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S186>/Tx Pri4 ID133' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of SwitchCase: '<S186>/Switch Case' */
      /* End of Outputs for SubSystem: '<S184>/TxStatusData' */
    }

    /* End of If: '<S184>/If1' */
    /* End of Outputs for SubSystem: '<S159>/Run Tx Routine' */
  }

  /* End of If: '<S159>/If2' */
  /* End of Outputs for S-Function (fcgen): '<S153>/Function-Call Generator1' */
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift1'
 *    '<S264>/Bit Shift3'
 */
void npc_controller_BitShift1(uint16_T rtu_u, rtB_BitShift1_npc_controller
  *localB)
{
  /* MATLAB Function: '<S315>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S327>:1' */
  /* '<S327>:1:6' */
  localB->y = rtu_u << 4;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift2'
 *    '<S264>/Bit Shift4'
 */
void npc_controller_BitShift2(uint16_T rtu_u, rtB_BitShift2_npc_controller
  *localB)
{
  /* MATLAB Function: '<S319>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S331>:1' */
  /* '<S331>:1:6' */
  localB->y = rtu_u << 5;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift3'
 *    '<S264>/Bit Shift5'
 */
void npc_controller_BitShift3(uint16_T rtu_u, rtB_BitShift3_npc_controller
  *localB)
{
  /* MATLAB Function: '<S320>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S332>:1' */
  /* '<S332>:1:6' */
  localB->y = rtu_u << 6;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift4'
 *    '<S264>/Bit Shift7'
 */
void npc_controller_BitShift4(uint16_T rtu_u, rtB_BitShift4_npc_controller
  *localB)
{
  /* MATLAB Function: '<S321>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S333>:1' */
  /* '<S333>:1:6' */
  localB->y = rtu_u << 8;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift5'
 *    '<S264>/Bit Shift8'
 */
void npc_controller_BitShift5(uint16_T rtu_u, rtB_BitShift5_npc_controller
  *localB)
{
  /* MATLAB Function: '<S322>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S334>:1' */
  /* '<S334>:1:6' */
  localB->y = rtu_u << 9;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift6'
 *    '<S264>/Bit Shift6'
 */
void npc_controller_BitShift6(uint16_T rtu_u, rtB_BitShift6_npc_controller
  *localB)
{
  /* MATLAB Function: '<S323>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S335>:1' */
  /* '<S335>:1:6' */
  localB->y = rtu_u << 7;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift7'
 *    '<S264>/Bit Shift9'
 */
void npc_controller_BitShift7(uint16_T rtu_u, rtB_BitShift7_npc_controller
  *localB)
{
  /* MATLAB Function: '<S324>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S336>:1' */
  /* '<S336>:1:6' */
  localB->y = rtu_u << 10;
}

/*
 * Output and update for atomic system:
 *    '<S267>/Bit Shift8'
 *    '<S264>/Bit Shift27'
 */
void npc_controller_BitShift8(uint16_T rtu_u, rtB_BitShift8_npc_controller
  *localB)
{
  /* MATLAB Function: '<S325>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S337>:1' */
  /* '<S337>:1:6' */
  localB->y = rtu_u << 11;
}

/* System initialize for atomic system: */
void npc_contr_MATLABSystem_Init(rtDW_MATLABSystem_npc_controlle *localDW)
{
  /* Start for MATLABSystem: '<S294>/MATLAB System' */
  localDW->objisempty = true;

  /*  Perform one-time calculations, such as computing constants */
  localDW->obj.status = 0U;
  localDW->obj.ref = 0U;
  localDW->obj.now = 0U;
  localDW->obj.cnt = 0U;

  /* InitializeConditions for MATLABSystem: '<S294>/MATLAB System' */
  /*  Initialize / reset discrete-state properties */
  localDW->status = localDW->obj.status;
  localDW->ref = localDW->obj.status;
  localDW->now = localDW->obj.status;
  localDW->cnt = localDW->obj.status;
}

/* Output and update for atomic system: */
void npc_controller_MATLABSystem(uint16_T rtu_0, uint16_T rtu_1, uint16_T rtu_2,
  uint16_T rtu_5, rtB_MATLABSystem_npc_controller *localB,
  rtDW_MATLABSystem_npc_controlle *localDW)
{
  uint16_T qY;

  /* MATLABSystem: '<S294>/MATLAB System' */
  /*  Implement algorithm. Calculate y as a function of input u and */
  /*  discrete states. */
  /* if(assert_lim>deassert_lim) %assert above */
  if (rtu_0 >= rtu_1) {
    localDW->obj.now = rtu_5;
    qY = localDW->obj.now - localDW->obj.ref;
    if (qY > localDW->obj.now) {
      qY = 0U;
    }

    localDW->obj.cnt = qY;
    if (localDW->obj.cnt > rtu_2) {
      localDW->obj.status = 1U;
      localDW->obj.cnt = 0U;
    }
  } else {
    localDW->obj.ref = rtu_5;
  }

  /* MATLABSystem: '<S294>/MATLAB System' */
  /* elseif(assert_lim<deassert_lim) %assert under */
  /*     if(input<=assert_lim) */
  /*         obj.now = tmr; */
  /*         obj.cnt = obj.now - obj.ref; */
  /*         if(obj.cnt>assert_vld) */
  /*             obj.status = uint16(1); */
  /*             obj.cnt = uint16(0); */
  /*         end */
  /*     else */
  /*         obj.ref = tmr; */
  /*     end */
  /* else %invalid case */
  /* end */
  localB->MATLABSystem = localDW->obj.status;

  /* MATLABSystem: '<S294>/MATLAB System' */
  localDW->status = localDW->obj.status;
  localDW->ref = localDW->obj.ref;
  localDW->now = localDW->obj.now;
  localDW->cnt = localDW->obj.cnt;
}

/* Termination for atomic system: */
void npc_contr_MATLABSystem_Term(rtDW_MATLABSystem_npc_controlle *localDW)
{
  /* Terminate for MATLABSystem: '<S294>/MATLAB System' */
  localDW->status = localDW->obj.status;
  localDW->ref = localDW->obj.ref;
  localDW->now = localDW->obj.now;
  localDW->cnt = localDW->obj.cnt;
}

/* Model step function for TID0 */
void npc_controller_step0(void)        /* Explicit Task: timer_1ms */
{
  {                                    /* Explicit Task: timer_1ms */
    rate_monotonic_scheduler();
  }

  /* Outputs for Atomic SubSystem: '<S342>/periodic_timer1' */
  npc_control_periodic_timer1(&npc_controller_DWork.cnt_1ms);

  /* End of Outputs for SubSystem: '<S342>/periodic_timer1' */
}

/* Model step function for TID1 */
void npc_controller_step1(void)        /* Sample time: [0.001s, 0.0s] */
{
  CMPSS_ModuleVal_type COMPModuleValue;
  uint16_T latchoutref;

  /* S-Function (c280xgpio_do): '<S152>/AC_OK_GPIO41' incorporates:
   *  DataStoreRead: '<S152>/Data Store Read2'
   */
  {
    if (npc_controller_DWork.ac_ok) {
      GpioDataRegs.GPBSET.bit.GPIO41 = 1U;
    } else {
      GpioDataRegs.GPBCLEAR.bit.GPIO41 = 1U;
    }
  }

  /* S-Function (c280xgpio_do): '<S152>/RELAY_GPIO4_EPWM3A1' incorporates:
   *  DataStoreRead: '<S152>/Data Store Read'
   */
  {
    if (npc_controller_DWork.relay_ctrl) {
      GpioDataRegs.GPASET.bit.GPIO4 = 1U;
    } else {
      GpioDataRegs.GPACLEAR.bit.GPIO4 = 1U;
    }
  }

  /* S-Function (c280xgpio_do): '<S152>/PFC_OK_GPIO58' incorporates:
   *  DataStoreRead: '<S152>/Data Store Read1'
   */
  {
    if (npc_controller_DWork.pfc_ok) {
      GpioDataRegs.GPBSET.bit.GPIO58 = 1U;
    } else {
      GpioDataRegs.GPBCLEAR.bit.GPIO58 = 1U;
    }
  }

  /* MATLABSystem: '<S339>/CMPSS1H' */
  COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain4, 1U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 1U);

  /* MATLABSystem: '<S339>/CMPSS2H' */
  COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain1, 1U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 1U);

  /* MATLABSystem: '<S339>/CMPSS4H' */
  COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain2, 1U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 1U);

  /* MATLABSystem: '<S339>/CMPSS1L' */
  COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain5, 0U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 0U);

  /* MATLABSystem: '<S339>/CMPSS2L' */
  COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain6, 0U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 0U);

  /* MATLABSystem: '<S339>/CMPSS4L' */
  COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain3, 0U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 0U);

  /* End of Outputs for S-Function (fcgen): '<S156>/Function-Call Generator1' */
}

/* Model step function for TID2 */
void npc_controller_step2(void)        /* Sample time: [0.02s, 0.0s] */
{
  real32_T f32IoutTarget;
  real32_T f32V2GPwrTarget;
  real32_T f32VoutTarget;
  uint16_T u8AliveCounter;
  uint16_T u8GridPhaseType;
  uint16_T u8ModeCmd;
  uint16_T u8RedunModeCmd;
  uint16_T u8SinglePhaseLeg;

  /* Chart: '<S152>/Chart1' */
  /* Gateway: IDLE_AND_TIMER/codegen/Chart1 */
  /* During: IDLE_AND_TIMER/codegen/Chart1 */
  if (npc_controller_DWork.is_active_c3_npc_controller == 0U) {
    /* Entry: IDLE_AND_TIMER/codegen/Chart1 */
    npc_controller_DWork.is_active_c3_npc_controller = 1U;

    /* Outputs for Function Call SubSystem: '<S152>/CAN_Task' */
    /* Entry Internal: IDLE_AND_TIMER/codegen/Chart1 */
    /* Transition: '<S154>:48' */
    /* Entry 'INIT': '<S154>:45' */
    /* Event: '<S154>:28' */
    npc_controller_CAN_Task(&npc_controller_DWork.b00_DebugEnabled,
      &npc_controller_DWork.b01_ReadRequest,
      &npc_controller_DWork.b05_MB10Received,
      &npc_controller_DWork.b06_MB11Received,
      &npc_controller_DWork.b07_MB12Received, &npc_controller_DWork.f32IinA,
      &npc_controller_DWork.f32IinB, &npc_controller_DWork.f32IinC,
      &f32IoutTarget, &npc_controller_DWork.f32IphaseA,
      &npc_controller_DWork.f32IphaseB, &npc_controller_DWork.f32IphaseC,
      &f32V2GPwrTarget, &npc_controller_DWork.f32Vaux,
      &npc_controller_DWork.f32VinA, &npc_controller_DWork.f32VinB,
      &npc_controller_DWork.f32VinC, &f32VoutTarget,
      &npc_controller_DWork.f32Vpfc, &npc_controller_DWork.f32VpfcMid,
      &npc_controller_DWork.sPriFault, &npc_controller_DWork.sPriStatus,
      &npc_controller_DWork.u16Debug0, &npc_controller_DWork.u16Debug1,
      &npc_controller_DWork.u16Debug2, &npc_controller_DWork.u16Debug3,
      &npc_controller_DWork.u16Debug4, &npc_controller_DWork.u16Debug5,
      &npc_controller_DWork.u16Reserved1, &npc_controller_DWork.u16TxDelayCount,
      &u8AliveCounter, npc_controller_DWork.u8CanDataRx10,
      npc_controller_DWork.u8CanDataRx11, npc_controller_DWork.u8CanDataRx12,
      &npc_controller_DWork.u8CanTxIndex, npc_controller_DWork.u8FwRevData,
      &u8GridPhaseType, &u8ModeCmd, &npc_controller_DWork.u8PriFutEnable,
      &npc_controller_DWork.u8RdReqMsgPntr, &u8RedunModeCmd,
      &npc_controller_DWork.u8Reserved1, &u8SinglePhaseLeg,
      &npc_controller_DWork.u8TclllcP1, &npc_controller_DWork.u8TclllcP2,
      &npc_controller_DWork.u8ThermalFlags, &npc_controller_DWork.u8TnpcA,
      &npc_controller_DWork.u8TnpcB, &npc_controller_DWork.u8TnpcC,
      &npc_controller_B.CAN_Task);

    /* End of Outputs for SubSystem: '<S152>/CAN_Task' */
  } else {
    /* Outputs for Function Call SubSystem: '<S152>/CAN_Task' */
    /* During 'INIT': '<S154>:45' */
    /* Transition: '<S154>:49' */
    /* Entry 'INIT': '<S154>:45' */
    /* Event: '<S154>:28' */
    npc_controller_CAN_Task(&npc_controller_DWork.b00_DebugEnabled,
      &npc_controller_DWork.b01_ReadRequest,
      &npc_controller_DWork.b05_MB10Received,
      &npc_controller_DWork.b06_MB11Received,
      &npc_controller_DWork.b07_MB12Received, &npc_controller_DWork.f32IinA,
      &npc_controller_DWork.f32IinB, &npc_controller_DWork.f32IinC,
      &f32IoutTarget, &npc_controller_DWork.f32IphaseA,
      &npc_controller_DWork.f32IphaseB, &npc_controller_DWork.f32IphaseC,
      &f32V2GPwrTarget, &npc_controller_DWork.f32Vaux,
      &npc_controller_DWork.f32VinA, &npc_controller_DWork.f32VinB,
      &npc_controller_DWork.f32VinC, &f32VoutTarget,
      &npc_controller_DWork.f32Vpfc, &npc_controller_DWork.f32VpfcMid,
      &npc_controller_DWork.sPriFault, &npc_controller_DWork.sPriStatus,
      &npc_controller_DWork.u16Debug0, &npc_controller_DWork.u16Debug1,
      &npc_controller_DWork.u16Debug2, &npc_controller_DWork.u16Debug3,
      &npc_controller_DWork.u16Debug4, &npc_controller_DWork.u16Debug5,
      &npc_controller_DWork.u16Reserved1, &npc_controller_DWork.u16TxDelayCount,
      &u8AliveCounter, npc_controller_DWork.u8CanDataRx10,
      npc_controller_DWork.u8CanDataRx11, npc_controller_DWork.u8CanDataRx12,
      &npc_controller_DWork.u8CanTxIndex, npc_controller_DWork.u8FwRevData,
      &u8GridPhaseType, &u8ModeCmd, &npc_controller_DWork.u8PriFutEnable,
      &npc_controller_DWork.u8RdReqMsgPntr, &u8RedunModeCmd,
      &npc_controller_DWork.u8Reserved1, &u8SinglePhaseLeg,
      &npc_controller_DWork.u8TclllcP1, &npc_controller_DWork.u8TclllcP2,
      &npc_controller_DWork.u8ThermalFlags, &npc_controller_DWork.u8TnpcA,
      &npc_controller_DWork.u8TnpcB, &npc_controller_DWork.u8TnpcC,
      &npc_controller_B.CAN_Task);

    /* End of Outputs for SubSystem: '<S152>/CAN_Task' */
  }

  /* End of Chart: '<S152>/Chart1' */
}

/* Model initialize function */
void npc_controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)npc_controller_M, 0,
                sizeof(RT_MODEL_npc_controller));

  /* block I/O */
  (void) memset(((void *) &npc_controller_B), 0,
                sizeof(BlockIO_npc_controller));

  {
    npc_controller_B.CAN_Task.CANPack1 = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_p = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_g = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_i = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_c = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_h = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_k = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_l = CAN_DATATYPE_GROUND;
  }

  /* custom signals */
  cpu2cla_angle = 0.0;
  cpu2cla_zc_a = 0.0;
  cla2cpu_Vpk = 0.0;
  cpu2cla_ref = 0.0F;
  cla2cpu_Ipk = 0.0F;
  cla_pida_temp2 = 0.0F;
  cla_pida_temp1 = 0.0F;
  cpu2cla_vbulk = 0.0F;
  cpu2cla_vmid = 0.0F;
  cpu2cla_vbn = 0.0F;
  cpu2cla_ic = 0.0F;
  cpu2cla_vcn = 0.0F;
  cpu2cla_ia = 0.0F;
  cpu2cla_van = 0.0F;
  cpu2cla_ib = 0.0F;
  cpu2cla_control_en = false;
  cpu2cla_pha_en = false;
  cpu2cla_phb_en = false;
  cpu2cla_phc_en = false;
  cpu2cla_pfc_ok2 = false;

  /* states (dwork) */
  (void) memset((void *)&npc_controller_DWork, 0,
                sizeof(D_Work_npc_controller));

  /* custom states */
  vbulk_pid1 = 0.0F;
  vbulk_pid2 = 0.0F;
  vbulk_pid3 = 0.0F;
  vbulk_pid4 = 0.0F;
  ia_pid2 = 0.0F;
  ia_pid1 = 0.0F;
  ia_pid3 = 0.0F;
  ia_pid4 = 0.0F;
  ss_delay_temp = 0.0F;
  ib_pid3 = 0.0F;
  ib_pid1 = 0.0F;
  ib_pid2 = 0.0F;
  ib_pid4 = 0.0F;
  ic_pid3 = 0.0F;
  ic_pid1 = 0.0F;
  ic_pid2 = 0.0F;
  ic_pid4 = 0.0F;

  /* external inputs */
  npc_controller_U.sim_adc_quantized = 0.0;

  {
    CMPSS_ModuleVal_type COMPModuleValue;

    /* Start for S-Function (c280xgpio_do): '<S152>/AC_OK_GPIO41' */
    EALLOW;
    GpioCtrlRegs.GPBMUX1.all &= 0xFFF3FFFFU;
    GpioCtrlRegs.GPBDIR.all |= 0x200U;
    EDIS;

    /* Start for S-Function (c280xgpio_do): '<S152>/RELAY_GPIO4_EPWM3A1' */
    EALLOW;
    GpioCtrlRegs.GPAMUX1.all &= 0xFFFFFCFFU;
    GpioCtrlRegs.GPADIR.all |= 0x10U;
    EDIS;

    /* Start for S-Function (c280xgpio_do): '<S152>/PFC_OK_GPIO58' */
    EALLOW;
    GpioCtrlRegs.GPBMUX2.all &= 0xFFCFFFFFU;
    GpioCtrlRegs.GPBDIR.all |= 0x4000000U;
    EDIS;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory28' */
    npc_controller_DWork.cnt_calib = 1U;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget1' */
    npc_controller_DWork.f32GainLineCurrentCS = 0.0412775092F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget2' */
    npc_controller_DWork.f32GainVbulk = 0.226365402F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget3' */
    npc_controller_DWork.f32GainVmid = 0.12730819F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget4' */
    npc_controller_DWork.f32GainLineCurrentHE = 0.0402930416F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget6' */
    npc_controller_DWork.f32GainLineVoltage = 0.44794932F;

    /* SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' incorporates:
     *  SubSystem: '<Root>/CONTROL'
     */
    /* System initialize for function-call system: '<Root>/CONTROL' */

    /* SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/GET_ADC'
     */
    /* SystemInitialize for S-Function (fcgen): '<S64>/Function-Call Generator' incorporates:
     *  SubSystem: '<S64>/ADCA'
     */
    /* Start for S-Function (c2802xadc): '<S65>/ADC18' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC0 ();

    /* Start for S-Function (c2802xadc): '<S65>/ADC5' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC4 ();

    /* Start for S-Function (c2802xadc): '<S65>/ADC7' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC3 ();

    /* Start for S-Function (c2802xadc): '<S65>/ADC3' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC2 ();

    /* Start for S-Function (c2802xadc): '<S65>/ADC6' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC5 ();

    /* Start for S-Function (c2802xadc): '<S65>/ADC17' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC6 ();

    /* Start for S-Function (c2802xadc): '<S65>/ADC8' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC7 ();

    /* SystemInitialize for S-Function (fcgen): '<S64>/Function-Call Generator' incorporates:
     *  SubSystem: '<S64>/ADCC'
     */
    /* Start for S-Function (c2802xadc): '<S66>/ADC6' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC0 ();

    /* Start for S-Function (c2802xadc): '<S66>/ADC2' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC1 ();

    /* Start for S-Function (c2802xadc): '<S66>/ADC5' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC2 ();

    /* Start for S-Function (c2802xadc): '<S66>/ADC3' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC3 ();

    /* Start for S-Function (c2802xadc): '<S66>/ADC4' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC4 ();

    /* End of SystemInitialize for S-Function (fcgen): '<S64>/Function-Call Generator' */

    /* SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/CONTROL'
     */
    /* SystemInitialize for IfAction SubSystem: '<S8>/false' */
    /* SystemInitialize for S-Function (c2000cla): '<S13>/CLA Task1' incorporates:
     *  SubSystem: '<S13>/CLA_CONTROL'
     */
    /* System initialize for function-call system: '<S13>/CLA_CONTROL' */

    /* SystemInitialize for S-Function (fcgen): '<S14>/Function-Call Generator' incorporates:
     *  SubSystem: '<S14>/CONTROL'
     */
    /* Start for S-Function (c2802xpwm): '<S26>/L1' */

    /*** Initialize ePWM7 modules ***/
    {
      /*  // Time Base Control Register
         EPwm7Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm7Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm7Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm7Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm7Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm7Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm7Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm7Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm7Regs.TBCTL.all = (EPwm7Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm7Regs.TBCTL2.all = (EPwm7Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm7Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm7Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm7Regs.TBPHS.all = (EPwm7Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm7Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm7Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm7Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm7Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm7Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm7Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm7Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm7Regs.CMPCTL.all = (EPwm7Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm7Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm7Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm7Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm7Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm7Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm7Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm7Regs.CMPCTL2.all = (EPwm7Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm7Regs.CMPA.bit.CMPA = 335U;  // Counter Compare A Register
      EPwm7Regs.CMPB.bit.CMPB = 435U;  // Counter Compare B Register
      EPwm7Regs.CMPC = 32000U;         // Counter Compare C Register
      EPwm7Regs.CMPD = 32000U;         // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm7Regs.AQCTLA.all = 96U;
                               // Action Qualifier Control Register For Output A
      EPwm7Regs.AQCTLB.all = 2304U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm7Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm7Regs.AQSFRC.all = (EPwm7Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm7Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm7Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm7Regs.AQCSFRC.all = (EPwm7Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm7Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm7Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm7Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm7Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm7Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm7Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm7Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm7Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm7Regs.DBCTL.all = (EPwm7Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm7Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm7Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm7Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm7Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm7Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm7Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM7SOC Period Select
         EPwm7Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm7Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm7Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm7Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm7Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM7SOCB Period Select
         EPwm7Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm7Regs.ETSEL.bit.INTEN                = 0U;          // EPWM7INTn Enable
         EPwm7Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm7Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm7Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM7INTn Period Select
         EPwm7Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm7Regs.ETSEL.all = (EPwm7Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm7Regs.ETPS.all = (EPwm7Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm7Regs.ETSOCPS.all = (EPwm7Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm7Regs.ETINTPS.all = (EPwm7Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm7Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm7Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm7Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm7Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm7Regs.PCCTL.all = (EPwm7Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm7Regs.TZSEL.all = 49920U;    // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm7Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM7A
         EPwm7Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM7B
         EPwm7Regs.TZCTL.bit.DCAEVT1              = 2U;          // EPWM7A action on DCAEVT1
         EPwm7Regs.TZCTL.bit.DCAEVT2              = 2U;          // EPWM7A action on DCAEVT2
         EPwm7Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM7B action on DCBEVT1
         EPwm7Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM7B action on DCBEVT2
       */
      EPwm7Regs.TZCTL.all = (EPwm7Regs.TZCTL.all & ~0xFFFU) | 0xFAAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm7Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm7Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm7Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm7Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm7Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm7Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm7Regs.TZEINT.all = (EPwm7Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm7Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm7Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm7Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 1U;          // DCAEVT1 Force Sync Signal
         EPwm7Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm7Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm7Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm7Regs.DCACTL.all = (EPwm7Regs.DCACTL.all & ~0x30FU) | 0x6U;

      /*	// Digital Compare B Control Register
         EPwm7Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm7Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm7Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 1U;          // DCBEVT1 Force Sync Signal
         EPwm7Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm7Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm7Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm7Regs.DCBCTL.all = (EPwm7Regs.DCBCTL.all & ~0x30FU) | 0x2U;

      /*	// Digital Compare Trip Select Register
         EPwm7Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 3U;          // Digital Compare A High COMP Input Select

         EPwm7Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 4U;          // Digital Compare A Low COMP Input Select
         EPwm7Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 3U;          // Digital Compare B High COMP Input Select
         EPwm7Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm7Regs.DCTRIPSEL.all = (EPwm7Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1343U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm7Regs.TZDCSEL.bit.DCAEVT1            = 2U;          // Digital Compare Output A Event 1
         EPwm7Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm7Regs.TZDCSEL.bit.DCBEVT1            = 2U;          // Digital Compare Output B Event 1
         EPwm7Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm7Regs.TZDCSEL.all = (EPwm7Regs.TZDCSEL.all & ~0xFFFU) | 0x82U;

      /*	// Digital Compare Filter Control Register
         EPwm7Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm7Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm7Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm7Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm7Regs.DCFCTL.all = (EPwm7Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm7Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm7Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm7Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm7Regs.DCCAPCTL.all = (EPwm7Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm7Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm7Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm7Regs.HRCNFG.all = (EPwm7Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm7Regs.EPWMXLINK.bit.TBPRDLINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPALINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPBLINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPCLINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPDLINK = 6U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm7Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm7Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm7Regs.HRPCTL.all = (EPwm7Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S26>/L2' incorporates:
     *  Constant: '<S26>/OFF'
     */

    /*** Initialize ePWM9 modules ***/
    {
      /*  // Time Base Control Register
         EPwm9Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm9Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm9Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm9Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm9Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm9Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm9Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm9Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm9Regs.TBCTL.all = (EPwm9Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm9Regs.TBCTL2.all = (EPwm9Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm9Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm9Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm9Regs.TBPHS.all = (EPwm9Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm9Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm9Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm9Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm9Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm9Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm9Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm9Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm9Regs.CMPCTL.all = (EPwm9Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm9Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm9Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm9Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm9Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm9Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm9Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm9Regs.CMPCTL2.all = (EPwm9Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm9Regs.CMPA.bit.CMPA = 335U;  // Counter Compare A Register
      EPwm9Regs.CMPB.bit.CMPB = 435U;  // Counter Compare B Register
      EPwm9Regs.CMPC = 32000U;         // Counter Compare C Register
      EPwm9Regs.CMPD = 32000U;         // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm9Regs.AQCTLA.all = 96U;
                               // Action Qualifier Control Register For Output A
      EPwm9Regs.AQCTLB.all = 2304U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm9Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm9Regs.AQSFRC.all = (EPwm9Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm9Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm9Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm9Regs.AQCSFRC.all = (EPwm9Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm9Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm9Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm9Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm9Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm9Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm9Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm9Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm9Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm9Regs.DBCTL.all = (EPwm9Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm9Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm9Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm9Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm9Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm9Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm9Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM9SOC Period Select
         EPwm9Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm9Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm9Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm9Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm9Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM9SOCB Period Select
         EPwm9Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm9Regs.ETSEL.bit.INTEN                = 0U;          // EPWM9INTn Enable
         EPwm9Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm9Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm9Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM9INTn Period Select
         EPwm9Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm9Regs.ETSEL.all = (EPwm9Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm9Regs.ETPS.all = (EPwm9Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm9Regs.ETSOCPS.all = (EPwm9Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm9Regs.ETINTPS.all = (EPwm9Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm9Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm9Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm9Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm9Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm9Regs.PCCTL.all = (EPwm9Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm9Regs.TZSEL.all = 49920U;    // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm9Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM9A
         EPwm9Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM9B
         EPwm9Regs.TZCTL.bit.DCAEVT1              = 2U;          // EPWM9A action on DCAEVT1
         EPwm9Regs.TZCTL.bit.DCAEVT2              = 2U;          // EPWM9A action on DCAEVT2
         EPwm9Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM9B action on DCBEVT1
         EPwm9Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM9B action on DCBEVT2
       */
      EPwm9Regs.TZCTL.all = (EPwm9Regs.TZCTL.all & ~0xFFFU) | 0xFAAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm9Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm9Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm9Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm9Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm9Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm9Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm9Regs.TZEINT.all = (EPwm9Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm9Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm9Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm9Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 1U;          // DCAEVT1 Force Sync Signal
         EPwm9Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm9Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm9Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm9Regs.DCACTL.all = (EPwm9Regs.DCACTL.all & ~0x30FU) | 0x6U;

      /*	// Digital Compare B Control Register
         EPwm9Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm9Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm9Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 1U;          // DCBEVT1 Force Sync Signal
         EPwm9Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm9Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm9Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm9Regs.DCBCTL.all = (EPwm9Regs.DCBCTL.all & ~0x30FU) | 0x2U;

      /*	// Digital Compare Trip Select Register
         EPwm9Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 6U;          // Digital Compare A High COMP Input Select

         EPwm9Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 7U;          // Digital Compare A Low COMP Input Select
         EPwm9Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 6U;          // Digital Compare B High COMP Input Select
         EPwm9Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm9Regs.DCTRIPSEL.all = (EPwm9Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1676U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm9Regs.TZDCSEL.bit.DCAEVT1            = 2U;          // Digital Compare Output A Event 1
         EPwm9Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm9Regs.TZDCSEL.bit.DCBEVT1            = 2U;          // Digital Compare Output B Event 1
         EPwm9Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm9Regs.TZDCSEL.all = (EPwm9Regs.TZDCSEL.all & ~0xFFFU) | 0x82U;

      /*	// Digital Compare Filter Control Register
         EPwm9Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm9Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm9Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm9Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm9Regs.DCFCTL.all = (EPwm9Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm9Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm9Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm9Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm9Regs.DCCAPCTL.all = (EPwm9Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm9Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm9Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm9Regs.HRCNFG.all = (EPwm9Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm9Regs.EPWMXLINK.bit.TBPRDLINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPALINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPBLINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPCLINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPDLINK = 8U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm9Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm9Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm9Regs.HRPCTL.all = (EPwm9Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S26>/N' incorporates:
     *  Constant: '<S26>/neutral_OFF1'
     */

    /*** Initialize ePWM11 modules ***/
    {
      /*  // Time Base Control Register
         EPwm11Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm11Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm11Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm11Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm11Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm11Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm11Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm11Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm11Regs.TBCTL.all = (EPwm11Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm11Regs.TBCTL2.all = (EPwm11Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm11Regs.TBPRD = 1538U;        // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm11Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm11Regs.TBPHS.all = (EPwm11Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm11Regs.TBCTR = 0x0000U;      /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm11Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm11Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm11Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm11Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm11Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm11Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm11Regs.CMPCTL.all = (EPwm11Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm11Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm11Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm11Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm11Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm11Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm11Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm11Regs.CMPCTL2.all = (EPwm11Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm11Regs.CMPA.bit.CMPA = 335U; // Counter Compare A Register
      EPwm11Regs.CMPB.bit.CMPB = 435U; // Counter Compare B Register
      EPwm11Regs.CMPC = 32000U;        // Counter Compare C Register
      EPwm11Regs.CMPD = 32000U;        // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm11Regs.AQCTLA.all = 0U;
                               // Action Qualifier Control Register For Output A
      EPwm11Regs.AQCTLB.all = 0U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm11Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm11Regs.AQSFRC.all = (EPwm11Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm11Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm11Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm11Regs.AQCSFRC.all = (EPwm11Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm11Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm11Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm11Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm11Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm11Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm11Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm11Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm11Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm11Regs.DBCTL.all = (EPwm11Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm11Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm11Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm11Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm11Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm11Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm11Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM11SOC Period Select
         EPwm11Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm11Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm11Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm11Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm11Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM11SOCB Period Select
         EPwm11Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm11Regs.ETSEL.bit.INTEN                = 0U;          // EPWM11INTn Enable
         EPwm11Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm11Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm11Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM11INTn Period Select
         EPwm11Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm11Regs.ETSEL.all = (EPwm11Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm11Regs.ETPS.all = (EPwm11Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm11Regs.ETSOCPS.all = (EPwm11Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm11Regs.ETINTPS.all = (EPwm11Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm11Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm11Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm11Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm11Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm11Regs.PCCTL.all = (EPwm11Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm11Regs.TZSEL.all = 49920U;   // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm11Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM11A
         EPwm11Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM11B
         EPwm11Regs.TZCTL.bit.DCAEVT1              = 2U;          // EPWM11A action on DCAEVT1
         EPwm11Regs.TZCTL.bit.DCAEVT2              = 2U;          // EPWM11A action on DCAEVT2
         EPwm11Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM11B action on DCBEVT1
         EPwm11Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM11B action on DCBEVT2
       */
      EPwm11Regs.TZCTL.all = (EPwm11Regs.TZCTL.all & ~0xFFFU) | 0xFAAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm11Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm11Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm11Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm11Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm11Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm11Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm11Regs.TZEINT.all = (EPwm11Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm11Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm11Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm11Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 1U;          // DCAEVT1 Force Sync Signal
         EPwm11Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm11Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm11Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm11Regs.DCACTL.all = (EPwm11Regs.DCACTL.all & ~0x30FU) | 0x6U;

      /*	// Digital Compare B Control Register
         EPwm11Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm11Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm11Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 1U;          // DCBEVT1 Force Sync Signal
         EPwm11Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm11Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm11Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm11Regs.DCBCTL.all = (EPwm11Regs.DCBCTL.all & ~0x30FU) | 0x2U;

      /*	// Digital Compare Trip Select Register
         EPwm11Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 4U;          // Digital Compare A High COMP Input Select

         EPwm11Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 9U;          // Digital Compare A Low COMP Input Select
         EPwm11Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 4U;          // Digital Compare B High COMP Input Select
         EPwm11Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm11Regs.DCTRIPSEL.all = (EPwm11Regs.DCTRIPSEL.all & ~ 0xFFFFU) |
        0x1494U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm11Regs.TZDCSEL.bit.DCAEVT1            = 2U;          // Digital Compare Output A Event 1
         EPwm11Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm11Regs.TZDCSEL.bit.DCBEVT1            = 2U;          // Digital Compare Output B Event 1
         EPwm11Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm11Regs.TZDCSEL.all = (EPwm11Regs.TZDCSEL.all & ~0xFFFU) | 0x82U;

      /*	// Digital Compare Filter Control Register
         EPwm11Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm11Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm11Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm11Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm11Regs.DCFCTL.all = (EPwm11Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm11Regs.DCFOFFSET = 0U;       // Digital Compare Filter Offset Register
      EPwm11Regs.DCFWINDOW = 0U;       // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm11Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm11Regs.DCCAPCTL.all = (EPwm11Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm11Regs.HRCNFG.bit.SWAPAB              = 1U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm11Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm11Regs.HRCNFG.all = (EPwm11Regs.HRCNFG.all & ~0xA0U) | 0x80U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm11Regs.EPWMXLINK.bit.TBPRDLINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPALINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPBLINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPCLINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPDLINK = 10U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm11Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm11Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm11Regs.HRPCTL.all = (EPwm11Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S26>/ePWM1 - EXTSYNC1' */

    /*** Initialize ePWM1 modules ***/
    {
      /*  // Time Base Control Register
         EPwm1Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm1Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm1Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm1Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm1Regs.TBCTL.bit.PHSEN                = 0U;          // Phase Load Enable
         EPwm1Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm1Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm1Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm1Regs.TBCTL.all = (EPwm1Regs.TBCTL.all & ~0x3FFFU) | 0x12U;
      EPwm1Regs.TBCTL2.all = (EPwm1Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm1Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm1Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm1Regs.TBPHS.all = (EPwm1Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm1Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm1Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm1Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm1Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm1Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm1Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm1Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm1Regs.CMPCTL.all = (EPwm1Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm1Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm1Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm1Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm1Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm1Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm1Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm1Regs.CMPCTL2.all = (EPwm1Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm1Regs.CMPA.bit.CMPA = 154U;  // Counter Compare A Register
      EPwm1Regs.CMPB.bit.CMPB = 154U;  // Counter Compare B Register
      EPwm1Regs.CMPC = 0U;             // Counter Compare C Register
      EPwm1Regs.CMPD = 0U;             // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm1Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm1Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm1Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm1Regs.AQSFRC.all = (EPwm1Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm1Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm1Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm1Regs.AQCSFRC.all = (EPwm1Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm1Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm1Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm1Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm1Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm1Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm1Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm1Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm1Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm1Regs.DBCTL.all = (EPwm1Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm1Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm1Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm1Regs.ETSEL.bit.SOCAEN               = 1U;          // Start of Conversion A Enable
         EPwm1Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm1Regs.ETSEL.bit.SOCASEL              = 2U;          // Start of Conversion A Select
         EPwm1Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM1SOC Period Select
         EPwm1Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm1Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm1Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm1Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm1Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM1SOCB Period Select
         EPwm1Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm1Regs.ETSEL.bit.INTEN                = 0U;          // EPWM1INTn Enable
         EPwm1Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm1Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm1Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM1INTn Period Select
         EPwm1Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm1Regs.ETSEL.all = (EPwm1Regs.ETSEL.all & ~0xFF7FU) | 0x1A01U;
      EPwm1Regs.ETPS.all = (EPwm1Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm1Regs.ETSOCPS.all = (EPwm1Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm1Regs.ETINTPS.all = (EPwm1Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm1Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm1Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm1Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm1Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm1Regs.PCCTL.all = (EPwm1Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm1Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm1Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM1A
         EPwm1Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM1B
         EPwm1Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM1A action on DCAEVT1
         EPwm1Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM1A action on DCAEVT2
         EPwm1Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM1B action on DCBEVT1
         EPwm1Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM1B action on DCBEVT2
       */
      EPwm1Regs.TZCTL.all = (EPwm1Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm1Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm1Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm1Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm1Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm1Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm1Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm1Regs.TZEINT.all = (EPwm1Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm1Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm1Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm1Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm1Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm1Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm1Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm1Regs.DCACTL.all = (EPwm1Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm1Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm1Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm1Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm1Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm1Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm1Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm1Regs.DCBCTL.all = (EPwm1Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm1Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm1Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm1Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm1Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm1Regs.DCTRIPSEL.all = (EPwm1Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm1Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm1Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm1Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm1Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm1Regs.TZDCSEL.all = (EPwm1Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm1Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm1Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm1Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm1Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm1Regs.DCFCTL.all = (EPwm1Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm1Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm1Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm1Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm1Regs.DCCAPCTL.all = (EPwm1Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm1Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm1Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm1Regs.HRCNFG.all = (EPwm1Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm1Regs.EPWMXLINK.bit.TBPRDLINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPALINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPBLINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPCLINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPDLINK = 0U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm1Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm1Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm1Regs.HRPCTL.all = (EPwm1Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S26>/ePWM5 - Unused' */

    /*** Initialize ePWM5 modules ***/
    {
      /*  // Time Base Control Register
         EPwm5Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm5Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm5Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm5Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm5Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm5Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm5Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm5Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm5Regs.TBCTL.all = (EPwm5Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm5Regs.TBCTL2.all = (EPwm5Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm5Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm5Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm5Regs.TBPHS.all = (EPwm5Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm5Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm5Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm5Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm5Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm5Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm5Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm5Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm5Regs.CMPCTL.all = (EPwm5Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm5Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm5Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm5Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm5Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm5Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm5Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm5Regs.CMPCTL2.all = (EPwm5Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm5Regs.CMPA.bit.CMPA = 154U;  // Counter Compare A Register
      EPwm5Regs.CMPB.bit.CMPB = 154U;  // Counter Compare B Register
      EPwm5Regs.CMPC = 0U;             // Counter Compare C Register
      EPwm5Regs.CMPD = 0U;             // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm5Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm5Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm5Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm5Regs.AQSFRC.all = (EPwm5Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm5Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm5Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm5Regs.AQCSFRC.all = (EPwm5Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm5Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm5Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm5Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm5Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm5Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm5Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm5Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm5Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm5Regs.DBCTL.all = (EPwm5Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm5Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm5Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm5Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm5Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm5Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm5Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM5SOC Period Select
         EPwm5Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm5Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm5Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm5Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm5Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM5SOCB Period Select
         EPwm5Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm5Regs.ETSEL.bit.INTEN                = 0U;          // EPWM5INTn Enable
         EPwm5Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm5Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm5Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM5INTn Period Select
         EPwm5Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm5Regs.ETSEL.all = (EPwm5Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm5Regs.ETPS.all = (EPwm5Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm5Regs.ETSOCPS.all = (EPwm5Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm5Regs.ETINTPS.all = (EPwm5Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm5Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm5Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm5Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm5Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm5Regs.PCCTL.all = (EPwm5Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm5Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm5Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM5A
         EPwm5Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM5B
         EPwm5Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM5A action on DCAEVT1
         EPwm5Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM5A action on DCAEVT2
         EPwm5Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM5B action on DCBEVT1
         EPwm5Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM5B action on DCBEVT2
       */
      EPwm5Regs.TZCTL.all = (EPwm5Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm5Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm5Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm5Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm5Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm5Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm5Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm5Regs.TZEINT.all = (EPwm5Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm5Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm5Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm5Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm5Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm5Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm5Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm5Regs.DCACTL.all = (EPwm5Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm5Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm5Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm5Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm5Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm5Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm5Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm5Regs.DCBCTL.all = (EPwm5Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm5Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm5Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm5Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm5Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm5Regs.DCTRIPSEL.all = (EPwm5Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm5Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm5Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm5Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm5Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm5Regs.TZDCSEL.all = (EPwm5Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm5Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm5Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm5Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm5Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm5Regs.DCFCTL.all = (EPwm5Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm5Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm5Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm5Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm5Regs.DCCAPCTL.all = (EPwm5Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm5Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm5Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm5Regs.HRCNFG.all = (EPwm5Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm5Regs.EPWMXLINK.bit.TBPRDLINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPALINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPBLINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPCLINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPDLINK = 4U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm5Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm5Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm5Regs.HRPCTL.all = (EPwm5Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* SystemInitialize for SignalConversion generated from: '<S15>/Vpk' */
    cla2cpu_Vpk = 0.0;

    /* Start for MATLABSystem: '<S26>/DAC' */
    MW_ConfigureDACB();

    /* End of SystemInitialize for S-Function (fcgen): '<S14>/Function-Call Generator' */

    /*  CLA Initialize*/
    EALLOW;

    /* Enable CLA */
    CpuSysRegs.PCLKCR0.bit.CLA1 = 1;

    /* Initialize and wait for CLA1ToCPUMsgRAM */
    MemCfgRegs.MSGxINIT.bit.INIT_CLA1TOCPU = 1;
    while (MemCfgRegs.MSGxINITDONE.bit.INITDONE_CLA1TOCPU != 1) {
    }

    /* Initialize and wait for CPUToCLA1MsgRAM */
    MemCfgRegs.MSGxINIT.bit.INIT_CPUTOCLA1 = 1;
    while (MemCfgRegs.MSGxINITDONE.bit.INITDONE_CPUTOCLA1 != 1) {
    }

    MemCfgRegs.LSxMSEL.all = 0x555;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS3 = 0;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS4 = 1;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS5 = 1;
    Cla1Regs.MCTL.bit.IACKE = 1;
    EDIS;
    EALLOW;
    Cla1Regs.MVECT1 = (Uint16)(&Cla1Task1);
    Cla1Regs.MIER.bit.INT1 = 1;
    EDIS;

    /* Start for S-Function (c280xgpio_di): '<S150>/PFC_EN_GPIO60' */
    EALLOW;
    GpioCtrlRegs.GPBMUX2.all &= 0xFCFFFFFFU;
    GpioCtrlRegs.GPBDIR.all &= 0xEFFFFFFFU;
    EDIS;
    npc_controller_DWork.fault = false;
    npc_controller_DWork.fut_en = false;
    npc_controller_DWork.start_cnt = 0.0;
    npc_controller_DWork.relayOff_cnt = 0.0;
    npc_controller_DWork.relay_cnt = 0.0;
    npc_controller_DWork.eoss_cnt = 0.0;
    npc_controller_DWork.delay_cnt = 0.0;
    npc_controller_B.state = 0U;
    npc_controller_B.calib_ok = false;
    npc_controller_B.control_en = false;
    npc_controller_B.burst_en = false;
    npc_controller_B.eoss = false;
    cpu2cla_ref = 0.0F;
    cpu2cla_pha_en = false;
    cpu2cla_phb_en = false;
    cpu2cla_phc_en = false;
    cpu2cla_pfc_ok2 = false;
    npc_controller_B.relay_ctrl = false;
    npc_controller_B.tfv_v_UvpOvp = false;

    /* SystemInitialize for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
     *  SubSystem: '<S112>/updateCalib'
     */

    /* SystemInitialize for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
     *  SubSystem: '<S112>/detectUvpOvp'
     */
    /* SystemInitialize for Chart: '<S117>/OVP' */
    npc_controller_B.tfv_v_Ovp = 0.0;

    /* SystemInitialize for Chart: '<S117>/UVP' */
    npc_controller_B.tfv_v_Uvp = 0.0;

    /* SystemInitialize for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
     *  SubSystem: '<S112>/updateSequencePhA_burst'
     */
    /* SystemInitialize for S-Function (fcgen): '<S122>/Function-Call Generator' incorporates:
     *  SubSystem: '<S122>/updateSequencePhA_burst'
     */
    /* SystemInitialize for S-Function (fcgen): '<S138>/Function-Call Generator' incorporates:
     *  SubSystem: '<S138>/pol_vxn1'
     */
    /* SystemInitialize for Chart: '<S139>/Chart2' */
    npc_controller_DWork.is_active_c18_npc_controller = 0U;
    npc_controller_DWork.is_c18_npc_controller = 0U;

    /* End of SystemInitialize for S-Function (fcgen): '<S138>/Function-Call Generator' */
    /* End of SystemInitialize for S-Function (fcgen): '<S122>/Function-Call Generator' */

    /* SystemInitialize for Chart: '<S111>/Chart' */
    npc_controller_DWork.is_active_c20_npc_controller = 0U;
    npc_controller_DWork.is_c20_npc_controller = 0U;
    cpu2cla_zc_a = 0.0;

    /* SystemInitialize for SignalConversion generated from: '<S12>/angle' */
    cpu2cla_angle = 0.0;

    /* Start for MATLABSystem: '<S151>/Validate_DI' */
    /*  Perform one-time calculations, such as computing constants */
    npc_controller_DWork.obj_k.din_state = false;
    npc_controller_DWork.obj_k.cnt = 0U;

    /* End of SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' */
    /*  Initialize / reset discrete-state properties */

    /* SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' incorporates:
     *  SubSystem: '<Root>/CANRX'
     */
    npc_controller_CANRX_Init(&npc_controller_B.CANRX);

    /* End of SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
    npc_controller_DWork.is_active_c3_npc_controller = 0U;

    /* SystemInitialize for S-Function (idletask): '<S152>/Idle Task' incorporates:
     *  SubSystem: '<S152>/IDLE'
     */

    /* System initialize for function-call system: '<S152>/IDLE' */
    {
      uint16_T rtb_DataStoreRead_dj;

      /* SystemInitialize for S-Function (fcgen): '<S155>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S155>/idle_task'
       */
      /* SystemInitialize for IfAction SubSystem: '<S261>/hkeep' */
      /* SystemInitialize for S-Function (fcgen): '<S265>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S265>/tz'
       */

      /* SystemInitialize for S-Function (fcgen): '<S265>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S265>/tfv'
       */
      npc_controller_DWork.is_active_c23_npc_controller = 0U;

      /* SystemInitialize for Chart: '<S291>/hkeep1' incorporates:
       *  SubSystem: '<S293>/HKEEP.tfvVa'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem);

      /* SystemInitialize for Chart: '<S291>/hkeep1' incorporates:
       *  SubSystem: '<S293>/HKEEP.tfvVb'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n);

      /* SystemInitialize for Chart: '<S291>/hkeep1' incorporates:
       *  SubSystem: '<S293>/HKEEP.tfvVc'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2);

      /* SystemInitialize for Chart: '<S291>/hkeep1' incorporates:
       *  SubSystem: '<S293>/HKEEP.tfvVbulk'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2n);

      /* SystemInitialize for Chart: '<S291>/hkeep1' incorporates:
       *  SubSystem: '<S293>/HKEEP.tfvVmid'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2nv);

      /* SystemInitialize for Chart: '<S291>/hkeep1' incorporates:
       *  SubSystem: '<S293>/HKEEP.tfvVaux'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2nvq);

      /* End of SystemInitialize for S-Function (fcgen): '<S265>/Function-Call Generator1' */
      /* End of SystemInitialize for SubSystem: '<S261>/hkeep' */

      /* SystemInitialize for IfAction SubSystem: '<S261>/report_adc' */
      /* Start for S-Function (c280xgpio_do): '<S266>/GPIO86' */
      EALLOW;
      GpioCtrlRegs.GPCMUX2.all &= 0xFFFFCFFFU;
      GpioCtrlRegs.GPCDIR.all |= 0x400000U;
      EDIS;

      /* SystemInitialize for Chart: '<S266>/OTP' */
      npc_controller_B.tfv_v_Otp = 0.0F;

      /* End of SystemInitialize for SubSystem: '<S261>/report_adc' */
      /* End of SystemInitialize for S-Function (fcgen): '<S155>/Function-Call Generator1' */
    }

    /* End of SystemInitialize for S-Function (idletask): '<S152>/Idle Task' */

    /* SystemInitialize for S-Function (fcgen): '<S156>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S156>/epwm'
     */

    /* user code (Initialize function Body) */

    /* System '<S156>/epwm' */

    /*Initialize pwm sync*/
    EALLOW;
    XBAR_setInputPin(XBAR_INPUT5, 0);  //EXTSYNC1 from PWM1A
    SyncSocRegs.SYNCSELECT.bit.EPWM4SYNCIN = 0b101;//Sync PWM4 group to EXTSYNC1
    SyncSocRegs.SYNCSELECT.bit.EPWM7SYNCIN = 0b101;//Sync PWM7 group to EXTSYNC1
    SyncSocRegs.SYNCSELECT.bit.EPWM10SYNCIN = 0b101;//Sync PWM10 group to EXTSYNC1
    EDIS;

    /*Force PWM to LOW*/
    EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

    /* SystemInitialize for S-Function (fcgen): '<S156>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S156>/orps&relay'
     */
    /* Start for S-Function (c2802xpwm): '<S341>/ePWM2 - ORPS4' */

    /*** Initialize ePWM6 modules ***/
    {
      /*  // Time Base Control Register
         EPwm6Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm6Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm6Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm6Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm6Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm6Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm6Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm6Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm6Regs.TBCTL.all = (EPwm6Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm6Regs.TBCTL2.all = (EPwm6Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm6Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm6Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm6Regs.TBPHS.all = (EPwm6Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm6Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm6Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm6Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm6Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm6Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm6Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm6Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm6Regs.CMPCTL.all = (EPwm6Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm6Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm6Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm6Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm6Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm6Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm6Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm6Regs.CMPCTL2.all = (EPwm6Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm6Regs.CMPA.bit.CMPA = 744U;  // Counter Compare A Register
      EPwm6Regs.CMPB.bit.CMPB = 794U;  // Counter Compare B Register
      EPwm6Regs.CMPC = 500U;           // Counter Compare C Register
      EPwm6Regs.CMPD = 500U;           // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm6Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm6Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm6Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm6Regs.AQSFRC.all = (EPwm6Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm6Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm6Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm6Regs.AQCSFRC.all = (EPwm6Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm6Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm6Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm6Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm6Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm6Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm6Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm6Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm6Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm6Regs.DBCTL.all = (EPwm6Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm6Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm6Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm6Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm6Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm6Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm6Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM6SOC Period Select
         EPwm6Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm6Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm6Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm6Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm6Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM6SOCB Period Select
         EPwm6Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm6Regs.ETSEL.bit.INTEN                = 0U;          // EPWM6INTn Enable
         EPwm6Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm6Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm6Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM6INTn Period Select
         EPwm6Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm6Regs.ETSEL.all = (EPwm6Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm6Regs.ETPS.all = (EPwm6Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm6Regs.ETSOCPS.all = (EPwm6Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm6Regs.ETINTPS.all = (EPwm6Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm6Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm6Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm6Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm6Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm6Regs.PCCTL.all = (EPwm6Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm6Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm6Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM6A
         EPwm6Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM6B
         EPwm6Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM6A action on DCAEVT1
         EPwm6Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM6A action on DCAEVT2
         EPwm6Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM6B action on DCBEVT1
         EPwm6Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM6B action on DCBEVT2
       */
      EPwm6Regs.TZCTL.all = (EPwm6Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm6Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm6Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm6Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm6Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm6Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm6Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm6Regs.TZEINT.all = (EPwm6Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm6Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm6Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm6Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm6Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm6Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm6Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm6Regs.DCACTL.all = (EPwm6Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm6Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm6Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm6Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm6Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm6Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm6Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm6Regs.DCBCTL.all = (EPwm6Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm6Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm6Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm6Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm6Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm6Regs.DCTRIPSEL.all = (EPwm6Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm6Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm6Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm6Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm6Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm6Regs.TZDCSEL.all = (EPwm6Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm6Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm6Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm6Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm6Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm6Regs.DCFCTL.all = (EPwm6Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm6Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm6Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm6Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm6Regs.DCCAPCTL.all = (EPwm6Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm6Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm6Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm6Regs.HRCNFG.all = (EPwm6Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm6Regs.EPWMXLINK.bit.TBPRDLINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPALINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPBLINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPCLINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPDLINK = 5U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm6Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm6Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm6Regs.HRPCTL.all = (EPwm6Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* SystemInitialize for S-Function (fcgen): '<S156>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S156>/cmpss'
     */
    /* Start for MATLABSystem: '<S339>/CMPSS1H' */
    COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPH(COMPModuleValue, 0U, 0U, 0U, 0U, 1U, 0U);

    /* Start for MATLABSystem: '<S339>/CMPSS2H' */
    COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPH(COMPModuleValue, 0U, 0U, 0U, 0U, 1U, 0U);

    /* Start for MATLABSystem: '<S339>/CMPSS4H' */
    COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPH(COMPModuleValue, 0U, 0U, 0U, 0U, 1U, 0U);

    /* Start for MATLABSystem: '<S339>/CMPSS1L' */
    COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPL(COMPModuleValue, 0U, 1U);

    /* Start for MATLABSystem: '<S339>/CMPSS2L' */
    COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPL(COMPModuleValue, 0U, 1U);

    /* Start for MATLABSystem: '<S339>/CMPSS4L' */
    COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPL(COMPModuleValue, 0U, 1U);

    /* End of SystemInitialize for S-Function (fcgen): '<S156>/Function-Call Generator1' */
  }
}

/* Model terminate function */
void npc_controller_terminate(void)
{
  /* Terminate for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' incorporates:
   *  SubSystem: '<Root>/CONTROL'
   */
  /* Termination for function-call system: '<Root>/CONTROL' */

  /* Terminate for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
   *  SubSystem: '<S112>/configFutEn'
   */

  /* Terminate for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
   *  SubSystem: '<S112>/configFutDis'
   */

  /* Terminate for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
   *  SubSystem: '<S112>/readCmpssOcp'
   */

  /* Terminate for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
   *  SubSystem: '<S112>/updateCalib'
   */

  /* Terminate for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
   *  SubSystem: '<S112>/disablePwm'
   */

  /* Terminate for Chart: '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' incorporates:
   *  SubSystem: '<S112>/updateSequencePhA_burst'
   */

  /* End of Terminate for S-Function (fcgen): '<S2>/Function-Call Generator' */

  /* Terminate for S-Function (idletask): '<S152>/Idle Task' incorporates:
   *  SubSystem: '<S152>/IDLE'
   */

  /* Termination for function-call system: '<S152>/IDLE' */

  /* Terminate for S-Function (fcgen): '<S155>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S155>/idle_task'
   */
  /* Terminate for IfAction SubSystem: '<S261>/hkeep' */
  /* Terminate for S-Function (fcgen): '<S265>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S265>/tz'
   */

  /* Terminate for S-Function (fcgen): '<S265>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S265>/tfv'
   */
  /* Terminate for Chart: '<S291>/hkeep1' incorporates:
   *  SubSystem: '<S293>/HKEEP.tfvVa'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem);

  /* Terminate for Chart: '<S291>/hkeep1' incorporates:
   *  SubSystem: '<S293>/HKEEP.tfvVb'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n);

  /* Terminate for Chart: '<S291>/hkeep1' incorporates:
   *  SubSystem: '<S293>/HKEEP.tfvVc'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2);

  /* Terminate for Chart: '<S291>/hkeep1' incorporates:
   *  SubSystem: '<S293>/HKEEP.tfvVbulk'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2n);

  /* Terminate for Chart: '<S291>/hkeep1' incorporates:
   *  SubSystem: '<S293>/HKEEP.tfvVmid'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2nv);

  /* Terminate for Chart: '<S291>/hkeep1' incorporates:
   *  SubSystem: '<S293>/HKEEP.tfvVaux'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2nvq);

  /* End of Terminate for S-Function (fcgen): '<S265>/Function-Call Generator1' */
  /* End of Terminate for SubSystem: '<S261>/hkeep' */
  /* End of Terminate for S-Function (fcgen): '<S155>/Function-Call Generator1' */

  /* End of Terminate for S-Function (idletask): '<S152>/Idle Task' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
