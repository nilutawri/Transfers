#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "rtwtypes.h"
#include "npc_controller.h"
#include "npc_controller_private.h"

void init_eCAN_A ( uint16_T bitRatePrescaler, uint16_T timeSeg1, uint16_T
                  timeSeg2, uint16_T sbg, uint16_T sjw, uint16_T sam)
{
  uint32_t ui32RegValue;
  uint16_t ui16CANCTL;
  EALLOW;
  CpuSysRegs.PCLKCR10.bit.CAN_A = 1;
  GpioCtrlRegs.GPCPUD.bit.GPIO71 = 0;  /* Enable pull-up on GPIO71 */
  GpioCtrlRegs.GPCGMUX1.bit.GPIO71 = 1;
  GpioCtrlRegs.GPCMUX1.bit.GPIO71 = 1;
  GpioCtrlRegs.GPCPUD.bit.GPIO70 = 0;  /* Enable pull-up on GPIO70 */
  GpioCtrlRegs.GPCGMUX1.bit.GPIO70 = 1;
  GpioCtrlRegs.GPCMUX1.bit.GPIO70 = 1;
  EDIS;
  ui32RegValue = (((uint32_T)((bitRatePrescaler-1) & 0x03C0))<<10)|((timeSeg2-1)<<
    12)|((timeSeg1-1)<<8)|((sjw-1)<<6)|((bitRatePrescaler-1) & 0x3F);
  CAN_initModule(CANA_BASE);
  CAN_selectClockSource(CANA_BASE, (CAN_ClockSource)0);

  //Set init mode
  ui16CANCTL = HWREGH(CANA_BASE + CAN_O_CTL);
  HWREGH(CANA_BASE + CAN_O_CTL) = ui16CANCTL | CAN_CTL_INIT | CAN_CTL_CCE;

  //Set Bit Timing register
  HWREGH(CANA_BASE + CAN_O_BTR) = (ui32RegValue & 0xFFFFU);
  HWREGH(CANA_BASE + CAN_O_BTR + 2) = (ui32RegValue >> 16);

  // Restore the saved CAN Control register.
  HWREGH(CANA_BASE + CAN_O_CTL) = ui16CANCTL;
  HWREGH(CANA_BASE + CAN_O_IP_MUX21) = 0;
  HWREGH(CANA_BASE + CAN_O_IP_MUX21 + 2) = 0;
  CAN_enableInterrupt(CANA_BASE, CAN_INT_IE0);
  CAN_enableGlobalInterrupt(CANA_BASE, CAN_GLOBAL_INT_CANINT0);

  // Enable the CAN for operation.
  CAN_enableController(CANA_BASE);
}
