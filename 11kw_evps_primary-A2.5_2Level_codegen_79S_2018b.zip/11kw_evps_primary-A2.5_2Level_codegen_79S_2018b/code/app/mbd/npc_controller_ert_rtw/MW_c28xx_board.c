#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "rtwtypes.h"
#include "npc_controller.h"
#include "npc_controller_private.h"

void init_board (void)
{
  DisableDog();
  EALLOW;
  CpuSysRegs.PCLKCR0.bit.DMA = 1U;
  CpuSysRegs.PCLKCR6.bit.SD1 = 1U;
  CpuSysRegs.PCLKCR6.bit.SD2 = 1U;
  EDIS;

#ifdef CPU1

  EALLOW;

  //enable pull-ups on unbonded IOs as soon as possible to reduce power consumption.
  GPIO_EnableUnbondedIOPullups();
  CpuSysRegs.PCLKCR13.bit.ADC_A = 1U;
  CpuSysRegs.PCLKCR13.bit.ADC_B = 1U;
  CpuSysRegs.PCLKCR13.bit.ADC_C = 1U;
  CpuSysRegs.PCLKCR13.bit.ADC_D = 1U;

  //check if device is trimmed
  if (*((Uint16 *)0x5D1B6) == 0x0000U) {
    //device is not trimmed, apply static calibration values
    AnalogSubsysRegs.ANAREFTRIMA.all = 31709U;
    AnalogSubsysRegs.ANAREFTRIMB.all = 31709U;
    AnalogSubsysRegs.ANAREFTRIMC.all = 31709U;
    AnalogSubsysRegs.ANAREFTRIMD.all = 31709U;
  }

  CpuSysRegs.PCLKCR13.bit.ADC_A = 0U;
  CpuSysRegs.PCLKCR13.bit.ADC_B = 0U;
  CpuSysRegs.PCLKCR13.bit.ADC_C = 0U;
  CpuSysRegs.PCLKCR13.bit.ADC_D = 0U;
  EDIS;
  InitSysPll(INT_OSC2,40,0,1);

  //Turn on all peripherals
  //InitPeripheralClocks();
  EALLOW;
  CpuSysRegs.PCLKCR0.bit.CPUTIMER0 = 1U;
  CpuSysRegs.PCLKCR0.bit.CPUTIMER1 = 1U;
  CpuSysRegs.PCLKCR0.bit.CPUTIMER2 = 1U;
  CpuSysRegs.PCLKCR0.bit.HRPWM = 1U;
  CpuSysRegs.PCLKCR1.bit.EMIF1 = 1U;
  CpuSysRegs.PCLKCR1.bit.EMIF2 = 1U;
  EDIS;

#endif

  EALLOW;

  /* Configure low speed peripheral clocks */
  ClkCfgRegs.LOSPCP.bit.LSPCLKDIV = 0U;
  EDIS;

  /* Disable and clear all CPU interrupts */
  DINT;
  IER = 0x0000U;
  IFR = 0x0000U;
  InitPieCtrl();
  InitPieVectTable();

  /* initial eCAN function.... */
  /* Initialize eCAN_A Module with following parameters:
   *    BRP=40, TSEG1=5, TSEG2=4
   *    Resynchronize on: Only_falling_edges
   *    Level of CAN bus: Sample_one_time
   *    Synchronization jump width = 2 */
  init_eCAN_A (40, 5, 4, 1, 2, 1);
  InitCpuTimers();

  /* initial ePWM GPIO assignment... */
  config_ePWM_GPIO();
  EALLOW;

  /* Enable clock to ePWM */
  CpuSysRegs.PCLKCR2.bit.EPWM6 = 1U;
  CpuSysRegs.PCLKCR2.bit.EPWM1 = 1U;
  CpuSysRegs.PCLKCR2.bit.EPWM5 = 1U;
  CpuSysRegs.PCLKCR2.bit.EPWM7 = 1U;
  CpuSysRegs.PCLKCR2.bit.EPWM9 = 1U;
  CpuSysRegs.PCLKCR2.bit.EPWM11 = 1U;

  /* Disable TBCLK within ePWM before module configuration */
  CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0U;
  EDIS;
  config_ePWMSyncSource();
  config_ePWM_XBAR();
  configureIXbar();

  /* initial GPIO qualification settings.... */
  EALLOW;
  GpioCtrlRegs.GPAQSEL1.all = 0x0U;
  GpioCtrlRegs.GPAQSEL2.all = 0x0U;
  GpioCtrlRegs.GPBQSEL1.all = 0x0U;
  GpioCtrlRegs.GPBQSEL2.all = 0x0U;
  GpioCtrlRegs.GPCQSEL1.all = 0x0U;
  GpioCtrlRegs.GPCQSEL2.all = 0x0U;
  GpioCtrlRegs.GPDQSEL1.all = 0x0U;
  GpioCtrlRegs.GPDQSEL2.all = 0x0U;
  GpioCtrlRegs.GPEQSEL1.all = 0x0U;
  GpioCtrlRegs.GPEQSEL2.all = 0x0U;
  GpioCtrlRegs.GPFQSEL1.all = 0x0U;
  EDIS;
}
