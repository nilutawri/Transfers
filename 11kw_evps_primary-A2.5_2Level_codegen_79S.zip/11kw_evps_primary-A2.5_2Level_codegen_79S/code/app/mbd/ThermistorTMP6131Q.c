/*******************************************************************************
 * Filename              : ThermistorTMP6131Q.c
 * Project               :
 * Author(s)             : vinoth kumar
 * Created               : 28 April 2020
 *
 * Description           : 
 *
 * Last modification:-
 *      on Date          :
 *      by Author        : 
 *      File Revision    : V1.0
 *
 * Compiler info         :
 * Processor info        :
 *
 * Copyright (c) 2023  EVPS, Liteon Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include "ThermalModule.h"

/*******************************************************************************
 * Global Variables (public to other modules)
 ******************************************************************************/


/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#define ADC_MAX_VALUE              2750     //ADC Max Value
#define TEMP_AT_ADC_MAX             846     //211.5'C(151.5'C) in 0.25'C Resolution with +60'C Offset at ADC Max Value


/*******************************************************************************
 * Local data / Variable types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local Variable (private to module)
 ******************************************************************************/

    /* Constants For NTSA1103FP027 Thermistor Temperature Calculation */
const uint16_t u16AdcRange[20] = { 1626, 1676, 1736, 1801, 1866, 1916, 1961, 2006, 2066, 2131, \
                                   2196, 2246, 2336, 2541, 2591, 2631, 2661, 2691, 2716, 2749};

const uint16_t u16TempRange[20]= {   78,  107,  142,  182,  223,  255,  284,  314,  355,  400, \
                                    446,  482,  548,  700,  736,  765,  786,  807,  824,  846};        //in 0.25'C Resolution

const uint16_t u16Gain[20]    = { 2430, 2460, 2560, 2590, 2620, 2670, 2750, 2805, 2830, 2910, \
                                   2980, 3010, 3047, 3015, 3095, 2959, 2940, 2840, 2770, 2735};

const uint16_t u16Divisor[20] = {   12,   12,   12,   12,   12,   12,   12,   12,   12,   12, \
                                     12,   12,   12,   12,   12,   12,   12,   12,   12,   12};

/*******************************************************************************
 * Local functions (private to module)
 ******************************************************************************/


/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Function name    : GetTemperatureTMP6131Q
 *
 * Parameters       : uint16_t - 12 Bit ADC Value from Thermistor Sensors.
 *
 * Returned value   : int16_t - Temperature Output Either in 1'C or in 0.25'C Resolution (Can be Selected)
 *                              With 60'C Positive Offset Added.
 *
 *                               Offset can be eliminated with Selection and results will be in  Signed Integer
 *
 * Description      :  This Function is Designed for Temperature calculation of Thermistor sensor TMP6131Q
 *                     using Look Up Table from  -40'c to 150'C in either 0.25'C or in 1'C Resolution. with 12 Bit ADC Input.
 *                     (Where the Thermistor in Connected @ bottom of the Voltage Divider with 10K resistor on Top)
 *
 *                    Refer to Excel Sheet for ADC Range, Gain, Divisor & Temperature Ranges
 *
 ******************************************************************************/
int16_t GetTemperatureTMP6131Q(uint16_t u16AdcInput)
{
    int16_t i16Temperature;
    uint16_t u16AdcRangePntr;

    uint16_t u16Temp;
    uint32_t u32Temp;

    if (u16AdcInput < ADC_MAX_VALUE)
    {
        if (u16AdcInput > u16AdcRange[0])
        {
            for (u16AdcRangePntr = 19; u16AdcRangePntr > 0; u16AdcRangePntr--)
            {
                if (u16AdcInput >= u16AdcRange[u16AdcRangePntr])
                    break;
            }

            u16Temp = u16AdcInput - u16AdcRange[u16AdcRangePntr];
            u32Temp = (uint32_t) u16Temp * u16Gain[u16AdcRangePntr];
            u32Temp = u32Temp >> u16Divisor[u16AdcRangePntr];

            i16Temperature = u16TempRange[u16AdcRangePntr] + (uint16_t) u32Temp;
        }
        else     //if Temperature is < -40.5'C Clamp to -40.5'C
            i16Temperature =  u16TempRange[0];
    }
    else     //if Temperature is > 151'C Clamp to 151.5'C
        i16Temperature =  TEMP_AT_ADC_MAX;

#ifdef TEMP_REPORTING_RESOLUTION_1_DEG
    i16Temperature = i16Temperature >> 2;   //Convert to 1'C from 0.25'C Resolution
#endif

#ifdef TEMP_REPORTING_OFFSET_NOT_ZERO
    i16Temperature = i16Temperature - TEMP_REPORTING_OFFSET_VALUE;
#endif

    return i16Temperature;
}

/*
 * End of file
 */
