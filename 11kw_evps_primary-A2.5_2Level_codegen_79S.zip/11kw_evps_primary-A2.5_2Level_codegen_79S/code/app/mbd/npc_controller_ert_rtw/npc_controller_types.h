/*
 * File: npc_controller_types.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.30
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri May 26 11:55:14 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_npc_controller_types_h_
#define RTW_HEADER_npc_controller_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_adc_
#define DEFINED_TYPEDEF_FOR_adc_

typedef struct {
  real32_T va;
  real32_T vb;
  real32_T vc;
  real32_T ia;
  real32_T ib;
  real32_T ic;
  real32_T vbulk;
  real32_T vmid;
} adc;

#endif

#ifndef DEFINED_TYPEDEF_FOR_adc_rect_
#define DEFINED_TYPEDEF_FOR_adc_rect_

typedef struct {
  real32_T va;
  real32_T vb;
  real32_T vc;
  real32_T ia;
  real32_T ib;
  real32_T ic;
  real32_T vbulk;
  real32_T vmid;
} adc_rect;

#endif

#ifndef struct_tag_ytSTa5iTZXVjnbne3XANeF
#define struct_tag_ytSTa5iTZXVjnbne3XANeF

struct tag_ytSTa5iTZXVjnbne3XANeF
{
  uint16_T status;
  uint16_T ref;
  uint16_T now;
  uint16_T cnt;
};

#endif                                 /* struct_tag_ytSTa5iTZXVjnbne3XANeF */

#ifndef typedef_tfv_latch_npc_controller
#define typedef_tfv_latch_npc_controller

typedef struct tag_ytSTa5iTZXVjnbne3XANeF tfv_latch_npc_controller;

#endif                                 /* typedef_tfv_latch_npc_controller */

#ifndef struct_tag_mJwWZQsvJAXvgRMjJItCbG
#define struct_tag_mJwWZQsvJAXvgRMjJItCbG

struct tag_mJwWZQsvJAXvgRMjJItCbG
{
  int32_T isInitialized;
};

#endif                                 /* struct_tag_mJwWZQsvJAXvgRMjJItCbG */

#ifndef typedef_codertarget_tic2000_blocks_DACW
#define typedef_codertarget_tic2000_blocks_DACW

typedef struct tag_mJwWZQsvJAXvgRMjJItCbG codertarget_tic2000_blocks_DACW;

#endif                             /* typedef_codertarget_tic2000_blocks_DACW */

#ifndef struct_tag_3ZLvR40xJ55vs8B3jfspmE
#define struct_tag_3ZLvR40xJ55vs8B3jfspmE

struct tag_3ZLvR40xJ55vs8B3jfspmE
{
  boolean_T din_state;
  uint16_T cnt;
};

#endif                                 /* struct_tag_3ZLvR40xJ55vs8B3jfspmE */

#ifndef typedef_Validate_DI_npc_controller
#define typedef_Validate_DI_npc_controller

typedef struct tag_3ZLvR40xJ55vs8B3jfspmE Validate_DI_npc_controller;

#endif                                 /* typedef_Validate_DI_npc_controller */

#ifndef struct_tag_DUFbRmTqG5lLLzZYEP4VJG
#define struct_tag_DUFbRmTqG5lLLzZYEP4VJG

struct tag_DUFbRmTqG5lLLzZYEP4VJG
{
  int32_T isInitialized;
};

#endif                                 /* struct_tag_DUFbRmTqG5lLLzZYEP4VJG */

#ifndef typedef_codertarget_tic2000_blocks_CMPS
#define typedef_codertarget_tic2000_blocks_CMPS

typedef struct tag_DUFbRmTqG5lLLzZYEP4VJG codertarget_tic2000_blocks_CMPS;

#endif                             /* typedef_codertarget_tic2000_blocks_CMPS */

/* Forward declaration for rtModel */
typedef struct tag_RTM_npc_controller RT_MODEL_npc_controller;

#endif                                 /* RTW_HEADER_npc_controller_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
