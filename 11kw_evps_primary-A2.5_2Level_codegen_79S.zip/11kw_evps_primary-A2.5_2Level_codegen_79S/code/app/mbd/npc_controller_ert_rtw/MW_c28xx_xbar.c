#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "rtwtypes.h"
#include "npc_controller.h"
#include "npc_controller_private.h"
#include "MW_c28xGPIO.h"

void configureIXbar(void)
{
  /*--- Configuring GPIO set in Input Xbar---*/
  EALLOW;
  InputXbarRegs.INPUT1SELECT = 62;
  InputXbarRegs.INPUT2SELECT = 61;
  EDIS;
}
