/*
 * File: npc_controller.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.30
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri May 26 11:55:14 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_npc_controller_h_
#define RTW_HEADER_npc_controller_h_
#ifndef npc_controller_COMMON_INCLUDES_
#define npc_controller_COMMON_INCLUDES_
#include <string.h>
#include <math.h>
#include "rtwtypes.h"
#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "IQmathLib.h"
#include "can_message.h"
#include "F2837xS_device.h"
#include "MW_c2000DAC.h"
#include "MW_c28xCMPSS.h"
#endif                                 /* npc_controller_COMMON_INCLUDES_ */

#include "npc_controller_types.h"
#include "CANRX.h"
#include "rt_nonfinite.h"
#include <stddef.h>
#include "MW_target_hardware_resources.h"

/* Includes for objects with custom storage classes */
#include "cla_header.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

extern void init_eCAN_A ( uint16_T bitRatePrescaler, uint16_T timeSeg1, uint16_T
  timeSeg2, uint16_T sbg, uint16_T sjw, uint16_T sam);
extern void initializeOverrunService();
extern void executeOverrunService();
extern void config_ePWMSyncSource(void);
extern void config_ePWM_GPIO (void);
extern void config_ePWM_TBSync (void);
extern void config_ePWM_XBAR(void);
extern void configureIXbar(void);

/* user code (top of header file) */
//#include "adc.h"
#include "asysctl.h"

//#include "can.h"
#include "cla.h"
#include "cmpss.h"
#include "cpu.h"
#include "cputimer.h"
#include "dac.h"
#include "dcsm.h"
#include "debug.h"
#include "dma.h"
#include "ecap.h"
#include "emif.h"
#include "epwm.h"
#include "eqep.h"
#include "flash.h"
#include "gpio.h"
#include "hrpwm.h"
#include "i2c.h"
#include "interrupt.h"
#include "mcbsp.h"
#include "memcfg.h"
#include "pin_map.h"
#include "sci.h"
#include "sdfm.h"
#include "spi.h"
#include "sysctl.h"

//#include "upp.h"
#include "version.h"
#include "xbar.h"

//#include "clb.h"
//#include "clb_config.h"
#include "ThermalModule.h"

/* user code (top of export header file) */
#include "can_message.h"

/* Block signals for system '<S191>/Bit Shift' */
typedef struct {
  uint16_T y;                          /* '<S194>/bit_shift' */
} rtB_BitShift_npc_controller;

/* Block signals for system '<S152>/CAN_Task' */
typedef struct {
  CAN_DATATYPE CANPack1;               /* '<S213>/CAN Pack1' */
  CAN_DATATYPE CANPack1_p;             /* '<S212>/CAN Pack1' */
  CAN_DATATYPE CANPack1_g;             /* '<S211>/CAN Pack1' */
  CAN_DATATYPE CANPack1_i;             /* '<S210>/CAN Pack1' */
  CAN_DATATYPE CANPack1_c;             /* '<S209>/CAN Pack1' */
  CAN_DATATYPE CANPack1_h;             /* '<S190>/CAN Pack1' */
  CAN_DATATYPE CANPack1_k;             /* '<S189>/CAN Pack1' */
  CAN_DATATYPE CANPack1_l;             /* '<S187>/CAN Pack1' */
  uint16_T VectorConcatenate[8];       /* '<S213>/Vector Concatenate' */
  uint16_T VectorConcatenate_d[8];     /* '<S212>/Vector Concatenate' */
  uint16_T VectorConcatenate_e[8];     /* '<S211>/Vector Concatenate' */
  uint16_T VectorConcatenate_g[8];     /* '<S210>/Vector Concatenate' */
  uint16_T VectorConcatenate_c[8];     /* '<S209>/Vector Concatenate' */
  uint16_T VectorConcatenate_o[8];     /* '<S190>/Vector Concatenate' */
  uint16_T VectorConcatenate_b[8];     /* '<S189>/Vector Concatenate' */
  uint16_T DataStoreRead2[8];          /* '<S187>/Data Store Read2' */
  rtB_BitShift_npc_controller BitShift_ab;/* '<S251>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_cy;/* '<S250>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_g0;/* '<S249>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_jj;/* '<S248>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_a;/* '<S239>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_ij;/* '<S238>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_b;/* '<S237>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_du;/* '<S236>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_c;/* '<S229>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_i;/* '<S228>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_g;/* '<S227>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_ed;/* '<S218>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_d;/* '<S216>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_pb;/* '<S215>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_o;/* '<S214>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_eq;/* '<S202>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_f;/* '<S201>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_e;/* '<S200>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_p;/* '<S193>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_ji;/* '<S192>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_j;/* '<S191>/Bit Shift' */
} rtB_CAN_Task_npc_controller;

/* Block signals for system '<S267>/Bit Shift1' */
typedef struct {
  uint16_T y;                          /* '<S315>/bit_shift' */
} rtB_BitShift1_npc_controller;

/* Block signals for system '<S267>/Bit Shift2' */
typedef struct {
  uint16_T y;                          /* '<S319>/bit_shift' */
} rtB_BitShift2_npc_controller;

/* Block signals for system '<S267>/Bit Shift3' */
typedef struct {
  uint16_T y;                          /* '<S320>/bit_shift' */
} rtB_BitShift3_npc_controller;

/* Block signals for system '<S267>/Bit Shift4' */
typedef struct {
  uint16_T y;                          /* '<S321>/bit_shift' */
} rtB_BitShift4_npc_controller;

/* Block signals for system '<S267>/Bit Shift5' */
typedef struct {
  uint16_T y;                          /* '<S322>/bit_shift' */
} rtB_BitShift5_npc_controller;

/* Block signals for system '<S267>/Bit Shift6' */
typedef struct {
  uint16_T y;                          /* '<S323>/bit_shift' */
} rtB_BitShift6_npc_controller;

/* Block signals for system '<S267>/Bit Shift7' */
typedef struct {
  uint16_T y;                          /* '<S324>/bit_shift' */
} rtB_BitShift7_npc_controller;

/* Block signals for system '<S267>/Bit Shift8' */
typedef struct {
  uint16_T y;                          /* '<S325>/bit_shift' */
} rtB_BitShift8_npc_controller;

/* Block signals for system '<S294>/MATLAB System' */
typedef struct {
  uint16_T MATLABSystem;               /* '<S294>/MATLAB System' */
} rtB_MATLABSystem_npc_controller;

/* Block states (default storage) for system '<S294>/MATLAB System' */
typedef struct {
  tfv_latch_npc_controller obj;        /* '<S294>/MATLAB System' */
  uint16_T status;                     /* '<S294>/MATLAB System' */
  uint16_T ref;                        /* '<S294>/MATLAB System' */
  uint16_T now;                        /* '<S294>/MATLAB System' */
  uint16_T cnt;                        /* '<S294>/MATLAB System' */
  boolean_T objisempty;                /* '<S294>/MATLAB System' */
} rtDW_MATLABSystem_npc_controlle;

/* Block signals (default storage) */
typedef struct {
  real_T SFunction_o17;                /* '<S291>/hkeep1' */
  real_T SFunction_o18;                /* '<S291>/hkeep1' */
  real_T SFunction_o19;                /* '<S291>/hkeep1' */
  real_T SFunction_o20;                /* '<S291>/hkeep1' */
  real_T SFunction_o21;                /* '<S291>/hkeep1' */
  real_T SFunction_o22;                /* '<S291>/hkeep1' */
  real_T SFunction_o23;                /* '<S291>/hkeep1' */
  real_T SFunction_o24;                /* '<S291>/hkeep1' */
  real_T SFunction_o25;                /* '<S291>/hkeep1' */
  real_T SFunction_o26;                /* '<S291>/hkeep1' */
  real_T SFunction_o27;                /* '<S291>/hkeep1' */
  real_T SFunction_o28;                /* '<S291>/hkeep1' */
  real_T SFunction_o29;                /* '<S291>/hkeep1' */
  real_T SFunction_o30;                /* '<S291>/hkeep1' */
  real_T SFunction_o31;                /* '<S291>/hkeep1' */
  real_T SFunction_o17_o;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o18_h;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o19_c;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o20_p;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o21_f;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o32;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o33;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o34;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o35;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o39;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o40;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o41;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o42;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o43;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o44;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o45;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o46;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o47;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T SFunction_o48;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T tfv_v_Uvp;                    /* '<S117>/UVP' */
  real_T tfv_v_Ovp;                    /* '<S117>/OVP' */
  real32_T tfv_v_Otp;                  /* '<S266>/OTP' */
  real32_T ADC6;                       /* '<S66>/ADC6' */
  real32_T ADC2;                       /* '<S66>/ADC2' */
  real32_T ADC5;                       /* '<S66>/ADC5' */
  real32_T ADC18;                      /* '<S65>/ADC18' */
  real32_T ADC5_b;                     /* '<S65>/ADC5' */
  real32_T ADC7;                       /* '<S65>/ADC7' */
  real32_T ADC3;                       /* '<S65>/ADC3' */
  real32_T ADC6_b;                     /* '<S65>/ADC6' */
  real32_T ADC17;                      /* '<S65>/ADC17' */
  real32_T ADC8;                       /* '<S65>/ADC8' */
  uint16_T input;                      /* '<S291>/hkeep1' */
  uint16_T assert_lim;                 /* '<S291>/hkeep1' */
  uint16_T assert_vld;                 /* '<S291>/hkeep1' */
  uint16_T deassert_lim;               /* '<S291>/hkeep1' */
  uint16_T deassert_vld;               /* '<S291>/hkeep1' */
  uint16_T input_a;                    /* '<S291>/hkeep1' */
  uint16_T assert_lim_h;               /* '<S291>/hkeep1' */
  uint16_T assert_vld_f;               /* '<S291>/hkeep1' */
  uint16_T deassert_lim_c;             /* '<S291>/hkeep1' */
  uint16_T deassert_vld_o;             /* '<S291>/hkeep1' */
  uint16_T input_n;                    /* '<S291>/hkeep1' */
  uint16_T assert_lim_c;               /* '<S291>/hkeep1' */
  uint16_T assert_vld_d;               /* '<S291>/hkeep1' */
  uint16_T deassert_lim_e;             /* '<S291>/hkeep1' */
  uint16_T deassert_vld_n;             /* '<S291>/hkeep1' */
  uint16_T input_j;                    /* '<S291>/hkeep1' */
  uint16_T assert_lim_p;               /* '<S291>/hkeep1' */
  uint16_T assert_vld_h;               /* '<S291>/hkeep1' */
  uint16_T deassert_lim_b;             /* '<S291>/hkeep1' */
  uint16_T deassert_vld_e;             /* '<S291>/hkeep1' */
  uint16_T input_m;                    /* '<S291>/hkeep1' */
  uint16_T assert_lim_b;               /* '<S291>/hkeep1' */
  uint16_T assert_vld_m;               /* '<S291>/hkeep1' */
  uint16_T deassert_lim_p;             /* '<S291>/hkeep1' */
  uint16_T deassert_vld_c;             /* '<S291>/hkeep1' */
  uint16_T input_ah;                   /* '<S291>/hkeep1' */
  uint16_T assert_lim_m;               /* '<S291>/hkeep1' */
  uint16_T assert_vld_k;               /* '<S291>/hkeep1' */
  uint16_T deassert_lim_py;            /* '<S291>/hkeep1' */
  uint16_T deassert_vld_j;             /* '<S291>/hkeep1' */
  uint16_T state;     /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T PFC_EN_GPIO60;             /* '<S150>/PFC_EN_GPIO60' */
  boolean_T calib_ok; /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T control_en;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T burst_en; /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T eoss;     /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T relay_ctrl;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T tfv_v_UvpOvp;
                      /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  rtB_BitShift7_npc_controller BitShift9_l;/* '<S264>/Bit Shift9' */
  rtB_BitShift5_npc_controller BitShift8_h;/* '<S264>/Bit Shift8' */
  rtB_BitShift4_npc_controller BitShift7_h;/* '<S264>/Bit Shift7' */
  rtB_BitShift6_npc_controller BitShift6_l;/* '<S264>/Bit Shift6' */
  rtB_BitShift3_npc_controller BitShift5_o;/* '<S264>/Bit Shift5' */
  rtB_BitShift2_npc_controller BitShift4_b;/* '<S264>/Bit Shift4' */
  rtB_BitShift1_npc_controller BitShift3_g;/* '<S264>/Bit Shift3' */
  rtB_BitShift8_npc_controller BitShift27;/* '<S264>/Bit Shift27' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2nvq;/* '<S294>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2nv;/* '<S294>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2n;/* '<S294>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2;/* '<S294>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n;/* '<S294>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem;/* '<S294>/MATLAB System' */
  rtB_BitShift8_npc_controller BitShift8;/* '<S267>/Bit Shift8' */
  rtB_BitShift7_npc_controller BitShift7;/* '<S267>/Bit Shift7' */
  rtB_BitShift6_npc_controller BitShift6;/* '<S267>/Bit Shift6' */
  rtB_BitShift5_npc_controller BitShift5;/* '<S267>/Bit Shift5' */
  rtB_BitShift4_npc_controller BitShift4;/* '<S267>/Bit Shift4' */
  rtB_BitShift3_npc_controller BitShift3;/* '<S267>/Bit Shift3' */
  rtB_BitShift2_npc_controller BitShift2;/* '<S267>/Bit Shift2' */
  rtB_BitShift1_npc_controller BitShift1;/* '<S267>/Bit Shift1' */
  rtB_CAN_Task_npc_controller CAN_Task;/* '<S152>/CAN_Task' */
  rtB_CANRX_npc_controller CANRX;      /* '<Root>/CANRX' */
} BlockIO_npc_controller;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T pos_seq;                      /* '<Root>/Data Store Memory71' */
  real_T rec_en;                       /* '<Root>/Data Store Memory72' */
  real_T can_on_cmd;                   /* '<Root>/Data Store Memory73' */
  real_T clllc_ok;                     /* '<Root>/Data Store Memory74' */
  real_T npc_fault;                    /* '<Root>/Data Store Memory75' */
  real_T inv_en;                       /* '<Root>/Data Store Memory76' */
  real_T state_control;                /* '<Root>/Data Store Memory77' */
  real_T can_timeout;                  /* '<Root>/Data Store Memory79' */
  real_T start_cnt;   /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T relayOff_cnt;/* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T relay_cnt;   /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T eoss_cnt;    /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real_T delay_cnt;   /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  real32_T Delay1_DSTATE;              /* '<S301>/Delay1' */
  real32_T Delay_DSTATE;               /* '<S301>/Delay' */
  real32_T Delay1_DSTATE_e;            /* '<S302>/Delay1' */
  real32_T Delay_DSTATE_e;             /* '<S302>/Delay' */
  real32_T Delay1_DSTATE_eo;           /* '<S300>/Delay1' */
  real32_T Delay_DSTATE_h;             /* '<S300>/Delay' */
  real32_T Delay2_DSTATE;              /* '<S134>/Delay2' */
  real32_T Delay2_DSTATE_j;            /* '<S133>/Delay2' */
  real32_T Delay2_DSTATE_l;            /* '<S132>/Delay2' */
  real32_T Delay2_DSTATE_h;            /* '<S131>/Delay2' */
  real32_T Delay2_DSTATE_k;            /* '<S130>/Delay2' */
  real32_T Delay2_DSTATE_a;            /* '<S129>/Delay2' */
  real32_T Delay_DSTATE_f;             /* '<S106>/Delay' */
  real32_T Delay_DSTATE_l;             /* '<S107>/Delay' */
  real32_T Delay_DSTATE_k;             /* '<S108>/Delay' */
  real32_T Delay_DSTATE_j;             /* '<S100>/Delay' */
  real32_T Delay_DSTATE_lx;            /* '<S101>/Delay' */
  real32_T Delay_DSTATE_m;             /* '<S102>/Delay' */
  real32_T Delay_DSTATE_e4;            /* '<S103>/Delay' */
  real32_T Delay_DSTATE_ef;            /* '<S104>/Delay' */
  real32_T Delay_DSTATE_d;             /* '<S105>/Delay' */
  real32_T f32IinA;                    /* '<Root>/f32IinA' */
  real32_T f32IinB;                    /* '<Root>/f32IinB' */
  real32_T f32IinC;                    /* '<Root>/f32IinC' */
  real32_T f32IphaseA;                 /* '<Root>/f32IphaseA' */
  real32_T f32IphaseB;                 /* '<Root>/f32IphaseB' */
  real32_T f32IphaseC;                 /* '<Root>/f32IphaseC' */
  real32_T f32Vaux;                    /* '<Root>/f32Vaux' */
  real32_T f32VinA;                    /* '<Root>/f32VinA' */
  real32_T f32VinB;                    /* '<Root>/f32VinB' */
  real32_T f32VinC;                    /* '<Root>/f32VinC' */
  real32_T f32Vpfc;                    /* '<Root>/f32Vpfc' */
  real32_T f32VpfcMid;                 /* '<Root>/f32VpfcMid' */
  real32_T adc_vmid;                   /* '<Root>/Data Store Memory1' */
  real32_T adc_va;                     /* '<Root>/Data Store Memory2' */
  real32_T adc_offset_vc;              /* '<Root>/Data Store Memory26' */
  real32_T adc_offset_ic;              /* '<Root>/Data Store Memory27' */
  real32_T adc_offset_vc_tmp;          /* '<Root>/Data Store Memory29' */
  real32_T adc_vb;                     /* '<Root>/Data Store Memory3' */
  real32_T adc_offset_ic_tmp;          /* '<Root>/Data Store Memory30' */
  real32_T adc_offset_vb;              /* '<Root>/Data Store Memory31' */
  real32_T adc_offset_ib;              /* '<Root>/Data Store Memory32' */
  real32_T adc_offset_vb_tmp;          /* '<Root>/Data Store Memory33' */
  real32_T adc_offset_ib_tmp;          /* '<Root>/Data Store Memory34' */
  real32_T adc_offset_va;              /* '<Root>/Data Store Memory35' */
  real32_T adc_offset_ia;              /* '<Root>/Data Store Memory36' */
  real32_T adc_offset_va_tmp;          /* '<Root>/Data Store Memory37' */
  real32_T adc_offset_ia_tmp;          /* '<Root>/Data Store Memory38' */
  real32_T rms_ib;                     /* '<Root>/Data Store Memory41' */
  real32_T rms_ic;                     /* '<Root>/Data Store Memory42' */
  real32_T rms_va;                     /* '<Root>/Data Store Memory43' */
  real32_T rms_vb;                     /* '<Root>/Data Store Memory44' */
  real32_T rms_vc;                     /* '<Root>/Data Store Memory47' */
  real32_T adc_temp_npcb;              /* '<Root>/Data Store Memory51' */
  real32_T adc_temp_npcc;              /* '<Root>/Data Store Memory52' */
  real32_T adc_temp_npca;              /* '<Root>/Data Store Memory53' */
  real32_T adc_vaux;                   /* '<Root>/Data Store Memory54' */
  real32_T rms_ia;                     /* '<Root>/Data Store Memory61' */
  real32_T rms_iphaseb;                /* '<Root>/Data Store Memory62' */
  real32_T rms_iphasec;                /* '<Root>/Data Store Memory63' */
  real32_T rms_iphasea;                /* '<Root>/Data Store Memory64' */
  real32_T adc_vbulk;                  /* '<Root>/Data Store Memory7' */
  real32_T adc_vc;                     /* '<Root>/Data Store Memory8' */
  real32_T otp_fault;                  /* '<Root>/Data Store Memory81' */
  real32_T f32GainLineCurrentCS;       /* '<Root>/f32IoutTarget1' */
  real32_T f32GainVbulk;               /* '<Root>/f32IoutTarget2' */
  real32_T f32GainVmid;                /* '<Root>/f32IoutTarget3' */
  real32_T f32GainLineCurrentHE;       /* '<Root>/f32IoutTarget4' */
  real32_T f32OffsetLineVoltage;       /* '<Root>/f32IoutTarget5' */
  real32_T f32GainLineVoltage;         /* '<Root>/f32IoutTarget6' */
  real32_T f32OffsetLineCurrentHE;     /* '<Root>/f32IoutTarget7' */
  real32_T f32OffsetLineCurrentCS;     /* '<Root>/f32IoutTarget8' */
  int32_T AC_OK_GPIO41_FRAC_LEN;       /* '<S152>/AC_OK_GPIO41' */
  int32_T RELAY_GPIO4_EPWM3A1_FRAC_LEN;/* '<S152>/RELAY_GPIO4_EPWM3A1' */
  int32_T PFC_OK_GPIO58_FRAC_LEN;      /* '<S152>/PFC_OK_GPIO58' */
  int32_T GPIO86_FRAC_LEN;             /* '<S266>/GPIO86' */
  Validate_DI_npc_controller obj_k;    /* '<S151>/Validate_DI' */
  uint16_T cnt_1ms;                    /* '<Root>/Data Store Memory4' */
  uint16_T sPriFault;                  /* '<Root>/sPriFault' */
  uint16_T sPriStatus;                 /* '<Root>/sPriStatus' */
  uint16_T u16Debug0;                  /* '<Root>/u16Debug0' */
  uint16_T u16Debug1;                  /* '<Root>/u16Debug1' */
  uint16_T u16Debug2;                  /* '<Root>/u16Debug2' */
  uint16_T u16Debug3;                  /* '<Root>/u16Debug3' */
  uint16_T u16Debug4;                  /* '<Root>/u16Debug4' */
  uint16_T u16Debug5;                  /* '<Root>/u16Debug5' */
  uint16_T u16Reserved1;               /* '<Root>/u16Reserved1' */
  uint16_T u16TxDelayCount;            /* '<Root>/u16TxDelayCount' */
  uint16_T tz_ovp;                     /* '<Root>/Data Store Memory20' */
  uint16_T tz_ocp;                     /* '<Root>/Data Store Memory23' */
  uint16_T cnt_calib;                  /* '<Root>/Data Store Memory28' */
  uint16_T theta;                      /* '<Root>/Data Store Memory45' */
  uint16_T tz_cmpssocp;                /* '<Root>/Data Store Memory80' */
  uint16_T cnt_idle;                   /* '<Root>/Data Store Memory5' */
  boolean_T DelayInput1_DSTATE;        /* '<S145>/Delay Input1' */
  uint16_T u8CanDataRx10[8];           /* '<Root>/u8CanDataRx10' */
  uint16_T u8CanDataRx11[8];           /* '<Root>/u8CanDataRx11' */
  uint16_T u8CanDataRx12[8];           /* '<Root>/u8CanDataRx12' */
  uint16_T u8CanTxIndex;               /* '<Root>/u8CanTxIndex' */
  uint16_T u8FwRevData[8];             /* '<Root>/u8FwRevData' */
  uint16_T u8PriFutEnable;             /* '<Root>/u8PriFutEnable' */
  uint16_T u8RdReqMsgPntr;             /* '<Root>/u8RdReqMsgPntr' */
  uint16_T u8Reserved1;                /* '<Root>/u8Reserved1' */
  uint16_T u8TclllcP1;                 /* '<Root>/u8TclllcP1' */
  uint16_T u8TclllcP2;                 /* '<Root>/u8TclllcP2' */
  uint16_T u8ThermalFlags;             /* '<Root>/u8ThermalFlags' */
  uint16_T u8TnpcA;                    /* '<Root>/u8TnpcA' */
  uint16_T u8TnpcB;                    /* '<Root>/u8TnpcB' */
  uint16_T u8TnpcC;                    /* '<Root>/u8TnpcC' */
  uint16_T is_active_c23_npc_controller;/* '<S291>/hkeep1' */
  uint16_T is_active_c3_npc_controller;/* '<S152>/Chart1' */
  uint16_T is_active_c20_npc_controller;/* '<S111>/Chart' */
  uint16_T is_c20_npc_controller;      /* '<S111>/Chart' */
  uint16_T is_active_c18_npc_controller;/* '<S139>/Chart2' */
  uint16_T is_c18_npc_controller;      /* '<S139>/Chart2' */
  boolean_T relay_ctrl;                /* '<Root>/Data Store Memory65' */
  boolean_T pfc_ok;                    /* '<Root>/Data Store Memory66' */
  boolean_T ac_ok;                     /* '<Root>/Data Store Memory68' */
  boolean_T b00_DebugEnabled;          /* '<Root>/b00' */
  boolean_T b01_ReadRequest;           /* '<Root>/b01' */
  boolean_T b05_MB10Received;          /* '<Root>/b05' */
  boolean_T b06_MB11Received;          /* '<Root>/b06' */
  boolean_T b07_MB12Received;          /* '<Root>/b07' */
  boolean_T tfv_vbulk;                 /* '<Root>/Data Store Memory10' */
  boolean_T tfv_vmid;                  /* '<Root>/Data Store Memory11' */
  boolean_T tfv_va;                    /* '<Root>/Data Store Memory12' */
  boolean_T tfv_vb;                    /* '<Root>/Data Store Memory13' */
  boolean_T tfv_vc;                    /* '<Root>/Data Store Memory14' */
  boolean_T control_en;                /* '<Root>/Data Store Memory15' */
  boolean_T tfv_iphaseb;               /* '<Root>/Data Store Memory16' */
  boolean_T tfv_iphasec;               /* '<Root>/Data Store Memory17' */
  boolean_T tfv_vtop;                  /* '<Root>/Data Store Memory21' */
  boolean_T tfv_vaux;                  /* '<Root>/Data Store Memory39' */
  boolean_T tfv_iphasea;               /* '<Root>/Data Store Memory6' */
  boolean_T pfc_en;                    /* '<Root>/Data Store Memory67' */
  boolean_T fault;    /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  boolean_T fut_en;   /* '<S111>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2nvq;/* '<S294>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2nv;/* '<S294>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2n;/* '<S294>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2;/* '<S294>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n;/* '<S294>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem;/* '<S294>/MATLAB System' */
} D_Work_npc_controller;

/* Invariant block signals (default storage) */
typedef struct {
  const real_T Gain1;                  /* '<S339>/Gain1' */
  const real_T Gain2;                  /* '<S339>/Gain2' */
  const real_T Gain4;                  /* '<S339>/Gain4' */
  const real_T Gain3;                  /* '<S339>/Gain3' */
  const real_T Gain5;                  /* '<S339>/Gain5' */
  const real_T Gain6;                  /* '<S339>/Gain6' */
} ConstBlockIO_npc_controller;

/* Constant parameters (default storage) */
typedef struct {
  /* Pooled Parameter (Expression: [150
     149
     148
     147
     146
     145
     144
     143
     142
     141
     140
     139
     138
     137
     136
     135
     134
     133
     132
     131
     130
     129
     128
     127
     126
     125
     124
     123
     122
     121
     120
     119
     118
     117
     116
     115
     114
     113
     112
     111
     110
     109
     108
     107
     106
     105
     104
     103
     102
     101
     100
     99
     98
     97
     96
     95
     94
     93
     92
     91
     90
     89
     88
     87
     86
     85
     84
     83
     82
     81
     80
     79
     78
     77
     76
     75
     74
     73
     72
     71
     70
     69
     68
     67
     66
     65
     64
     63
     62
     61
     60
     59
     58
     57
     56
     55
     54
     53
     52
     51
     50
     49
     48
     47
     46
     45
     44
     43
     42
     41
     40
     39
     38
     37
     36
     35
     34
     33
     32
     31
     30
     29
     28
     27
     26
     25
     24
     23
     22
     21
     20
     19
     18
     17
     16
     15
     14
     13
     12
     11
     10
     9
     8
     7
     6
     5
     4
     3
     2
     1
     0
     -1
     -2
     -3
     -4
     -5
     -6
     -7
     -8
     -9
     -10
     -11
     -12
     -13
     -14
     -15
     -16
     -17
     -18
     -19
     -20
     -21
     -22
     -23
     -24
     -25
     -26
     -27
     -28
     -29
     -30
     -31
     -32
     -33
     -34
     -35
     -36
     -37
     -38
     -39
     -40
     ])
   * Referenced by:
   *   '<S266>/1-D Lookup Table1'
   *   '<S266>/1-D Lookup Table2'
   *   '<S266>/1-D Lookup Table3'
   */
  real32_T pooled29[191];

  /* Pooled Parameter (Expression: [369
     370
     372
     374
     376
     377
     379
     381
     383
     385
     387
     388
     390
     392
     394
     396
     398
     400
     402
     404
     406
     408
     410
     411
     413
     415
     417
     420
     422
     424
     426
     428
     430
     432
     434
     436
     438
     440
     442
     445
     447
     449
     451
     453
     456
     458
     460
     462
     465
     467
     469
     472
     474
     476
     479
     481
     483
     486
     488
     490
     493
     495
     498
     500
     503
     505
     508
     510
     513
     515
     518
     521
     523
     526
     528
     531
     534
     536
     539
     542
     544
     547
     550
     553
     555
     558
     561
     564
     567
     570
     573
     575
     578
     581
     584
     587
     590
     593
     596
     599
     602
     605
     608
     612
     615
     618
     621
     624
     627
     631
     634
     637
     640
     644
     647
     650
     653
     657
     660
     664
     667
     670
     674
     677
     681
     684
     688
     691
     695
     699
     702
     706
     710
     713
     717
     721
     724
     728
     732
     736
     739
     743
     747
     751
     755
     759
     763
     767
     770
     774
     778
     782
     787
     791
     795
     799
     803
     807
     811
     815
     819
     824
     828
     832
     836
     841
     845
     849
     853
     858
     862
     867
     871
     875
     880
     884
     889
     893
     897
     902
     906
     911
     915
     920
     925
     929
     934
     938
     943
     947
     952
     ])
   * Referenced by:
   *   '<S266>/1-D Lookup Table1'
   *   '<S266>/1-D Lookup Table2'
   *   '<S266>/1-D Lookup Table3'
   */
  real32_T pooled30[191];
} ConstParam_npc_controller;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T sim_adc_quantized;            /* '<Root>/sim_adc_quantized' */
} ExternalInputs_npc_controller;

/* Real-time Model Data Structure */
struct tag_RTM_npc_controller {
  const char_T * volatile errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint16_T TID[3];
    } TaskCounters;
  } Timing;
};

extern CAN_DATATYPE CAN_DATATYPE_GROUND;
extern CAN_DATATYPE CAN_DATATYPE_GROUND;
extern CAN_DATATYPE CAN_DATATYPE_GROUND;

/* Block signals (default storage) */
extern BlockIO_npc_controller npc_controller_B;

/* Block states (default storage) */
extern D_Work_npc_controller npc_controller_DWork;

/* External inputs (root inport signals with default storage) */
extern ExternalInputs_npc_controller npc_controller_U;
extern const ConstBlockIO_npc_controller npc_controller_ConstB;/* constant block i/o */

/* Constant parameters (default storage) */
extern const ConstParam_npc_controller npc_controller_ConstP;

/* External function called from main */
extern void npc_controller_SetEventsForThisBaseStep(boolean_T *eventFlags);

/* Model entry point functions */
extern void npc_controller_initialize(void);
extern void npc_controller_step0(void);
extern void npc_controller_step1(void);
extern void npc_controller_step2(void);
extern void npc_controller_terminate(void);
extern volatile boolean_T runModel;

/* Real-time Model object */
extern RT_MODEL_npc_controller *const npc_controller_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'npc_controller'
 * '<S1>'   : 'npc_controller/CANRX'
 * '<S2>'   : 'npc_controller/CONTROL'
 * '<S3>'   : 'npc_controller/IDLE_AND_TIMER'
 * '<S4>'   : 'npc_controller/CANRX/can_rcv'
 * '<S5>'   : 'npc_controller/CANRX/can_rcv/Switch Case Action Subsystem'
 * '<S6>'   : 'npc_controller/CANRX/can_rcv/Switch Case Action Subsystem1'
 * '<S7>'   : 'npc_controller/CANRX/can_rcv/Switch Case Action Subsystem2'
 * '<S8>'   : 'npc_controller/CONTROL/CONTROL'
 * '<S9>'   : 'npc_controller/CONTROL/GET_ADC'
 * '<S10>'  : 'npc_controller/CONTROL/GPIO_HIGH'
 * '<S11>'  : 'npc_controller/CONTROL/GPIO_LOW'
 * '<S12>'  : 'npc_controller/CONTROL/STATE-MACHINE'
 * '<S13>'  : 'npc_controller/CONTROL/CONTROL/false'
 * '<S14>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL'
 * '<S15>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL'
 * '<S16>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/GPIO_HIGH'
 * '<S17>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/GPIO_LOW'
 * '<S18>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL'
 * '<S19>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/2P2Z_para'
 * '<S20>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/Direction'
 * '<S21>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/If Action Subsystem'
 * '<S22>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/If Action Subsystem1'
 * '<S23>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia'
 * '<S24>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ib'
 * '<S25>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ic'
 * '<S26>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation'
 * '<S27>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole'
 * '<S28>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/2P2Z_para/200V'
 * '<S29>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/Direction/Forward (G2V)'
 * '<S30>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/Compare To Constant'
 * '<S31>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/Compare To Constant1'
 * '<S32>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/Saturation Dynamic1'
 * '<S33>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/hold peak duty during zc'
 * '<S34>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/peak duty'
 * '<S35>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/soft_start1'
 * '<S36>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/soft_start1/Saturation Dynamic'
 * '<S37>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ib/Saturation Dynamic1'
 * '<S38>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ic/Saturation Dynamic1'
 * '<S39>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Direction'
 * '<S40>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty'
 * '<S41>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty1'
 * '<S42>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty2'
 * '<S43>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty3'
 * '<S44>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Direction/Forward (G2V)'
 * '<S45>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty/Duty0Pct'
 * '<S46>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty/Duty5Pct'
 * '<S47>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty1/Duty0Pct'
 * '<S48>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty1/Duty5Pct'
 * '<S49>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty2/Duty0Pct'
 * '<S50>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty2/Duty5Pct'
 * '<S51>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty3/Duty0Pct'
 * '<S52>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty3/Duty5Pct'
 * '<S53>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole/Saturation Dynamic1'
 * '<S54>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole/Vpeak'
 * '<S55>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole/Vpeak/200V'
 * '<S56>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/Compare To Constant'
 * '<S57>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/Compare To Constant1'
 * '<S58>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/Compare To Constant2'
 * '<S59>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true'
 * '<S60>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true1'
 * '<S61>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true2'
 * '<S62>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true3'
 * '<S63>'  : 'npc_controller/CONTROL/GET_ADC/ADC'
 * '<S64>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen'
 * '<S65>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA'
 * '<S66>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC'
 * '<S67>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem'
 * '<S68>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem1'
 * '<S69>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem2'
 * '<S70>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem3'
 * '<S71>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem4'
 * '<S72>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem5'
 * '<S73>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem6'
 * '<S74>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem7'
 * '<S75>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem8'
 * '<S76>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem10'
 * '<S77>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem11'
 * '<S78>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem18'
 * '<S79>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6'
 * '<S80>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7'
 * '<S81>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8'
 * '<S82>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem9'
 * '<S83>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem1'
 * '<S84>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem2'
 * '<S85>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem1/If Action Subsystem'
 * '<S86>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem2/If Action Subsystem'
 * '<S87>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem1'
 * '<S88>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem2'
 * '<S89>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem1/If Action Subsystem'
 * '<S90>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem2/If Action Subsystem'
 * '<S91>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem1'
 * '<S92>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem2'
 * '<S93>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem1/If Action Subsystem'
 * '<S94>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem2/If Action Subsystem'
 * '<S95>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem12'
 * '<S96>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem13'
 * '<S97>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem14'
 * '<S98>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem15'
 * '<S99>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem16'
 * '<S100>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem/IIR Filter1'
 * '<S101>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem1/IIR Filter1'
 * '<S102>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem2/IIR Filter1'
 * '<S103>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem3/IIR Filter1'
 * '<S104>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem4/IIR Filter1'
 * '<S105>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem5/IIR Filter1'
 * '<S106>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem6/IIR Filter1'
 * '<S107>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem7/IIR Filter1'
 * '<S108>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem8/IIR Filter1'
 * '<S109>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine'
 * '<S110>' : 'npc_controller/CONTROL/STATE-MACHINE/Variant Subsystem'
 * '<S111>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine'
 * '<S112>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3'
 * '<S113>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Chart'
 * '<S114>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Detect Rise Positive1'
 * '<S115>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/configFutDis'
 * '<S116>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/configFutEn'
 * '<S117>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp'
 * '<S118>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectZCPhA'
 * '<S119>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/disablePwm'
 * '<S120>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/readCmpssOcp'
 * '<S121>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib'
 * '<S122>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst'
 * '<S123>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/OVP'
 * '<S124>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectUvpOvp/UVP'
 * '<S125>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectZCPhA/false'
 * '<S126>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/detectZCPhA/true'
 * '<S127>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt'
 * '<S128>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/done'
 * '<S129>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt/Subsystem1'
 * '<S130>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt/Subsystem2'
 * '<S131>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt/Subsystem3'
 * '<S132>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt/Subsystem4'
 * '<S133>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt/Subsystem5'
 * '<S134>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/cnt/Subsystem6'
 * '<S135>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/done/AUTO-CALIB_DONE'
 * '<S136>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/done/CLEAR_FAULTS'
 * '<S137>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateCalib/done/RESET_TZ'
 * '<S138>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst'
 * '<S139>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1'
 * '<S140>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/Chart2'
 * '<S141>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/enable'
 * '<S142>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/zero'
 * '<S143>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/zero_crossing_a'
 * '<S144>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/enable/PWM_and_SR_ON'
 * '<S145>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/Detect Rise Positive'
 * '<S146>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/false'
 * '<S147>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/true'
 * '<S148>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS3/updateSequencePhA_burst/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/Detect Rise Positive/Positive'
 * '<S149>' : 'npc_controller/CONTROL/STATE-MACHINE/State machine/Codegen_Statemachine/Detect Rise Positive1/Positive'
 * '<S150>' : 'npc_controller/CONTROL/STATE-MACHINE/Variant Subsystem/Codegen_PFC_EN'
 * '<S151>' : 'npc_controller/CONTROL/STATE-MACHINE/Variant Subsystem/Codegen_PFC_EN/Update_PFC_EN'
 * '<S152>' : 'npc_controller/IDLE_AND_TIMER/codegen'
 * '<S153>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task'
 * '<S154>' : 'npc_controller/IDLE_AND_TIMER/codegen/Chart1'
 * '<S155>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE'
 * '<S156>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION'
 * '<S157>' : 'npc_controller/IDLE_AND_TIMER/codegen/TIMER_1MS'
 * '<S158>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler'
 * '<S159>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler'
 * '<S160>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10'
 * '<S161>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB11'
 * '<S162>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12'
 * '<S163>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/All Legs'
 * '<S164>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Bit Shift'
 * '<S165>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Leg A'
 * '<S166>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Leg B'
 * '<S167>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Leg C'
 * '<S168>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Mode_Cmd'
 * '<S169>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Phase Type 1 Phase'
 * '<S170>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Phase Type 3 Phase'
 * '<S171>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Bit Shift/bit_shift'
 * '<S172>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB11/Red_Mode_Cmd'
 * '<S173>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd'
 * '<S174>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Read'
 * '<S175>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Write'
 * '<S176>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/Debug En//Dis'
 * '<S177>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/FUT En Dis'
 * '<S178>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/Debug En//Dis/Debug_Dis'
 * '<S179>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/Debug En//Dis/Debug_En'
 * '<S180>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/FUT En Dis/Disable FUT'
 * '<S181>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/FUT En Dis/Enable FUT'
 * '<S182>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Read/Debug_Cmd'
 * '<S183>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Increment Stored Integer'
 * '<S184>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine'
 * '<S185>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest'
 * '<S186>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData'
 * '<S187>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/ Tx FW Rev ID134'
 * '<S188>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx Cal Data ID135'
 * '<S189>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136'
 * '<S190>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137'
 * '<S191>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes'
 * '<S192>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes1'
 * '<S193>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes2'
 * '<S194>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes/Bit Shift'
 * '<S195>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S196>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes1/Bit Shift'
 * '<S197>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes1/Bit Shift/bit_shift'
 * '<S198>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes2/Bit Shift'
 * '<S199>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes2/Bit Shift/bit_shift'
 * '<S200>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes'
 * '<S201>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes1'
 * '<S202>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes2'
 * '<S203>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes/Bit Shift'
 * '<S204>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S205>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes1/Bit Shift'
 * '<S206>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes1/Bit Shift/bit_shift'
 * '<S207>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes2/Bit Shift'
 * '<S208>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes2/Bit Shift/bit_shift'
 * '<S209>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110'
 * '<S210>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130'
 * '<S211>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131'
 * '<S212>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132'
 * '<S213>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri4 ID133'
 * '<S214>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes'
 * '<S215>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes1'
 * '<S216>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes2'
 * '<S217>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/TxReadRequest'
 * '<S218>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/u16 Data to Bytes'
 * '<S219>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes/Bit Shift'
 * '<S220>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes/Bit Shift/bit_shift'
 * '<S221>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes1/Bit Shift'
 * '<S222>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes1/Bit Shift/bit_shift'
 * '<S223>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes2/Bit Shift'
 * '<S224>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S225>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/u16 Data to Bytes/Bit Shift'
 * '<S226>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S227>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/Float Data to Bytes2'
 * '<S228>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes'
 * '<S229>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes1'
 * '<S230>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/Float Data to Bytes2/Bit Shift'
 * '<S231>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S232>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes/Bit Shift'
 * '<S233>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S234>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes1/Bit Shift'
 * '<S235>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes1/Bit Shift/bit_shift'
 * '<S236>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes'
 * '<S237>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes1'
 * '<S238>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes2'
 * '<S239>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes3'
 * '<S240>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes/Bit Shift'
 * '<S241>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes/Bit Shift/bit_shift'
 * '<S242>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes1/Bit Shift'
 * '<S243>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes1/Bit Shift/bit_shift'
 * '<S244>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes2/Bit Shift'
 * '<S245>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S246>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes3/Bit Shift'
 * '<S247>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes3/Bit Shift/bit_shift'
 * '<S248>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes'
 * '<S249>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes1'
 * '<S250>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes2'
 * '<S251>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes3'
 * '<S252>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes/Bit Shift'
 * '<S253>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes/Bit Shift/bit_shift'
 * '<S254>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes1/Bit Shift'
 * '<S255>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes1/Bit Shift/bit_shift'
 * '<S256>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes2/Bit Shift'
 * '<S257>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S258>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes3/Bit Shift'
 * '<S259>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes3/Bit Shift/bit_shift'
 * '<S260>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/cnt_idle'
 * '<S261>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task'
 * '<S262>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/cnt_idle/cnt_idle'
 * '<S263>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/cnt_idle/cnt_idle_sat'
 * '<S264>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise'
 * '<S265>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep'
 * '<S266>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc'
 * '<S267>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits'
 * '<S268>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/watchdog'
 * '<S269>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift'
 * '<S270>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift1'
 * '<S271>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift2'
 * '<S272>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift27'
 * '<S273>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift3'
 * '<S274>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift4'
 * '<S275>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift5'
 * '<S276>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift6'
 * '<S277>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift7'
 * '<S278>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift8'
 * '<S279>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift9'
 * '<S280>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift/bit_shift'
 * '<S281>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift1/bit_shift'
 * '<S282>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift2/bit_shift'
 * '<S283>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift27/bit_shift'
 * '<S284>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift3/bit_shift'
 * '<S285>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift4/bit_shift'
 * '<S286>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift5/bit_shift'
 * '<S287>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift6/bit_shift'
 * '<S288>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift7/bit_shift'
 * '<S289>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift8/bit_shift'
 * '<S290>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift9/bit_shift'
 * '<S291>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv'
 * '<S292>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tz'
 * '<S293>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1'
 * '<S294>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVa'
 * '<S295>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVaux'
 * '<S296>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVb'
 * '<S297>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVbulk'
 * '<S298>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVc'
 * '<S299>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVmid'
 * '<S300>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/IIR (1s at 750Hz)'
 * '<S301>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/IIR (1s at 750Hz)1'
 * '<S302>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/IIR (1s at 750Hz)2'
 * '<S303>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP'
 * '<S304>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem1'
 * '<S305>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem10'
 * '<S306>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem11'
 * '<S307>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem2'
 * '<S308>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem3'
 * '<S309>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem4'
 * '<S310>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem5'
 * '<S311>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem6'
 * '<S312>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem7'
 * '<S313>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem8'
 * '<S314>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem9'
 * '<S315>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift1'
 * '<S316>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift10'
 * '<S317>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift11'
 * '<S318>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift12'
 * '<S319>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift2'
 * '<S320>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift3'
 * '<S321>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift4'
 * '<S322>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift5'
 * '<S323>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift6'
 * '<S324>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift7'
 * '<S325>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift8'
 * '<S326>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift9'
 * '<S327>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift1/bit_shift'
 * '<S328>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift10/bit_shift'
 * '<S329>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift11/bit_shift'
 * '<S330>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift12/bit_shift'
 * '<S331>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift2/bit_shift'
 * '<S332>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift3/bit_shift'
 * '<S333>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift4/bit_shift'
 * '<S334>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift5/bit_shift'
 * '<S335>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift6/bit_shift'
 * '<S336>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift7/bit_shift'
 * '<S337>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift8/bit_shift'
 * '<S338>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift9/bit_shift'
 * '<S339>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION/cmpss'
 * '<S340>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION/epwm'
 * '<S341>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION/orps&relay'
 * '<S342>' : 'npc_controller/IDLE_AND_TIMER/codegen/TIMER_1MS/codegen'
 * '<S343>' : 'npc_controller/IDLE_AND_TIMER/codegen/TIMER_1MS/codegen/periodic_timer1'
 */
#endif                                 /* RTW_HEADER_npc_controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
