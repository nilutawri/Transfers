#include "can_message.h"

/* A ground reference for CAN_DATATYPE */
CAN_DATATYPE CAN_DATATYPE_GROUND;
