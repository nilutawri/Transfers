/*
 * File: periodic_timer1.c
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.30
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri May 26 11:55:14 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "npc_controller.h"
#include "rtwtypes.h"
#include "periodic_timer1.h"
#include "npc_controller_private.h"

/* Output and update for atomic system: '<S342>/periodic_timer1' */
void npc_control_periodic_timer1(uint16_T *rtd_cnt_1ms)
{
  /* DataStoreWrite: '<S343>/Data Store Write1' incorporates:
   *  Constant: '<S343>/Constant1'
   *  DataStoreRead: '<S343>/Data Store Read1'
   *  Sum: '<S343>/Add1'
   */
  (*rtd_cnt_1ms)++;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
