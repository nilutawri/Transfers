/*
 * File: CANRX.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.30
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri May 26 11:55:14 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CANRX_h_
#define RTW_HEADER_CANRX_h_
#ifndef npc_controller_COMMON_INCLUDES_
#define npc_controller_COMMON_INCLUDES_
#include <string.h>
#include <math.h>
#include "rtwtypes.h"
#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "IQmathLib.h"
#include "can_message.h"
#include "F2837xS_device.h"
#include "MW_c2000DAC.h"
#include "MW_c28xCMPSS.h"
#endif                                 /* npc_controller_COMMON_INCLUDES_ */

/* Block signals for system '<Root>/CANRX' */
typedef struct {
  uint16_T eCANReceive2_o2[8];         /* '<S7>/eCAN Receive2' */
  uint16_T eCANReceive1_o2[8];         /* '<S6>/eCAN Receive1' */
  uint16_T eCANReceive_o2[8];          /* '<S5>/eCAN Receive' */
} rtB_CANRX_npc_controller;

extern void npc_controller_CANRX_Init(rtB_CANRX_npc_controller *localB);
extern void npc_controller_CANRX(boolean_T *rtd_b05_MB10Received, boolean_T
  *rtd_b06_MB11Received, boolean_T *rtd_b07_MB12Received, uint16_T
  rtd_u8CanDataRx10[8], uint16_T rtd_u8CanDataRx11[8], uint16_T
  rtd_u8CanDataRx12[8], rtB_CANRX_npc_controller *localB);

#endif                                 /* RTW_HEADER_CANRX_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
