#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "rtwtypes.h"
#include "npc_controller.h"
#include "npc_controller_private.h"

void initWatchdog()
{
  EALLOW;
  WdRegs.SCSR.all = 0x0000;
  EDIS;

  /*reset watchdog count   */
  KickDog();
  EALLOW;
  WdRegs.WDCR.all = 41;
  EDIS;
}
