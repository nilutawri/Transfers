#ifndef CUSTOM_CODE_H
#define CUSTOM_CODE_H
/* The above is an include guard that makes sure that this
header file is included only once. */

#define updateTz() (EPwm1Regs.TZOSTFLG.bit.OST2)

#endif /* CUSTOM_CODE_H */
