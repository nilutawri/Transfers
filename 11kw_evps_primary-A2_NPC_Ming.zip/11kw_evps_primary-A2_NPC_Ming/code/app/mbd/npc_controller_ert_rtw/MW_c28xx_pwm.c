#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "rtwtypes.h"
#include "npc_controller.h"
#include "npc_controller_private.h"

void config_ePWM_GPIO (void)
{
  EALLOW;
  ClkCfgRegs.PERCLKDIVSEL.bit.EPWMCLKDIV = 0U;

  /*-- Configure pin assignments for ePWM6 --*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1U;/* Configure GPIOGPIO10 as EPWM6A*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO11 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1U;/* Configure GPIOGPIO11 as EPWM6B*/

  /*-- Configure pin assignments for ePWM5 --*/

  /*-- Configure pin assignments for ePWM1 --*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1U; /* Configure GPIOGPIO0 as EPWM1A*/

  /*-- Configure pin assignments for ePWM10 --*/
  GpioCtrlRegs.GPAGMUX2.bit.GPIO18 = 1U;
  GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 1U;/* Configure GPIOGPIO18 as EPWM10A*/
  GpioCtrlRegs.GPAGMUX2.bit.GPIO19 = 1U;
  GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 1U;/* Configure GPIOGPIO19 as EPWM10B*/

  /*-- Configure pin assignments for ePWM11 --*/
  GpioCtrlRegs.GPAGMUX2.bit.GPIO20 = 1U;
  GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 1U;/* Configure GPIOGPIO20 as EPWM11A*/
  GpioCtrlRegs.GPAGMUX2.bit.GPIO21 = 1U;
  GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 1U;/* Configure GPIOGPIO21 as EPWM11B*/

  /*-- Configure pin assignments for ePWM2 --*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO2 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1U; /* Configure GPIOGPIO2 as EPWM2A*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO3 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1U; /* Configure GPIOGPIO3 as EPWM2B*/

  /*-- Configure pin assignments for ePWM3 --*/

  /*-- Configure pin assignments for ePWM4 --*/

  /*-- Configure pin assignments for ePWM7 --*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO12 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1U;/* Configure GPIOGPIO12 as EPWM7A*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO13 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1U;/* Configure GPIOGPIO13 as EPWM7B*/

  /*-- Configure pin assignments for ePWM8 --*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 1U;/* Configure GPIOGPIO14 as EPWM8A*/
  GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0U;
  GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 1U;/* Configure GPIOGPIO15 as EPWM8B*/

  /*-- Configure pin assignments for ePWM9 --*/
  GpioCtrlRegs.GPAGMUX2.bit.GPIO16 = 1U;
  GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 1U;/* Configure GPIOGPIO16 as EPWM9A*/
  GpioCtrlRegs.GPAGMUX2.bit.GPIO17 = 1U;
  GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 1U;/* Configure GPIOGPIO17 as EPWM9B*/
  EDIS;
}

void config_ePWM_XBAR (void)
{
  /*--- Configure ePWM Xbars ---*/
  EALLOW;
  EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX0 = 1U;
  EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX0 = 1U;
  EPwmXbarRegs.TRIPOUTINV.bit.TRIP4 = 0U;
  EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX2 = 1U;
  EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX2 = 1U;
  EPwmXbarRegs.TRIPOUTINV.bit.TRIP5 = 0U;
  EPwmXbarRegs.TRIP7MUXENABLE.bit.MUX6 = 1U;
  EPwmXbarRegs.TRIP7MUX0TO15CFG.bit.MUX6 = 1U;
  EPwmXbarRegs.TRIPOUTINV.bit.TRIP7 = 0U;
  EDIS;
}

void config_ePWM_TBSync (void)
{
  /* Enable TBCLK within the EPWM*/
  EALLOW;

  /* Enable TBCLK after the ePWM configurations */
  CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1U;
  EDIS;
}

void config_ePWMSyncSource (void)
{
  /* Configuring EXTSYNCOUT source selection */
  EALLOW;
  SyncSocRegs.SYNCSELECT.bit.SYNCOUT = 0U;

  /* Configuring ePWM Sync in source selection */
  SyncSocRegs.SYNCSELECT.bit.EPWM4SYNCIN = 0U;
  SyncSocRegs.SYNCSELECT.bit.EPWM7SYNCIN = 0U;
  SyncSocRegs.SYNCSELECT.bit.EPWM10SYNCIN = 0U;
  EDIS;
}
