/*
 * File: npc_controller_private.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.19
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 24 14:22:57 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_npc_controller_private_h_
#define RTW_HEADER_npc_controller_private_h_
#include "rtwtypes.h"
#include "npc_controller.h"
#include "npc_controller_types.h"
#include "can_message.h"
#include "MW_f2837xS_includes.h"
#include "can_message.h"
#include "MW_f2837xS_includes.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFFFU) ) || ( SCHAR_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

void InitAdcA (void);
void config_ADCA_SOC0 (void);
void config_ADCA_SOC4 (void);
void config_ADCA_SOC3 (void);
void config_ADCA_SOC2 (void);
void config_ADCA_SOC5 (void);
void config_ADCA_SOC6 (void);
void config_ADCA_SOC7 (void);
void InitAdcB (void);
void config_ADCB_SOC0 (void);
void config_ADCB_SOC1 (void);
void config_ADCB_SOC2 (void);
void config_ADCB_SOC3 (void);
void config_ADCB_SOC4 (void);
extern Uint16 Cla1Prog_Start;
extern CAN_DATATYPE CAN_DATATYPE_GROUND;
extern uint16_T MW_adcAInitFlag;
extern uint16_T MW_adcBInitFlag;
__interrupt void Cla1Task1();
void isr_int1pie1_task_fcn(void);
void isr_int9pie5_task_fcn(void);
extern void configureGPIOExtInterrupt(void);
void idle_num1_task_fcn(void);
extern real32_T look1_iflf_binlxpw(real32_T u0, const real32_T bp0[], const
  real32_T table[], uint32_T maxIndex);
extern void npc_contro_detectZCPhA_Init(rtB_detectZCPhA_npc_controller *localB);
extern void npc_controller_detectZCPhA(real_T rtu_vxn,
  rtB_detectZCPhA_npc_controller *localB);
extern void npc_controller_Chart2_Init(rtB_Chart2_npc_controller *localB,
  rtDW_Chart2_npc_controller *localDW);
extern void npc_controller_Chart2_Reset(rtB_Chart2_npc_controller *localB,
  rtDW_Chart2_npc_controller *localDW);
extern void npc_controller_Chart2(real32_T rtu_I_ref, real32_T rtu_zc, real32_T
  rtu_I_th, rtB_Chart2_npc_controller *localB, rtDW_Chart2_npc_controller
  *localDW);
extern void npc_controller_BitShift(uint16_T rtu_u, rtB_BitShift_npc_controller *
  localB);
extern void npc_controller_CAN_Task(boolean_T *rtd_b00_DebugEnabled, boolean_T
  *rtd_b01_ReadRequest, boolean_T *rtd_b05_MB10Received, boolean_T
  *rtd_b06_MB11Received, boolean_T *rtd_b07_MB12Received, const real32_T
  *rtd_f32IinA, const real32_T *rtd_f32IinB, const real32_T *rtd_f32IinC,
  real32_T *rtd_f32IoutTarget, const real32_T *rtd_f32IphaseA, const real32_T
  *rtd_f32IphaseB, const real32_T *rtd_f32IphaseC, real32_T *rtd_f32V2GPwrTarget,
  const real32_T *rtd_f32Vaux, const real32_T *rtd_f32VinA, const real32_T
  *rtd_f32VinB, const real32_T *rtd_f32VinC, real32_T *rtd_f32VoutTarget, const
  real32_T *rtd_f32Vpfc, const real32_T *rtd_f32VpfcMid, const uint16_T
  *rtd_sPriFault, const uint16_T *rtd_sPriStatus, const uint16_T *rtd_u16Debug0,
  const uint16_T *rtd_u16Debug1, const uint16_T *rtd_u16Debug2, const uint16_T
  *rtd_u16Debug3, const uint16_T *rtd_u16Debug4, const uint16_T *rtd_u16Debug5,
  const uint16_T *rtd_u16Reserved1, uint16_T *rtd_u16TxDelayCount, uint16_T
  *rtd_u8AliveCounter, const uint16_T rtd_u8CanDataRx10[8], const uint16_T
  rtd_u8CanDataRx11[8], const uint16_T rtd_u8CanDataRx12[8], uint16_T
  *rtd_u8CanTxIndex, const uint16_T rtd_u8FwRevData[8], uint16_T
  *rtd_u8GridPhaseType, uint16_T *rtd_u8ModeCmd, uint16_T *rtd_u8PriFutEnable,
  uint16_T *rtd_u8RdReqMsgPntr, uint16_T *rtd_u8RedunModeCmd, const uint16_T
  *rtd_u8Reserved1, uint16_T *rtd_u8SinglePhaseLeg, const uint16_T
  *rtd_u8TclllcP1, const uint16_T *rtd_u8TclllcP2, const uint16_T
  *rtd_u8ThermalFlags, const uint16_T *rtd_u8TnpcA, const uint16_T *rtd_u8TnpcB,
  const uint16_T *rtd_u8TnpcC, rtB_CAN_Task_npc_controller *localB);
extern void npc_controller_BitShift1(uint16_T rtu_u,
  rtB_BitShift1_npc_controller *localB);
extern void npc_controller_BitShift2(uint16_T rtu_u,
  rtB_BitShift2_npc_controller *localB);
extern void npc_controller_BitShift3(uint16_T rtu_u,
  rtB_BitShift3_npc_controller *localB);
extern void npc_controller_BitShift4(uint16_T rtu_u,
  rtB_BitShift4_npc_controller *localB);
extern void npc_controller_BitShift5(uint16_T rtu_u,
  rtB_BitShift5_npc_controller *localB);
extern void npc_controller_BitShift6(uint16_T rtu_u,
  rtB_BitShift6_npc_controller *localB);
extern void npc_controller_BitShift7(uint16_T rtu_u,
  rtB_BitShift7_npc_controller *localB);
extern void npc_controller_BitShift8(uint16_T rtu_u,
  rtB_BitShift8_npc_controller *localB);
extern void npc_contr_MATLABSystem_Init(rtDW_MATLABSystem_npc_controlle *localDW);
extern void npc_controller_MATLABSystem(uint16_T rtu_0, uint16_T rtu_1, uint16_T
  rtu_2, uint16_T rtu_5, rtB_MATLABSystem_npc_controller *localB,
  rtDW_MATLABSystem_npc_controlle *localDW);
extern void npc_contr_MATLABSystem_Term(rtDW_MATLABSystem_npc_controlle *localDW);
void isr_int1pie1_task_fcn(void);

#endif                                /* RTW_HEADER_npc_controller_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
