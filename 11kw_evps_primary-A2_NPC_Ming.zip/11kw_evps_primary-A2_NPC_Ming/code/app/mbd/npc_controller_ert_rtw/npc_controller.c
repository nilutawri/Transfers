/*
 * File: npc_controller.c
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.19
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 24 14:22:57 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "npc_controller.h"
#include "rtwtypes.h"
#include "npc_controller_private.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "CANRX.h"
#include "periodic_timer1.h"
#include "cla_header.h"
#include <string.h>
#define npc_controll_IN_NO_ACTIVE_CHILD (0U)
#define npc_controller_IN_Burst        (1U)
#define npc_controller_IN_Contineous   (2U)

/* Exported data definition */

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Definition for custom storage class: Cla1DataRam */
#if defined(PRAGMA_FLAG_ia_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid1;                      /* '<S27>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid1)
#define PRAGMA_FLAG_ia_pid1
#endif

#if defined(PRAGMA_FLAG_ia_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid2;                      /* '<S27>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid2)
#define PRAGMA_FLAG_ia_pid2
#endif

#if defined(PRAGMA_FLAG_ia_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid3;                      /* '<S27>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid3)
#define PRAGMA_FLAG_ia_pid3
#endif

#if defined(PRAGMA_FLAG_ia_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T ia_pid4;                      /* '<S27>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid4)
#define PRAGMA_FLAG_ia_pid4
#endif

#if defined(PRAGMA_FLAG_ib_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid1;                      /* '<S28>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid1)
#define PRAGMA_FLAG_ib_pid1
#endif

#if defined(PRAGMA_FLAG_ib_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid2;                      /* '<S28>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid2)
#define PRAGMA_FLAG_ib_pid2
#endif

#if defined(PRAGMA_FLAG_ib_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid3;                      /* '<S28>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid3)
#define PRAGMA_FLAG_ib_pid3
#endif

#if defined(PRAGMA_FLAG_ib_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T ib_pid4;                      /* '<S28>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid4)
#define PRAGMA_FLAG_ib_pid4
#endif

#if defined(PRAGMA_FLAG_ic_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid1;                      /* '<S29>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid1)
#define PRAGMA_FLAG_ic_pid1
#endif

#if defined(PRAGMA_FLAG_ic_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid2;                      /* '<S29>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid2)
#define PRAGMA_FLAG_ic_pid2
#endif

#if defined(PRAGMA_FLAG_ic_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid3;                      /* '<S29>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid3)
#define PRAGMA_FLAG_ic_pid3
#endif

#if defined(PRAGMA_FLAG_ic_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T ic_pid4;                      /* '<S29>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid4)
#define PRAGMA_FLAG_ic_pid4
#endif

#if defined(PRAGMA_FLAG_vbulk_delay1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_delay1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay1) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_delay1;                 /* '<S21>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay1)
#define PRAGMA_FLAG_vbulk_delay1
#endif

#if defined(PRAGMA_FLAG_vbulk_delay2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_delay2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay2) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_delay2;                 /* '<S21>/Delay' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay2)
#define PRAGMA_FLAG_vbulk_delay2
#endif

#if defined(PRAGMA_FLAG_vbulk_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid1) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid1;                   /* '<S31>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid1)
#define PRAGMA_FLAG_vbulk_pid1
#endif

#if defined(PRAGMA_FLAG_vbulk_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid2) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid2;                   /* '<S31>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid2)
#define PRAGMA_FLAG_vbulk_pid2
#endif

#if defined(PRAGMA_FLAG_vbulk_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid3) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid3;                   /* '<S31>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid3)
#define PRAGMA_FLAG_vbulk_pid3
#endif

#if defined(PRAGMA_FLAG_vbulk_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid4) || !defined(__TMS320C28XX_CLA__)

real32_T vbulk_pid4;                   /* '<S31>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid4)
#define PRAGMA_FLAG_vbulk_pid4
#endif

#if defined(PRAGMA_FLAG_vmid_delay1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vmid_delay1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vmid_delay1) || !defined(__TMS320C28XX_CLA__)

real32_T vmid_delay1;                  /* '<S20>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vmid_delay1)
#define PRAGMA_FLAG_vmid_delay1
#endif

#if defined(PRAGMA_FLAG_vmid_delay2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vmid_delay2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vmid_delay2) || !defined(__TMS320C28XX_CLA__)

real32_T vmid_delay2;                  /* '<S20>/Delay' */

#endif

#if !defined(PRAGMA_FLAG_vmid_delay2)
#define PRAGMA_FLAG_vmid_delay2
#endif

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Definition for custom storage class: Cla1ToCpuMsgRAM */
#if defined(PRAGMA_FLAG_cla2cpu_Ipk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla2cpu_Ipk,"Cla1ToCpuMsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Ipk) || !defined(__TMS320C28XX_CLA__)

real32_T cla2cpu_Ipk;                  /* '<S59>/Switch2' */

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Ipk)
#define PRAGMA_FLAG_cla2cpu_Ipk
#endif

#if defined(PRAGMA_FLAG_cla2cpu_Vpk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla2cpu_Vpk,"Cla1ToCpuMsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Vpk) || !defined(__TMS320C28XX_CLA__)

real_T cla2cpu_Vpk;

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Vpk)
#define PRAGMA_FLAG_cla2cpu_Vpk
#endif

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Definition for custom storage class: CpuToCla1MsgRAM */
#if defined(PRAGMA_FLAG_cpu2cla_angle) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_angle,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_angle) || !defined(__TMS320C28XX_CLA__)

real_T cpu2cla_angle;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_angle)
#define PRAGMA_FLAG_cpu2cla_angle
#endif

#if defined(PRAGMA_FLAG_cpu2cla_control_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_control_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_control_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_control_en;          /* '<S2>/Data Store Read' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_control_en)
#define PRAGMA_FLAG_cpu2cla_control_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ia) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ia,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ia) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ia;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ia)
#define PRAGMA_FLAG_cpu2cla_ia
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ib) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ib,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ib) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ib;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ib)
#define PRAGMA_FLAG_cpu2cla_ib
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ic) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ic,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ic) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ic;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ic)
#define PRAGMA_FLAG_cpu2cla_ic
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pfc_ok2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pfc_ok2,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pfc_ok2) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pfc_ok2;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pfc_ok2)
#define PRAGMA_FLAG_cpu2cla_pfc_ok2
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pha_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pha_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pha_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pha_en;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pha_en)
#define PRAGMA_FLAG_cpu2cla_pha_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_phb_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_phb_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phb_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_phb_en;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phb_en)
#define PRAGMA_FLAG_cpu2cla_phb_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_phc_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_phc_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phc_en) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_phc_en;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phc_en)
#define PRAGMA_FLAG_cpu2cla_phc_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pol_pha) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pol_pha,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_pha) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pol_pha;             /* '<S12>/GreaterThan' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_pha)
#define PRAGMA_FLAG_cpu2cla_pol_pha
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pol_phb) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pol_phb,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phb) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pol_phb;             /* '<S12>/GreaterThan1' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phb)
#define PRAGMA_FLAG_cpu2cla_pol_phb
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pol_phc) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pol_phc,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phc) || !defined(__TMS320C28XX_CLA__)

boolean_T cpu2cla_pol_phc;             /* '<S12>/GreaterThan2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phc)
#define PRAGMA_FLAG_cpu2cla_pol_phc
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ref) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ref,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ref) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_ref;  /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ref)
#define PRAGMA_FLAG_cpu2cla_ref
#endif

#if defined(PRAGMA_FLAG_cpu2cla_van) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_van,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_van) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_van;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_van)
#define PRAGMA_FLAG_cpu2cla_van
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vbn) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vbn,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbn) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vbn;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbn)
#define PRAGMA_FLAG_cpu2cla_vbn
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vbulk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vbulk,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbulk) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vbulk;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbulk)
#define PRAGMA_FLAG_cpu2cla_vbulk
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vcn) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vcn,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vcn) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vcn;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vcn)
#define PRAGMA_FLAG_cpu2cla_vcn
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vmid) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vmid,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vmid) || !defined(__TMS320C28XX_CLA__)

real32_T cpu2cla_vmid;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vmid)
#define PRAGMA_FLAG_cpu2cla_vmid
#endif

/* Block signals (default storage) */
BlockIO_npc_controller npc_controller_B;

/* Block states (default storage) */
D_Work_npc_controller npc_controller_DWork;

/* External inputs (root inport signals with default storage) */
ExternalInputs_npc_controller npc_controller_U;

/* Real-time model */
static RT_MODEL_npc_controller npc_controller_M_;
RT_MODEL_npc_controller *const npc_controller_M = &npc_controller_M_;
static void rate_monotonic_scheduler(void);

#ifndef __TMS320C28XX_CLA__

uint16_T MW_adcAInitFlag = 0;

#endif

#ifndef __TMS320C28XX_CLA__

uint16_T MW_adcBInitFlag = 0;

#endif

real32_T look1_iflf_binlxpw(real32_T u0, const real32_T bp0[], const real32_T
  table[], uint32_T maxIndex)
{
  real32_T frac;
  real32_T yL_0d0;
  uint32_T bpIdx;
  uint32_T iLeft;
  uint32_T iRght;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0UL]) {
    iLeft = 0UL;
    frac = (u0 - bp0[0UL]) / (bp0[1UL] - bp0[0UL]);
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search */
    bpIdx = maxIndex >> 1UL;
    iLeft = 0UL;
    iRght = maxIndex;
    while (iRght - iLeft > 1UL) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1UL;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1UL] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1UL;
    frac = (u0 - bp0[maxIndex - 1UL]) / (bp0[maxIndex] - bp0[maxIndex - 1UL]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1UL] - yL_0d0) * frac + yL_0d0;
}

/* Hardware Interrupt Block: '<Root>/C28x Hardware Interrupt2' */
void isr_int1pie1_task_fcn(void)
{
  if (1 == runModel) {
    /* Call the system: <Root>/CONTROL */
    {
      /* S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */

      /* Output and update for function-call system: '<Root>/CONTROL' */
      {
        real32_T rtb_Sum;
        real32_T rtb_Sum_b;
        real32_T rtb_Sum_e;
        real32_T rtb_Sum_l;
        real32_T rtb_Sum_oi;
        real32_T rtb_Sum_pz;
        real32_T rtb_vabc7_d;
        real32_T rtb_vabc7_f;
        real32_T rtb_vabc7_i;
        real32_T rtb_vabc7_l4;
        real32_T rtb_vabc7_o;
        real32_T rtb_vabc7_p;
        real32_T vabc3;
        real32_T vabc3_a;
        real32_T vabc3_aq;
        real32_T vabc3_b;
        real32_T vabc3_b3;
        real32_T vabc3_d;
        real32_T vabc3_e;
        real32_T vabc3_m;
        real32_T vabc3_n;
        int16_T tmp;
        uint16_T qY;
        boolean_T Constant1;
        boolean_T guard1 = false;

        /* DataStoreRead: '<S2>/Data Store Read' */
        cpu2cla_control_en = npc_controller_DWork.control_en;

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/GET_ADC'
         */
        /* S-Function (fcgen): '<S67>/Function-Call Generator' incorporates:
         *  SubSystem: '<S67>/ADCA'
         */
        /* S-Function (c2802xadc): '<S68>/ADC18' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC18 = (AdcaResultRegs.ADCRESULT0);
        }

        /* DataStoreWrite: '<S79>/Data Store Write3' */
        npc_controller_DWork.adc_vb = npc_controller_B.ADC18;

        /* Sum: '<S79>/vabc3' incorporates:
         *  DataStoreRead: '<S79>/Data Store Read4'
         */
        vabc3_a = npc_controller_B.ADC18 - npc_controller_DWork.adc_offset_vb;

        /* S-Function (c2802xadc): '<S68>/ADC5' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC5_b = (AdcaResultRegs.ADCRESULT4);
        }

        /* If: '<S82>/If3' incorporates:
         *  DataStoreRead: '<S82>/Data Store Read6'
         */
        if (!npc_controller_DWork.ac_ok) {
          /* Outputs for IfAction SubSystem: '<S82>/If Action Subsystem2' incorporates:
           *  ActionPort: '<S87>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S87>/If Action Subsystem' incorporates:
           *  ActionPort: '<S89>/Action Port'
           */
          /* If: '<S87>/If' incorporates:
           *  DataStoreWrite: '<S89>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasec = ((npc_controller_B.ADC5_b > 3705.0F)
            || (npc_controller_B.ADC5_b < 798.0F) ||
            npc_controller_DWork.tfv_iphasec);

          /* End of Outputs for SubSystem: '<S87>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S82>/If Action Subsystem2' */
        } else {
          /* Outputs for IfAction SubSystem: '<S82>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S86>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S86>/If Action Subsystem' incorporates:
           *  ActionPort: '<S88>/Action Port'
           */
          /* If: '<S86>/If2' incorporates:
           *  DataStoreWrite: '<S88>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasec = ((npc_controller_B.ADC5_b > 3342.0F)
            || (npc_controller_B.ADC5_b < 1162.0F) ||
            npc_controller_DWork.tfv_iphasec);

          /* End of Outputs for SubSystem: '<S86>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S82>/If Action Subsystem1' */
        }

        /* End of If: '<S82>/If3' */

        /* Sum: '<S82>/vabc3' incorporates:
         *  DataStoreRead: '<S82>/Data Store Read4'
         */
        vabc3_b3 = npc_controller_B.ADC5_b - npc_controller_DWork.adc_offset_ic;

        /* S-Function (c2802xadc): '<S68>/ADC7' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC7 = (AdcaResultRegs.ADCRESULT3);
        }

        /* DataStoreWrite: '<S80>/Data Store Write3' */
        npc_controller_DWork.adc_vc = npc_controller_B.ADC7;

        /* Sum: '<S80>/vabc3' incorporates:
         *  DataStoreRead: '<S80>/Data Store Read4'
         */
        vabc3_d = npc_controller_B.ADC7 - npc_controller_DWork.adc_offset_vc;

        /* S-Function (c2802xadc): '<S68>/ADC3' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC3_n = (AdcaResultRegs.ADCRESULT2);
        }

        /* If: '<S84>/If3' incorporates:
         *  DataStoreRead: '<S84>/Data Store Read6'
         */
        if (!npc_controller_DWork.ac_ok) {
          /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem2' incorporates:
           *  ActionPort: '<S95>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S95>/If Action Subsystem' incorporates:
           *  ActionPort: '<S97>/Action Port'
           */
          /* If: '<S95>/If' incorporates:
           *  DataStoreWrite: '<S97>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasea = ((npc_controller_B.ADC3_n > 3705.0F)
            || (npc_controller_B.ADC3_n < 798.0F) ||
            npc_controller_DWork.tfv_iphasea);

          /* End of Outputs for SubSystem: '<S95>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S84>/If Action Subsystem2' */
        } else {
          /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S94>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S94>/If Action Subsystem' incorporates:
           *  ActionPort: '<S96>/Action Port'
           */
          /* If: '<S94>/If2' incorporates:
           *  DataStoreWrite: '<S96>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphasea = ((npc_controller_B.ADC3_n > 3342.0F)
            || (npc_controller_B.ADC3_n < 1162.0F) ||
            npc_controller_DWork.tfv_iphasea);

          /* End of Outputs for SubSystem: '<S94>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S84>/If Action Subsystem1' */
        }

        /* End of If: '<S84>/If3' */

        /* Sum: '<S84>/vabc3' incorporates:
         *  DataStoreRead: '<S84>/Data Store Read4'
         */
        vabc3_aq = npc_controller_B.ADC3_n - npc_controller_DWork.adc_offset_ia;

        /* S-Function (c2802xadc): '<S68>/ADC6' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC6_b = (AdcaResultRegs.ADCRESULT5);
        }

        /* DataTypeConversion: '<S85>/Cast To Single4' incorporates:
         *  DataStoreWrite: '<S85>/Data Store Write2'
         */
        vabc3_n = (real32_T)floor(npc_controller_B.ADC6_b);
        if (rtIsNaNF(vabc3_n) || rtIsInfF(vabc3_n)) {
          vabc3_n = 0.0F;
        } else {
          vabc3_n = (real32_T)fmod(vabc3_n, 65536.0);
        }

        npc_controller_DWork.u16Debug3 = vabc3_n < 0.0F ? (uint16_T)-(int16_T)
          (uint16_T)-vabc3_n : (uint16_T)vabc3_n;

        /* End of DataTypeConversion: '<S85>/Cast To Single4' */

        /* DataStoreWrite: '<S85>/Data Store Write3' */
        npc_controller_DWork.adc_va = npc_controller_B.ADC6_b;

        /* Sum: '<S85>/vabc3' incorporates:
         *  DataStoreRead: '<S85>/Data Store Read4'
         */
        vabc3_n = npc_controller_B.ADC6_b - npc_controller_DWork.adc_offset_va;

        /* S-Function (c2802xadc): '<S68>/ADC17' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC17 = (AdcaResultRegs.ADCRESULT6);
        }

        /* If: '<S83>/If3' incorporates:
         *  DataStoreRead: '<S83>/Data Store Read6'
         */
        if (!npc_controller_DWork.ac_ok) {
          /* Outputs for IfAction SubSystem: '<S83>/If Action Subsystem2' incorporates:
           *  ActionPort: '<S91>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S91>/If Action Subsystem' incorporates:
           *  ActionPort: '<S93>/Action Port'
           */
          /* If: '<S91>/If' incorporates:
           *  DataStoreWrite: '<S93>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphaseb = ((npc_controller_B.ADC17 > 3705.0F)
            || (npc_controller_B.ADC17 < 798.0F) ||
            npc_controller_DWork.tfv_iphaseb);

          /* End of Outputs for SubSystem: '<S91>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S83>/If Action Subsystem2' */
        } else {
          /* Outputs for IfAction SubSystem: '<S83>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S90>/Action Port'
           */
          /* Outputs for IfAction SubSystem: '<S90>/If Action Subsystem' incorporates:
           *  ActionPort: '<S92>/Action Port'
           */
          /* If: '<S90>/If2' incorporates:
           *  DataStoreWrite: '<S92>/Data Store Write1'
           */
          npc_controller_DWork.tfv_iphaseb = ((npc_controller_B.ADC17 > 3342.0F)
            || (npc_controller_B.ADC17 < 1162.0F) ||
            npc_controller_DWork.tfv_iphaseb);

          /* End of Outputs for SubSystem: '<S90>/If Action Subsystem' */
          /* End of Outputs for SubSystem: '<S83>/If Action Subsystem1' */
        }

        /* End of If: '<S83>/If3' */

        /* Sum: '<S83>/vabc3' incorporates:
         *  DataStoreRead: '<S83>/Data Store Read4'
         */
        vabc3_e = npc_controller_B.ADC17 - npc_controller_DWork.adc_offset_ib;

        /* S-Function (c2802xadc): '<S68>/ADC8' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          npc_controller_B.ADC8 = (AdcaResultRegs.ADCRESULT7);
        }

        /* DataStoreWrite: '<S81>/Data Store Write12' */
        npc_controller_DWork.adc_vaux = npc_controller_B.ADC8;

        /* S-Function (fcgen): '<S67>/Function-Call Generator' incorporates:
         *  SubSystem: '<S67>/ADCC'
         */
        /* S-Function (c2802xadc): '<S69>/ADC6' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC0 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC6 = (AdcbResultRegs.ADCRESULT0);
        }

        /* DataStoreWrite: '<S100>/Data Store Write' */
        npc_controller_DWork.adc_temp_npca = npc_controller_B.ADC6;

        /* Sum: '<S100>/vabc3' incorporates:
         *  DataStoreRead: '<S100>/Data Store Read4'
         */
        vabc3 = npc_controller_B.ADC6 - npc_controller_DWork.adc_offset_ia;

        /* S-Function (c2802xadc): '<S69>/ADC2' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC1 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC2 = (AdcbResultRegs.ADCRESULT1);
        }

        /* DataStoreWrite: '<S101>/Data Store Write' */
        npc_controller_DWork.adc_temp_npcb = npc_controller_B.ADC2;

        /* Sum: '<S101>/vabc3' incorporates:
         *  DataStoreRead: '<S101>/Data Store Read4'
         */
        vabc3_b = npc_controller_B.ADC2 - npc_controller_DWork.adc_offset_ib;

        /* S-Function (c2802xadc): '<S69>/ADC5' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC2 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC5 = (AdcbResultRegs.ADCRESULT2);
        }

        /* DataStoreWrite: '<S102>/Data Store Write' */
        npc_controller_DWork.adc_temp_npcc = npc_controller_B.ADC5;

        /* Sum: '<S102>/vabc3' incorporates:
         *  DataStoreRead: '<S102>/Data Store Read4'
         */
        vabc3_m = npc_controller_B.ADC5 - npc_controller_DWork.adc_offset_ic;

        /* S-Function (c2802xadc): '<S69>/ADC3' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC3 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC3 = (AdcbResultRegs.ADCRESULT3);
        }

        /* DataStoreWrite: '<S99>/Data Store Write6' */
        npc_controller_DWork.adc_vbulk = npc_controller_B.ADC3;

        /* S-Function (c2802xadc): '<S69>/ADC4' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          AdcbRegs.ADCSOCFRC1.bit.SOC4 = 1U;

          /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

          asm(" RPT #39|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

          float wait_index;
          for (wait_index= 6; wait_index > 0; wait_index--)
            __mnop();

#endif

          npc_controller_B.ADC4 = (AdcbResultRegs.ADCRESULT4);
        }

        /* DataStoreWrite: '<S98>/Data Store Write8' */
        npc_controller_DWork.adc_vmid = npc_controller_B.ADC4;

        /* End of Outputs for S-Function (fcgen): '<S67>/Function-Call Generator' */

        /* Sum: '<S109>/Sum' incorporates:
         *  Constant: '<S76>/Offset7'
         *  Constant: '<S76>/Offset8'
         *  Delay: '<S109>/Delay'
         *  Gain: '<S109>/1 - Lambda'
         *  Gain: '<S109>/Lambda'
         *  Product: '<S76>/Product'
         *  Product: '<S76>/Product1'
         *  RelationalOperator: '<S76>/Less Than'
         *  RelationalOperator: '<S76>/Less Than1'
         *  Sum: '<S76>/vabc7'
         */
        vabc3 = ((real32_T)(vabc3 > 0.0F) * vabc3 - (real32_T)(vabc3 < 0.0F) *
                 vabc3) * 0.00015384F + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_f;

        /* Gain: '<S76>/Gain' incorporates:
         *  DataStoreWrite: '<S76>/Data Store Write3'
         */
        npc_controller_DWork.rms_iphasea = 1.11F * vabc3;

        /* Sum: '<S110>/Sum' incorporates:
         *  Constant: '<S77>/Offset7'
         *  Constant: '<S77>/Offset8'
         *  Delay: '<S110>/Delay'
         *  Gain: '<S110>/1 - Lambda'
         *  Gain: '<S110>/Lambda'
         *  Product: '<S77>/Product'
         *  Product: '<S77>/Product1'
         *  RelationalOperator: '<S77>/Less Than'
         *  RelationalOperator: '<S77>/Less Than1'
         *  Sum: '<S77>/vabc7'
         */
        vabc3_b = ((real32_T)(vabc3_b > 0.0F) * vabc3_b - (real32_T)(vabc3_b <
                    0.0F) * vabc3_b) * 0.00015384F + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_l;

        /* Gain: '<S77>/Gain' incorporates:
         *  DataStoreWrite: '<S77>/Data Store Write3'
         */
        npc_controller_DWork.rms_iphaseb = 1.11F * vabc3_b;

        /* Sum: '<S111>/Sum' incorporates:
         *  Constant: '<S78>/Offset7'
         *  Constant: '<S78>/Offset8'
         *  Delay: '<S111>/Delay'
         *  Gain: '<S111>/1 - Lambda'
         *  Gain: '<S111>/Lambda'
         *  Product: '<S78>/Product'
         *  Product: '<S78>/Product1'
         *  RelationalOperator: '<S78>/Less Than'
         *  RelationalOperator: '<S78>/Less Than1'
         *  Sum: '<S78>/vabc7'
         */
        vabc3_m = ((real32_T)(vabc3_m > 0.0F) * vabc3_m - (real32_T)(vabc3_m <
                    0.0F) * vabc3_m) * 0.00015384F + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_k;

        /* Gain: '<S78>/Gain' incorporates:
         *  DataStoreWrite: '<S78>/Data Store Write3'
         */
        npc_controller_DWork.rms_iphasec = 1.11F * vabc3_m;

        /* Sum: '<S70>/vabc7' incorporates:
         *  Constant: '<S70>/Offset7'
         *  Constant: '<S70>/Offset8'
         *  Product: '<S70>/Product'
         *  Product: '<S70>/Product1'
         *  RelationalOperator: '<S70>/Less Than'
         *  RelationalOperator: '<S70>/Less Than1'
         */
        rtb_vabc7_f = (real32_T)(vabc3_n > 0.0F) * vabc3_n - (real32_T)(vabc3_n <
          0.0F) * vabc3_n;

        /* Sum: '<S103>/Sum' incorporates:
         *  Delay: '<S103>/Delay'
         *  Gain: '<S103>/1 - Lambda'
         *  Gain: '<S103>/Lambda'
         */
        rtb_Sum = 0.00015384F * rtb_vabc7_f + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_j;

        /* Gain: '<S70>/Gain' incorporates:
         *  DataStoreWrite: '<S70>/Data Store Write3'
         */
        npc_controller_DWork.rms_va = 1.11F * rtb_Sum;

        /* Sum: '<S71>/vabc7' incorporates:
         *  Constant: '<S71>/Offset7'
         *  Constant: '<S71>/Offset8'
         *  Product: '<S71>/Product'
         *  Product: '<S71>/Product1'
         *  RelationalOperator: '<S71>/Less Than'
         *  RelationalOperator: '<S71>/Less Than1'
         */
        rtb_vabc7_p = (real32_T)(vabc3_a > 0.0F) * vabc3_a - (real32_T)(vabc3_a <
          0.0F) * vabc3_a;

        /* Sum: '<S104>/Sum' incorporates:
         *  Delay: '<S104>/Delay'
         *  Gain: '<S104>/1 - Lambda'
         *  Gain: '<S104>/Lambda'
         */
        rtb_Sum_b = 0.00015384F * rtb_vabc7_p + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_lx;

        /* Gain: '<S71>/Gain' incorporates:
         *  DataStoreWrite: '<S71>/Data Store Write3'
         */
        npc_controller_DWork.rms_vb = 1.11F * rtb_Sum_b;

        /* Sum: '<S72>/vabc7' incorporates:
         *  Constant: '<S72>/Offset7'
         *  Constant: '<S72>/Offset8'
         *  Product: '<S72>/Product'
         *  Product: '<S72>/Product1'
         *  RelationalOperator: '<S72>/Less Than'
         *  RelationalOperator: '<S72>/Less Than1'
         */
        rtb_vabc7_o = (real32_T)(vabc3_d > 0.0F) * vabc3_d - (real32_T)(vabc3_d <
          0.0F) * vabc3_d;

        /* Sum: '<S105>/Sum' incorporates:
         *  Delay: '<S105>/Delay'
         *  Gain: '<S105>/1 - Lambda'
         *  Gain: '<S105>/Lambda'
         */
        rtb_Sum_oi = 0.00015384F * rtb_vabc7_o + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_mn;

        /* Gain: '<S72>/Gain' incorporates:
         *  DataStoreWrite: '<S72>/Data Store Write3'
         */
        npc_controller_DWork.rms_vc = 1.11F * rtb_Sum_oi;

        /* Sum: '<S73>/vabc7' incorporates:
         *  Constant: '<S73>/Offset7'
         *  Constant: '<S73>/Offset8'
         *  Product: '<S73>/Product'
         *  Product: '<S73>/Product1'
         *  RelationalOperator: '<S73>/Less Than'
         *  RelationalOperator: '<S73>/Less Than1'
         */
        rtb_vabc7_i = (real32_T)(vabc3_aq > 0.0F) * vabc3_aq - (real32_T)
          (vabc3_aq < 0.0F) * vabc3_aq;

        /* Sum: '<S106>/Sum' incorporates:
         *  Delay: '<S106>/Delay'
         *  Gain: '<S106>/1 - Lambda'
         *  Gain: '<S106>/Lambda'
         */
        rtb_Sum_pz = 0.00015384F * rtb_vabc7_i + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_e;

        /* Gain: '<S73>/Gain' incorporates:
         *  DataStoreWrite: '<S73>/Data Store Write3'
         */
        npc_controller_DWork.rms_ia = 1.11F * rtb_Sum_pz;

        /* Sum: '<S74>/vabc7' incorporates:
         *  Constant: '<S74>/Offset7'
         *  Constant: '<S74>/Offset8'
         *  Product: '<S74>/Product'
         *  Product: '<S74>/Product1'
         *  RelationalOperator: '<S74>/Less Than'
         *  RelationalOperator: '<S74>/Less Than1'
         */
        rtb_vabc7_d = (real32_T)(vabc3_e > 0.0F) * vabc3_e - (real32_T)(vabc3_e <
          0.0F) * vabc3_e;

        /* Sum: '<S107>/Sum' incorporates:
         *  Delay: '<S107>/Delay'
         *  Gain: '<S107>/1 - Lambda'
         *  Gain: '<S107>/Lambda'
         */
        rtb_Sum_l = 0.00015384F * rtb_vabc7_d + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_ef;

        /* Gain: '<S74>/Gain' incorporates:
         *  DataStoreWrite: '<S74>/Data Store Write3'
         */
        npc_controller_DWork.rms_ib = 1.11F * rtb_Sum_l;

        /* Sum: '<S75>/vabc7' incorporates:
         *  Constant: '<S75>/Offset7'
         *  Constant: '<S75>/Offset8'
         *  Product: '<S75>/Product'
         *  Product: '<S75>/Product1'
         *  RelationalOperator: '<S75>/Less Than'
         *  RelationalOperator: '<S75>/Less Than1'
         */
        rtb_vabc7_l4 = (real32_T)(vabc3_b3 > 0.0F) * vabc3_b3 - (real32_T)
          (vabc3_b3 < 0.0F) * vabc3_b3;

        /* Sum: '<S108>/Sum' incorporates:
         *  Delay: '<S108>/Delay'
         *  Gain: '<S108>/1 - Lambda'
         *  Gain: '<S108>/Lambda'
         */
        rtb_Sum_e = 0.00015384F * rtb_vabc7_l4 + 0.99984616F *
          npc_controller_DWork.Delay_DSTATE_d;

        /* Gain: '<S75>/Gain' incorporates:
         *  DataStoreWrite: '<S75>/Data Store Write3'
         */
        npc_controller_DWork.rms_ic = 1.11F * rtb_Sum_e;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_van = rtb_vabc7_f;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_vbn = rtb_vabc7_p;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_vcn = rtb_vabc7_o;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_ia = rtb_vabc7_i;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_ib = rtb_vabc7_d;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_ic = rtb_vabc7_l4;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_vbulk = npc_controller_B.ADC3;

        /* SignalConversion generated from: '<S9>/adc_rect' */
        cpu2cla_vmid = npc_controller_B.ADC4;

        /* Update for Delay: '<S109>/Delay' */
        npc_controller_DWork.Delay_DSTATE_f = vabc3;

        /* Update for Delay: '<S110>/Delay' */
        npc_controller_DWork.Delay_DSTATE_l = vabc3_b;

        /* Update for Delay: '<S111>/Delay' */
        npc_controller_DWork.Delay_DSTATE_k = vabc3_m;

        /* Update for Delay: '<S103>/Delay' */
        npc_controller_DWork.Delay_DSTATE_j = rtb_Sum;

        /* Update for Delay: '<S104>/Delay' */
        npc_controller_DWork.Delay_DSTATE_lx = rtb_Sum_b;

        /* Update for Delay: '<S105>/Delay' */
        npc_controller_DWork.Delay_DSTATE_mn = rtb_Sum_oi;

        /* Update for Delay: '<S106>/Delay' */
        npc_controller_DWork.Delay_DSTATE_e = rtb_Sum_pz;

        /* Update for Delay: '<S107>/Delay' */
        npc_controller_DWork.Delay_DSTATE_ef = rtb_Sum_l;

        /* Update for Delay: '<S108>/Delay' */
        npc_controller_DWork.Delay_DSTATE_d = rtb_Sum_e;

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/POLARITY'
         */
        /* RelationalOperator: '<S12>/GreaterThan' incorporates:
         *  Constant: '<S12>/Constant'
         */
        cpu2cla_pol_pha = (vabc3_n < 0.0F);

        /* RelationalOperator: '<S12>/GreaterThan1' incorporates:
         *  Constant: '<S12>/Constant1'
         */
        cpu2cla_pol_phb = (vabc3_a < 0.0F);

        /* RelationalOperator: '<S12>/GreaterThan2' incorporates:
         *  Constant: '<S12>/Constant2'
         */
        cpu2cla_pol_phc = (vabc3_d < 0.0F);

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/CONTROL'
         */
        /* If: '<S8>/If' incorporates:
         *  DataStoreRead: '<S8>/Data Store Read'
         */
        if (npc_controller_DWork.u8PriFutEnable == 0U) {
          /* Outputs for IfAction SubSystem: '<S8>/false' incorporates:
           *  ActionPort: '<S14>/Action Port'
           */
          /* S-Function (c2000cla): '<S14>/CLA Task1' */
          Cla1ForceTask1();

          /* End of Outputs for S-Function (c2000cla): '<S14>/CLA Task1' */
          /* End of Outputs for SubSystem: '<S8>/false' */
        }

        /* End of If: '<S8>/If' */

        /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
         *  SubSystem: '<S2>/STATE-MACHINE'
         */
        /* Gain: '<S13>/Gain3' incorporates:
         *  DataStoreRead: '<S13>/Data Store Read5'
         */
        vabc3 = 1.414F * npc_controller_DWork.rms_vb;

        /* Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
         *  Constant: '<S13>/Constant'
         *  Logic: '<S116>/OR'
         */
        /* Gateway: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2 */
        /* During: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2 */
        /* Entry Internal: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2 */
        /* Transition: '<S112>:599' */
        guard1 = false;
        if (npc_controller_DWork.start_cnt > 63333.0) {
          /* Transition: '<S112>:600' */
          /* 50cycles */
          if (npc_controller_B.calib_ok) {
            /* Outputs for Function Call SubSystem: '<S112>/detectUvpOvp' */
            /* Chart: '<S116>/OVP' incorporates:
             *  Constant: '<S13>/Constant'
             */
            /* Transition: '<S112>:417' */
            /* Simulink Function 'detectUvpOvp': '<S112>:799' */
            /* Gateway: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/OVP */
            /* During: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/OVP */
            /* Entry Internal: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/OVP */
            /* Transition: '<S126>:17' */
            if (vabc3 > 244.93333333333334) {
              /* Transition: '<S126>:15' */
              /* Transition: '<S126>:16' */
              npc_controller_B.tfv_v_Ovp = 1.0;

              /* Transition: '<S126>:14' */
            } else if (vabc3 < 219.6) {
              /* Transition: '<S126>:10' */
              /* Transition: '<S126>:11' */
              npc_controller_B.tfv_v_Ovp = 0.0;
            } else {
              /* Transition: '<S126>:8' */
              /* Transition: '<S126>:9' */

              /* Transition: '<S126>:12' */
            }

            /* End of Chart: '<S116>/OVP' */

            /* Chart: '<S116>/UVP' incorporates:
             *  Constant: '<S13>/Constant'
             */
            /* Gateway: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/UVP */
            /* During: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/UVP */
            /* Entry Internal: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/UVP */
            /* Transition: '<S127>:35' */
            if (vabc3 < 134.4) {
              /* Transition: '<S127>:27' */
              /* Transition: '<S127>:25' */
              npc_controller_B.tfv_v_Uvp = 1.0;

              /* Transition: '<S127>:24' */
            } else if (vabc3 > 151.46666666666667) {
              /* Transition: '<S127>:31' */
              /* Transition: '<S127>:30' */
              npc_controller_B.tfv_v_Uvp = 0.0;
            } else {
              /* Transition: '<S127>:21' */
              /* Transition: '<S127>:32' */

              /* Transition: '<S127>:29' */
            }

            /* End of Chart: '<S116>/UVP' */
            npc_controller_B.tfv_v_UvpOvp = ((npc_controller_B.tfv_v_Ovp != 0.0)
              || (npc_controller_B.tfv_v_Uvp != 0.0));

            /* End of Outputs for SubSystem: '<S112>/detectUvpOvp' */

            /* Outputs for Function Call SubSystem: '<S112>/readCmpssOcp' */
            /* Simulink Function 'readCmpssOcp': '<S112>:790' */

            /* user code (Output function Body for TID3) */

            /* System '<S112>/readCmpssOcp' */

            /*read Digital Compare EVT1 Tz Flag*/
            npc_controller_DWork.tz_cmpssocp = EPwm2Regs.TZFLG.bit.DCAEVT1 |
              EPwm2Regs.TZFLG.bit.DCBEVT1 | EPwm7Regs.TZFLG.bit.DCAEVT1 |
              EPwm7Regs.TZFLG.bit.DCBEVT1 | EPwm8Regs.TZFLG.bit.DCAEVT1 |
              EPwm8Regs.TZFLG.bit.DCBEVT1 | EPwm9Regs.TZFLG.bit.DCAEVT1 |
              EPwm9Regs.TZFLG.bit.DCBEVT1| EPwm10Regs.TZFLG.bit.DCAEVT1 |
              EPwm10Regs.TZFLG.bit.DCBEVT1 | EPwm11Regs.TZFLG.bit.DCAEVT1 |
              EPwm11Regs.TZFLG.bit.DCBEVT1;

            /* End of Outputs for SubSystem: '<S112>/readCmpssOcp' */
            /* Transition: '<S112>:532' */
            /* fault latch|| tfv_vtop */
            if (npc_controller_DWork.tfv_va || npc_controller_DWork.tfv_vb ||
                npc_controller_DWork.tfv_vc || npc_controller_DWork.tfv_iphasea ||
                npc_controller_DWork.tfv_iphaseb ||
                npc_controller_DWork.tfv_iphasec ||
                npc_controller_DWork.tfv_vbulk || npc_controller_DWork.tfv_vmid ||
                npc_controller_DWork.tfv_vaux || (npc_controller_DWork.tz_ocp !=
                 0U) || (npc_controller_DWork.tz_ovp != 0U) ||
                (npc_controller_DWork.tz_cmpssocp != 0U) ||
                npc_controller_DWork.fault) {
              /* Transition: '<S112>:4' */
              npc_controller_DWork.fault = true;
              npc_controller_B.state = 1U;

              /* turn OFF */
              /* Transition: '<S112>:420' */
              /* {calib_ok = false;} //calib_ok resets at fault or CAN command */
              /* Transition: '<S112>:763' */
              guard1 = true;

              /* Transition: '<S112>:671' */
              /* Transition: '<S112>:543' */
            } else if ((int16_T)npc_controller_DWork.u8PriFutEnable != 0) {
              /* Transition: '<S112>:502' */
              if (!npc_controller_DWork.fut_en) {
                /* Outputs for Function Call SubSystem: '<S112>/configFutEn' */
                /* Transition: '<S112>:493' */
                /* Transition: '<S112>:499' */
                /* Simulink Function 'configFutEn': '<S112>:496' */

                /* user code (Output function Body for TID3) */

                /* System '<S112>/configFutEn' */
                /*Disable forced PWM*/
                EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);

                /*Input unique %duty*/
                EPwm2Regs.CMPA.bit.CMPA = (uint16_T)(461.4F);//S1
                EPwm7Regs.CMPB.bit.CMPB = (uint16_T)(461.4F);//S2
                EPwm2Regs.CMPB.bit.CMPB = (uint16_T)(461.4F);//S3
                EPwm7Regs.CMPA.bit.CMPA = (uint16_T)(461.4F);//S4
                EPwm8Regs.CMPB.bit.CMPB = (uint16_T)(922.8F);//S1
                EPwm9Regs.CMPB.bit.CMPB = (uint16_T)(922.8F);//S2
                EPwm8Regs.CMPA.bit.CMPA = (uint16_T)(922.8F);//S3
                EPwm9Regs.CMPA.bit.CMPA = (uint16_T)(922.8F);//S4
                EPwm10Regs.CMPB.bit.CMPB = (uint16_T)(1384.2F);//S1
                EPwm11Regs.CMPB.bit.CMPB = (uint16_T)(1384.2F);//S2
                EPwm10Regs.CMPA.bit.CMPA = (uint16_T)(1384.2F);//S3
                EPwm11Regs.CMPA.bit.CMPA = (uint16_T)(1384.2F);//S4

                /* End of Outputs for SubSystem: '<S112>/configFutEn' */
                npc_controller_DWork.fut_en = true;
              } else {
                /* Transition: '<S112>:495' */
                /* Transition: '<S112>:503' */
              }

              /* Transition: '<S112>:517' */
              npc_controller_B.state = 2U;

              /* Transition: '<S112>:732' */
              /* Transition: '<S112>:782' */
              /* Transition: '<S112>:708' */
              /* Transition: '<S112>:667' */
              /* Transition: '<S112>:718' */
              /* Transition: '<S112>:761' */
              /* Transition: '<S112>:535' */
            } else {
              /* Transition: '<S112>:719' */
              if (npc_controller_DWork.fut_en) {
                /* Outputs for Function Call SubSystem: '<S112>/configFutDis' */
                /* Transition: '<S112>:507' */
                /* Transition: '<S112>:509' */
                /* Simulink Function 'configFutDis': '<S112>:497' */

                /* user code (Output function Body for TID3) */

                /* System '<S112>/configFutDis' */
                /*Force PWM to LOW*/
                EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

                /* End of Outputs for SubSystem: '<S112>/configFutDis' */
                npc_controller_DWork.fut_en = false;

                /* Transition: '<S112>:518' */
              } else {
                /* Transition: '<S112>:513' */
              }

              /* Transition: '<S112>:741' */
              if ((!npc_controller_B.tfv_v_UvpOvp) &&
                  (!(npc_controller_DWork.otp_fault != 0.0F))) {
                /* Transition: '<S112>:730' */
                /* check ac_ok at start */
                if (!npc_controller_DWork.pfc_en) {
                  /* Transition: '<S112>:715' */
                  npc_controller_B.state = 6U;

                  /* turn OFF
                     relay OFF */
                  /* Transition: '<S112>:717' */
                  guard1 = true;

                  /* Transition: '<S112>:723' */
                } else if (npc_controller_DWork.delay_cnt > 2666.0) {
                  /* Transition: '<S112>:779' */
                  if (!npc_controller_B.control_en) {
                    /* Transition: '<S112>:677' */
                    if (3.9594 * vabc3 - npc_controller_B.ADC3 < 50.0) {
                      /* Transition: '<S112>:344' */
                      /* Transition: '<S112>:660' */
                      npc_controller_B.relay_ctrl = true;

                      /* pre-charge relay ON */
                    } else {
                      /* Transition: '<S112>:566' */
                      /* Transition: '<S112>:663' */
                    }

                    /* Transition: '<S112>:682' */
                  } else {
                    /* Transition: '<S112>:680' */
                    /* Transition: '<S112>:681' */
                  }

                  if (npc_controller_B.relay_ctrl) {
                    /* Transition: '<S112>:661' */
                    if (npc_controller_DWork.relay_cnt > 3300.0) {
                      /* Transition: '<S112>:617' */
                      /* PWM ON with 40ms delay */
                      if (!npc_controller_B.control_en) {
                        /* Transition: '<S112>:618' */
                        if (npc_controller_B.ADC3 > 753.866638F) {
                          /* Transition: '<S112>:688' */
                          /* 170//341//640V */
                          /* Transition: '<S112>:704' */
                          npc_controller_B.control_en = true;

                          /* PWM ON */
                          cpu2cla_ref = npc_controller_B.ADC3;

                          /* enDigCmpMode();
                             enCmpssTz(); */

                          /* Transition: '<S112>:697' */
                        } else if (npc_controller_B.ADC3 < 565.333313F) {
                          /* Transition: '<S112>:687' */
                          /* 128V//256V//480V */
                          /* Transition: '<S112>:694' */
                          npc_controller_B.control_en = false;
                        } else {
                          /* Transition: '<S112>:690' */
                          /* Transition: '<S112>:700' */

                          /* Transition: '<S112>:705' */
                        }

                        /* Transition: '<S112>:703' */
                      } else {
                        /* Transition: '<S112>:755' */
                        /* Transition: '<S112>:756' */
                      }

                      if (npc_controller_B.control_en) {
                        /* Transition: '<S112>:115' */
                        if (npc_controller_B.ADC3 > 989.6F) {
                          /* Transition: '<S112>:120' */
                          /* 224V//448V//840V */
                          /* Transition: '<S112>:274' */
                          npc_controller_B.eoss = false;
                          npc_controller_B.burst_en = true;

                          /* Transition: '<S112>:255' */
                        } else if (npc_controller_B.ADC3 < 928.0F) {
                          /* Transition: '<S112>:265' */
                          /* 210V//420V//787V */
                          /* Transition: '<S112>:272' */
                          npc_controller_B.burst_en = false;
                        } else {
                          /* Transition: '<S112>:268' */
                          /* Transition: '<S112>:271' */

                          /* Transition: '<S112>:275' */
                        }

                        if (npc_controller_B.burst_en) {
                          /* Outputs for Function Call SubSystem: '<S112>/disablePwm' */
                          /* Transition: '<S112>:277' */
                          /* Transition: '<S112>:279' */
                          /* Simulink Function 'disablePwm': '<S112>:24' */

                          /* user code (Output function Body for TID3) */

                          /* System '<S112>/disablePwm' */
                          /*Force PWM to LOW*/
                          EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                          EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                          EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

                          /* End of Outputs for SubSystem: '<S112>/disablePwm' */
                          /* forced zero */
                          cpu2cla_pha_en = false;
                          cpu2cla_phb_en = false;
                          cpu2cla_phc_en = false;
                          npc_controller_B.state = 5U;

                          /* Transition: '<S112>:534' */
                        } else {
                          /* Transition: '<S112>:280' */
                          if (npc_controller_B.eoss) {
                            /* Transition: '<S112>:257' */
                            /* {tfv_v_UvpOvp = detectUvpOvp(Vpk, V_select)} */
                            if (npc_controller_DWork.eoss_cnt > 6667.0) {
                              /* Transition: '<S112>:649' */
                              /* 5cycles delay after SS for PFC_OK */
                              /* Transition: '<S112>:652' */
                              cpu2cla_pfc_ok2 = true;

                              /* eoss_cnt = 13100; */
                            } else {
                              /* Transition: '<S112>:653' */
                              npc_controller_DWork.eoss_cnt++;
                              cpu2cla_pfc_ok2 = false;

                              /* Transition: '<S112>:650' */
                            }

                            /* Transition: '<S112>:259' */
                          } else if (cpu2cla_ref < 883.733337F) {
                            /* Transition: '<S112>:91' */
                            /* (single(222//444//883)-vbulk) > single(50)] //11V ripple */
                            /* Transition: '<S112>:107' */
                            cpu2cla_ref = cpu2cla_ref + 0.00266666664F;
                            npc_controller_B.eoss = false;
                          } else {
                            /* Transition: '<S112>:90' */
                            /* Transition: '<S112>:104' */
                            cpu2cla_ref = 883.733337F;

                            /* 200V//400V//750V */
                            npc_controller_B.eoss = true;

                            /* Transition: '<S112>:88' */
                            /* Transition: '<S112>:99' */

                            /* Transition: '<S112>:87' */
                            /* Transition: '<S112>:650' */
                          }

                          if (cpu2cla_pha_en) {
                            /* Outputs for Function Call SubSystem: '<S112>/updateSequencePhA_burst' */
                            /* S-Function (fcgen): '<S123>/Function-Call Generator' incorporates:
                             *  SubSystem: '<S123>/pol_vxn1'
                             */
                            /* If: '<S150>/If1' incorporates:
                             *  Constant: '<S156>/Constant1'
                             *  Constant: '<S157>/Constant'
                             *  Constant: '<S158>/Constant'
                             *  RelationalOperator: '<S158>/Compare'
                             */
                            /* Transition: '<S112>:353' */
                            /* Transition: '<S112>:355' */
                            /* Simulink Function 'updateSequencePhA_burst': '<S112>:817' */
                            if ((vabc3_n > -16.0F) && (vabc3_n < 16.0F)) {
                              /* Outputs for IfAction SubSystem: '<S150>/true' incorporates:
                               *  ActionPort: '<S157>/Action Port'
                               */
                              tmp = 1;

                              /* End of Outputs for SubSystem: '<S150>/true' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S150>/false' incorporates:
                               *  ActionPort: '<S156>/Action Port'
                               */
                              tmp = -1;

                              /* End of Outputs for SubSystem: '<S150>/false' */
                            }

                            Constant1 = (tmp > 0);

                            /* End of If: '<S150>/If1' */

                            /* Chart: '<S145>/Chart2' incorporates:
                             *  Constant: '<S145>/2A'
                             *  DataTypeConversion: '<S150>/Data Type Conversion'
                             *  RelationalOperator: '<S155>/FixPt Relational Operator'
                             *  UnitDelay: '<S155>/Delay Input1'
                             */
                            npc_controller_Chart2(cla2cpu_Ipk, (real32_T)
                                                  ((int16_T)Constant1 > (int16_T)
                              npc_controller_DWork.DelayInput1_DSTATE_a), 12.5F,
                                                  &npc_controller_B.sf_Chart2,
                                                  &npc_controller_DWork.sf_Chart2);

                            /* If: '<S145>/If2' incorporates:
                             *  If: '<S147>/If'
                             */
                            if (((vabc3_n > -48.0F) && (vabc3_n < 48.0F)) ||
                                (npc_controller_B.sf_Chart2.PWM_burst_en < 0.5F))
                            {
                              /* Outputs for IfAction SubSystem: '<S145>/zero' incorporates:
                               *  ActionPort: '<S149>/Action Port'
                               */

                              /* user code (Output function Body for TID3) */

                              /* System '<S145>/zero' */
                              /*Force PWM to LOW*/
                              EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                              EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S145>/zero' */
                            } else if (vabc3_n >= 48.0F) {
                              /* Outputs for IfAction SubSystem: '<S145>/pos' incorporates:
                               *  ActionPort: '<S148>/Action Port'
                               */
                              /* If: '<S148>/If' */
                              if ((vabc3_aq > -48.0F) && (vabc3_aq < 48.0F)) {
                                /* Outputs for IfAction SubSystem: '<S148>/SR Force to Low' incorporates:
                                 *  ActionPort: '<S153>/Action Port'
                                 */

                                /* user code (Output function Body for TID3) */

                                /* System '<S148>/SR Force to Low' */
                                EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                                EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                                EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                                EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                                /* End of Outputs for SubSystem: '<S148>/SR Force to Low' */
                              } else {
                                /* Outputs for IfAction SubSystem: '<S148>/SR ON' incorporates:
                                 *  ActionPort: '<S154>/Action Port'
                                 */

                                /* user code (Output function Body for TID3) */

                                /* System '<S148>/SR ON' */
                                EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                                EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                                EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                                EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                                /* End of Outputs for SubSystem: '<S148>/SR ON' */
                              }

                              /* End of If: '<S148>/If' */
                              /* End of Outputs for SubSystem: '<S145>/pos' */

                              /* Outputs for IfAction SubSystem: '<S145>/neg' incorporates:
                               *  ActionPort: '<S147>/Action Port'
                               */
                            } else if ((vabc3_aq > -48.0F) && (vabc3_aq < 48.0F))
                            {
                              /* Outputs for IfAction SubSystem: '<S147>/SR OFF' incorporates:
                               *  ActionPort: '<S151>/Action Port'
                               */
                              /* If: '<S147>/If' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S147>/SR OFF' */
                              EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                              EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                              EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S147>/SR OFF' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S147>/SR ON' incorporates:
                               *  ActionPort: '<S152>/Action Port'
                               */
                              /* If: '<S147>/If' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S147>/SR ON' */
                              EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                              EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                              EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);

                              /* End of Outputs for SubSystem: '<S147>/SR ON' */

                              /* End of Outputs for SubSystem: '<S145>/neg' */
                            }

                            /* End of If: '<S145>/If2' */

                            /* Update for UnitDelay: '<S155>/Delay Input1' */
                            npc_controller_DWork.DelayInput1_DSTATE_a =
                              Constant1;

                            /* End of Outputs for S-Function (fcgen): '<S123>/Function-Call Generator' */
                            /* End of Outputs for SubSystem: '<S112>/updateSequencePhA_burst' */
                          } else {
                            /* Outputs for Function Call SubSystem: '<S112>/detectZCPhA' */
                            /* Transition: '<S112>:357' */
                            /* Simulink Function 'detectZCPhA': '<S112>:459' */
                            npc_controller_detectZCPhA((real_T)vabc3_n,
                              &npc_controller_B.detectZCPhA);

                            /* End of Outputs for SubSystem: '<S112>/detectZCPhA' */
                            cpu2cla_pha_en = npc_controller_B.detectZCPhA.Merge1;

                            /* Transition: '<S112>:358' */
                          }

                          if (cpu2cla_phb_en) {
                            /* Outputs for Function Call SubSystem: '<S112>/updateSequencePhB_burst' */
                            /* S-Function (fcgen): '<S124>/Function-Call Generator' incorporates:
                             *  SubSystem: '<S124>/pol_vxn1'
                             */
                            /* If: '<S164>/If1' incorporates:
                             *  Constant: '<S170>/Constant1'
                             *  Constant: '<S171>/Constant'
                             *  Constant: '<S172>/Constant'
                             *  RelationalOperator: '<S172>/Compare'
                             */
                            /* Transition: '<S112>:361' */
                            /* Transition: '<S112>:364' */
                            /* Simulink Function 'updateSequencePhB_burst': '<S112>:843' */
                            if ((vabc3_a > -16.0F) && (vabc3_a < 16.0F)) {
                              /* Outputs for IfAction SubSystem: '<S164>/true' incorporates:
                               *  ActionPort: '<S171>/Action Port'
                               */
                              tmp = 1;

                              /* End of Outputs for SubSystem: '<S164>/true' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S164>/false' incorporates:
                               *  ActionPort: '<S170>/Action Port'
                               */
                              tmp = -1;

                              /* End of Outputs for SubSystem: '<S164>/false' */
                            }

                            Constant1 = (tmp > 0);

                            /* End of If: '<S164>/If1' */

                            /* Chart: '<S159>/Chart2' incorporates:
                             *  Constant: '<S159>/2A'
                             *  DataTypeConversion: '<S164>/Data Type Conversion'
                             *  RelationalOperator: '<S169>/FixPt Relational Operator'
                             *  UnitDelay: '<S169>/Delay Input1'
                             */
                            npc_controller_Chart2(cla2cpu_Ipk, (real32_T)
                                                  ((int16_T)Constant1 > (int16_T)
                              npc_controller_DWork.DelayInput1_DSTATE_j), 12.5F,
                                                  &npc_controller_B.sf_Chart2_g,
                                                  &npc_controller_DWork.sf_Chart2_g);

                            /* If: '<S159>/If3' incorporates:
                             *  If: '<S161>/If'
                             */
                            if (((vabc3_a > -48.0F) && (vabc3_a < 48.0F)) ||
                                (npc_controller_B.sf_Chart2_g.PWM_burst_en <
                                 0.5F)) {
                              /* Outputs for IfAction SubSystem: '<S159>/zero' incorporates:
                               *  ActionPort: '<S163>/Action Port'
                               */

                              /* user code (Output function Body for TID3) */

                              /* System '<S159>/zero' */
                              /*Force PWM to LOW*/
                              EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                              EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S159>/zero' */
                            } else if (vabc3_a >= 48.0F) {
                              /* Outputs for IfAction SubSystem: '<S159>/pos' incorporates:
                               *  ActionPort: '<S162>/Action Port'
                               */
                              /* If: '<S162>/If' */
                              if ((vabc3_e > -48.0F) && (vabc3_e < 48.0F)) {
                                /* Outputs for IfAction SubSystem: '<S162>/SR Force to Low' incorporates:
                                 *  ActionPort: '<S167>/Action Port'
                                 */

                                /* user code (Output function Body for TID3) */

                                /* System '<S162>/SR Force to Low' */
                                EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                                EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                                EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                                EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                                /* End of Outputs for SubSystem: '<S162>/SR Force to Low' */
                              } else {
                                /* Outputs for IfAction SubSystem: '<S162>/SR ON' incorporates:
                                 *  ActionPort: '<S168>/Action Port'
                                 */

                                /* user code (Output function Body for TID3) */

                                /* System '<S162>/SR ON' */
                                EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                                EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                                EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                                EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                                /* End of Outputs for SubSystem: '<S162>/SR ON' */
                              }

                              /* End of If: '<S162>/If' */
                              /* End of Outputs for SubSystem: '<S159>/pos' */

                              /* Outputs for IfAction SubSystem: '<S159>/neg' incorporates:
                               *  ActionPort: '<S161>/Action Port'
                               */
                            } else if ((vabc3_e > -48.0F) && (vabc3_e < 48.0F))
                            {
                              /* Outputs for IfAction SubSystem: '<S161>/SR OFF' incorporates:
                               *  ActionPort: '<S165>/Action Port'
                               */
                              /* If: '<S161>/If' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S161>/SR OFF' */
                              EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b10);
                              EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S161>/SR OFF' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S161>/SR ON' incorporates:
                               *  ActionPort: '<S166>/Action Port'
                               */
                              /* If: '<S161>/If' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S161>/SR ON' */
                              EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b10);
                              EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);

                              /* End of Outputs for SubSystem: '<S161>/SR ON' */

                              /* End of Outputs for SubSystem: '<S159>/neg' */
                            }

                            /* End of If: '<S159>/If3' */

                            /* Update for UnitDelay: '<S169>/Delay Input1' */
                            npc_controller_DWork.DelayInput1_DSTATE_j =
                              Constant1;

                            /* End of Outputs for S-Function (fcgen): '<S124>/Function-Call Generator' */
                            /* End of Outputs for SubSystem: '<S112>/updateSequencePhB_burst' */
                          } else {
                            /* Outputs for Function Call SubSystem: '<S112>/detectZCPhB' */
                            /* Transition: '<S112>:363' */
                            /* Simulink Function 'detectZCPhB': '<S112>:392' */
                            npc_controller_detectZCPhA((real_T)vabc3_a,
                              &npc_controller_B.detectZCPhB);

                            /* End of Outputs for SubSystem: '<S112>/detectZCPhB' */
                            cpu2cla_phb_en = npc_controller_B.detectZCPhB.Merge1;

                            /* Transition: '<S112>:360' */
                          }

                          if (cpu2cla_phc_en) {
                            /* Outputs for Function Call SubSystem: '<S112>/updateSequencePhC_burst' */
                            /* S-Function (fcgen): '<S125>/Function-Call Generator' incorporates:
                             *  SubSystem: '<S125>/pol_vxn1'
                             */
                            /* If: '<S178>/If1' incorporates:
                             *  Constant: '<S184>/Constant1'
                             *  Constant: '<S185>/Constant'
                             *  Constant: '<S186>/Constant'
                             *  RelationalOperator: '<S186>/Compare'
                             */
                            /* Transition: '<S112>:373' */
                            /* Transition: '<S112>:369' */
                            /* Simulink Function 'updateSequencePhC_burst': '<S112>:848' */
                            if ((vabc3_d > -16.0F) && (vabc3_d < 16.0F)) {
                              /* Outputs for IfAction SubSystem: '<S178>/true' incorporates:
                               *  ActionPort: '<S185>/Action Port'
                               */
                              tmp = 1;

                              /* End of Outputs for SubSystem: '<S178>/true' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S178>/false' incorporates:
                               *  ActionPort: '<S184>/Action Port'
                               */
                              tmp = -1;

                              /* End of Outputs for SubSystem: '<S178>/false' */
                            }

                            Constant1 = (tmp > 0);

                            /* End of If: '<S178>/If1' */

                            /* Chart: '<S173>/Chart2' incorporates:
                             *  Constant: '<S173>/2A'
                             *  DataTypeConversion: '<S178>/Data Type Conversion'
                             *  RelationalOperator: '<S183>/FixPt Relational Operator'
                             *  UnitDelay: '<S183>/Delay Input1'
                             */
                            npc_controller_Chart2(cla2cpu_Ipk, (real32_T)
                                                  ((int16_T)Constant1 > (int16_T)
                              npc_controller_DWork.DelayInput1_DSTATE), 12.5F,
                                                  &npc_controller_B.sf_Chart2_p,
                                                  &npc_controller_DWork.sf_Chart2_p);

                            /* If: '<S173>/If3' incorporates:
                             *  If: '<S175>/If'
                             */
                            if (((vabc3_d > -48.0F) && (vabc3_d < 48.0F)) ||
                                (npc_controller_B.sf_Chart2_p.PWM_burst_en <
                                 0.5F)) {
                              /* Outputs for IfAction SubSystem: '<S173>/zero' incorporates:
                               *  ActionPort: '<S177>/Action Port'
                               */

                              /* user code (Output function Body for TID3) */

                              /* System '<S173>/zero' */
                              /*Force PWM to LOW*/
                              EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S173>/zero' */
                            } else if (vabc3_d >= 48.0F) {
                              /* Outputs for IfAction SubSystem: '<S173>/pos' incorporates:
                               *  ActionPort: '<S176>/Action Port'
                               */
                              /* If: '<S176>/If' */
                              if ((vabc3_b3 > -48.0F) && (vabc3_b3 < 48.0F)) {
                                /* Outputs for IfAction SubSystem: '<S176>/SR Force to Low' incorporates:
                                 *  ActionPort: '<S181>/Action Port'
                                 */

                                /* user code (Output function Body for TID3) */

                                /* System '<S176>/SR Force to Low' */
                                EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                                EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                                EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                                EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                                /* End of Outputs for SubSystem: '<S176>/SR Force to Low' */
                              } else {
                                /* Outputs for IfAction SubSystem: '<S176>/SR ON' incorporates:
                                 *  ActionPort: '<S182>/Action Port'
                                 */

                                /* user code (Output function Body for TID3) */

                                /* System '<S176>/SR ON' */
                                EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                                EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b10);
                                EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);
                                EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                                /* End of Outputs for SubSystem: '<S176>/SR ON' */
                              }

                              /* End of If: '<S176>/If' */
                              /* End of Outputs for SubSystem: '<S173>/pos' */

                              /* Outputs for IfAction SubSystem: '<S173>/neg' incorporates:
                               *  ActionPort: '<S175>/Action Port'
                               */
                            } else if ((vabc3_b3 > -48.0F) && (vabc3_b3 < 48.0F))
                            {
                              /* Outputs for IfAction SubSystem: '<S175>/SR OFF' incorporates:
                               *  ActionPort: '<S179>/Action Port'
                               */
                              /* If: '<S175>/If' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S175>/SR OFF' */
                              EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b10);
                              EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);

                              /* End of Outputs for SubSystem: '<S175>/SR OFF' */
                            } else {
                              /* Outputs for IfAction SubSystem: '<S175>/SR ON' incorporates:
                               *  ActionPort: '<S180>/Action Port'
                               */
                              /* If: '<S175>/If' */

                              /* user code (Output function Body for TID3) */

                              /* System '<S175>/SR ON' */
                              EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
                              EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b00);
                              EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b10);
                              EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b00);

                              /* End of Outputs for SubSystem: '<S175>/SR ON' */

                              /* End of Outputs for SubSystem: '<S173>/neg' */
                            }

                            /* End of If: '<S173>/If3' */

                            /* Update for UnitDelay: '<S183>/Delay Input1' */
                            npc_controller_DWork.DelayInput1_DSTATE = Constant1;

                            /* End of Outputs for S-Function (fcgen): '<S125>/Function-Call Generator' */
                            /* End of Outputs for SubSystem: '<S112>/updateSequencePhC_burst' */
                          } else {
                            /* Outputs for Function Call SubSystem: '<S112>/detectZCPhC' */
                            /* Transition: '<S112>:371' */
                            /* Simulink Function 'detectZCPhC': '<S112>:462' */
                            npc_controller_detectZCPhA((real_T)vabc3_d,
                              &npc_controller_B.detectZCPhC);

                            /* End of Outputs for SubSystem: '<S112>/detectZCPhC' */
                            cpu2cla_phc_en = npc_controller_B.detectZCPhC.Merge1;

                            /* Transition: '<S112>:368' */
                          }

                          /* Transition: '<S112>:374' */
                          npc_controller_B.state = 4U;

                          /* Transition: '<S112>:328' */
                          /* Transition: '<S112>:534' */
                        }
                      } else {
                        /* Transition: '<S112>:666' */
                        /* exit */
                        /* Transition: '<S112>:761' */
                        /* Transition: '<S112>:535' */
                      }
                    } else {
                      /* Transition: '<S112>:619' */
                      npc_controller_DWork.relay_cnt++;

                      /* exit */
                      /* Transition: '<S112>:718' */
                      /* Transition: '<S112>:761' */
                      /* Transition: '<S112>:535' */
                    }
                  } else {
                    /* Transition: '<S112>:709' */
                    /* exit */
                    /* Transition: '<S112>:667' */
                    /* Transition: '<S112>:718' */
                    /* Transition: '<S112>:761' */
                    /* Transition: '<S112>:535' */
                  }
                } else {
                  /* Transition: '<S112>:781' */
                  npc_controller_DWork.delay_cnt++;

                  /* exit */
                  /* Transition: '<S112>:708' */
                  /* Transition: '<S112>:667' */
                  /* Transition: '<S112>:718' */
                  /* Transition: '<S112>:761' */
                  /* Transition: '<S112>:535' */
                }
              } else {
                /* Transition: '<S112>:746' */
                /* Transition: '<S112>:729' */
                npc_controller_B.state = 7U;

                /* turn OFF */
                /* Transition: '<S112>:763' */
                guard1 = true;
              }
            }
          } else {
            /* Outputs for Function Call SubSystem: '<S112>/updateCalib' */
            /* If: '<S122>/If' incorporates:
             *  Constant: '<S142>/Constant1'
             */
            /* Transition: '<S112>:438' */
            /* Simulink Function 'updateCalib': '<S112>:408' */
            if (npc_controller_DWork.cnt_calib > 65000U) {
              /* Outputs for IfAction SubSystem: '<S122>/done' incorporates:
               *  ActionPort: '<S135>/Action Port'
               */
              /* S-Function (fcgen): '<S135>/Function-Call Generator' incorporates:
               *  SubSystem: '<S135>/AUTO-CALIB_DONE'
               */
              /* DataStoreWrite: '<S142>/Data Store Write2' incorporates:
               *  Constant: '<S142>/Constant2'
               */
              npc_controller_DWork.cnt_calib = 1U;

              /* DataStoreWrite: '<S142>/Data Store Write' incorporates:
               *  DataStoreRead: '<S142>/Data Store Read'
               */
              npc_controller_DWork.adc_offset_ib =
                npc_controller_DWork.adc_offset_ib_tmp;

              /* DataStoreWrite: '<S142>/Data Store Write1' incorporates:
               *  DataStoreRead: '<S142>/Data Store Read1'
               */
              npc_controller_DWork.adc_offset_ic =
                npc_controller_DWork.adc_offset_ic_tmp;

              /* DataStoreWrite: '<S142>/Data Store Write3' incorporates:
               *  DataStoreRead: '<S142>/Data Store Read2'
               */
              npc_controller_DWork.adc_offset_va =
                npc_controller_DWork.adc_offset_va_tmp;

              /* DataStoreWrite: '<S142>/Data Store Write4' incorporates:
               *  DataStoreRead: '<S142>/Data Store Read3'
               */
              npc_controller_DWork.adc_offset_vb =
                npc_controller_DWork.adc_offset_vb_tmp;

              /* DataStoreWrite: '<S142>/Data Store Write5' incorporates:
               *  DataStoreRead: '<S142>/Data Store Read4'
               */
              npc_controller_DWork.adc_offset_vc =
                npc_controller_DWork.adc_offset_vc_tmp;

              /* DataStoreWrite: '<S142>/Data Store Write6' incorporates:
               *  DataStoreRead: '<S142>/Data Store Read5'
               */
              npc_controller_DWork.adc_offset_ia =
                npc_controller_DWork.adc_offset_ia_tmp;
              Constant1 = true;

              /* S-Function (fcgen): '<S135>/Function-Call Generator' incorporates:
               *  SubSystem: '<S135>/RESET_TZ'
               */

              /* user code (Output function Body for TID3) */

              /* System '<S135>/RESET_TZ' */

              //npc_controller_DWork.tz_ocp = 0b0;
              EALLOW;

              /*Disabled tripzone action*/
              EPwm2Regs.TZCTL.bit.TZA = (uint16_T)(0b11);//do nothing
              EPwm2Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm7Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm7Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm8Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm8Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm9Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm9Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm10Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm10Regs.TZCTL.bit.TZB = (uint16_T)(0b11);
              EPwm11Regs.TZCTL.bit.TZA = (uint16_T)(0b11);
              EPwm11Regs.TZCTL.bit.TZB = (uint16_T)(0b11);

              /*Disabled Digital Compare Out A and Out B Event1*/
              //EPwm2Regs.TZCTL.bit.DCAEVT1 = 0b11; //do nothing
              //EPwm2Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm7Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm7Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm8Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm8Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm9Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm9Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm10Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm10Regs.TZCTL.bit.DCBEVT1 = 0b11;
              //EPwm11Regs.TZCTL.bit.DCAEVT1 = 0b11;
              //EPwm11Regs.TZCTL.bit.DCBEVT1 = 0b11;
              /*Disabled Digital Compare Out A and Out B Event1 */
              EPwm2Regs.TZSEL.bit.DCAEVT1 = 0b0;//disable DCAEVT1 for the ePWM module
              EPwm2Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm7Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm7Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm8Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm8Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm9Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm9Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm10Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm10Regs.TZSEL.bit.DCBEVT1 = 0b0;
              EPwm11Regs.TZSEL.bit.DCAEVT1 = 0b0;
              EPwm11Regs.TZSEL.bit.DCBEVT1 = 0b0;

              /*Clear grouped OST TZ flags*/
              EPwm2Regs.TZCLR.bit.OST = 0b1;//clear trip
              EPwm7Regs.TZCLR.bit.OST = 0b1;
              EPwm8Regs.TZCLR.bit.OST = 0b1;
              EPwm9Regs.TZCLR.bit.OST = 0b1;
              EPwm10Regs.TZCLR.bit.OST = 0b1;
              EPwm11Regs.TZCLR.bit.OST = 0b1;

              /*Clear Digital Compare Out A and B Event1 flags */
              EPwm2Regs.TZCLR.bit.DCAEVT1 = 0b1;//clear trip
              EPwm2Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm7Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm7Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm8Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm8Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm9Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm9Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm10Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm10Regs.TZCLR.bit.DCBEVT1 = 0b1;
              EPwm11Regs.TZCLR.bit.DCAEVT1 = 0b1;
              EPwm11Regs.TZCLR.bit.DCBEVT1 = 0b1;

              /*Enabled Digital Compare Out A and Out B Event1 */
              EPwm2Regs.TZSEL.bit.DCAEVT1 = 0b1;//enabled DCAEVT1 for the ePWM module
              EPwm2Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm7Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm7Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm8Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm8Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm9Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm9Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm10Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm10Regs.TZSEL.bit.DCBEVT1 = 0b1;
              EPwm11Regs.TZSEL.bit.DCAEVT1 = 0b1;
              EPwm11Regs.TZSEL.bit.DCBEVT1 = 0b1;

              /*Clear individual OST TZ flags*/
              EPwm2Regs.TZOSTCLR.bit.OST1 = 0b1;//clear trip
              EPwm2Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm7Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm7Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm8Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm8Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm9Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm9Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm10Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm10Regs.TZOSTCLR.bit.OST2 = 0b1;
              EPwm11Regs.TZOSTCLR.bit.OST1 = 0b1;
              EPwm11Regs.TZOSTCLR.bit.OST2 = 0b1;

              /*Enable tripzone action*/
              EPwm2Regs.TZCTL.bit.TZA = (uint16_T)(0b10);//force to LOW
              EPwm2Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm7Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm7Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm8Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm8Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm9Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm9Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm10Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm10Regs.TZCTL.bit.TZB = (uint16_T)(0b10);
              EPwm11Regs.TZCTL.bit.TZA = (uint16_T)(0b10);
              EPwm11Regs.TZCTL.bit.TZB = (uint16_T)(0b10);

              /*Enabled Digital Compare Out A and Out B Event1*/
              //EPwm2Regs.TZCTL.bit.DCAEVT1 = 0b10; //force to LOW
              //EPwm2Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm7Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm7Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm8Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm8Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm9Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm9Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm10Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm10Regs.TZCTL.bit.DCBEVT1 = 0b10;
              //EPwm11Regs.TZCTL.bit.DCAEVT1 = 0b10;
              //EPwm11Regs.TZCTL.bit.DCBEVT1 = 0b10;
              EDIS;

              /* S-Function (fcgen): '<S135>/Function-Call Generator' incorporates:
               *  SubSystem: '<S135>/CLEAR_FAULTS'
               */
              /* DataStoreWrite: '<S143>/Data Store Write1' incorporates:
               *  Constant: '<S142>/Constant1'
               *  Constant: '<S143>/Constant1'
               */
              npc_controller_DWork.tz_cmpssocp = 0U;

              /* DataStoreWrite: '<S143>/Data Store Write7' incorporates:
               *  Constant: '<S143>/Constant3'
               */
              npc_controller_DWork.tfv_iphasea = false;

              /* DataStoreWrite: '<S143>/Data Store Write8' incorporates:
               *  Constant: '<S143>/Constant4'
               */
              npc_controller_DWork.tfv_iphaseb = false;

              /* DataStoreWrite: '<S143>/Data Store Write9' incorporates:
               *  Constant: '<S143>/Constant5'
               */
              npc_controller_DWork.tfv_iphasec = false;

              /* DataStoreWrite: '<S143>/Data Store Write10' incorporates:
               *  Constant: '<S143>/Constant6'
               */
              npc_controller_DWork.tz_ocp = 0U;

              /* DataStoreWrite: '<S143>/Data Store Write11' incorporates:
               *  Constant: '<S143>/Constant7'
               */
              npc_controller_DWork.tz_ovp = 0U;

              /* End of Outputs for S-Function (fcgen): '<S135>/Function-Call Generator' */
              /* End of Outputs for SubSystem: '<S122>/done' */
            } else {
              /* Outputs for IfAction SubSystem: '<S122>/cnt' incorporates:
               *  ActionPort: '<S134>/Action Port'
               */
              /* Sum: '<S134>/Add' incorporates:
               *  Constant: '<S134>/Constant'
               *  DataStoreWrite: '<S134>/Data Store Write2'
               */
              npc_controller_DWork.cnt_calib++;

              /* Sum: '<S141>/Add4' incorporates:
               *  Constant: '<S141>/Constant4'
               *  DataStoreRead: '<S141>/Data Store Read4'
               *  DataStoreWrite: '<S134>/Data Store Write5'
               *  DataTypeConversion: '<S141>/Cast To Single'
               *  Delay: '<S141>/Delay2'
               *  Product: '<S141>/Divide3'
               *  Product: '<S141>/Divide4'
               *  Sum: '<S141>/Subtract1'
               */
              npc_controller_DWork.adc_offset_va_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE / (real32_T)
                npc_controller_DWork.cnt_calib + vabc3_n / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S140>/Add4' incorporates:
               *  Constant: '<S140>/Constant4'
               *  DataStoreRead: '<S140>/Data Store Read4'
               *  DataStoreWrite: '<S134>/Data Store Write6'
               *  DataTypeConversion: '<S140>/Cast To Single'
               *  Delay: '<S140>/Delay2'
               *  Product: '<S140>/Divide3'
               *  Product: '<S140>/Divide4'
               *  Sum: '<S140>/Subtract1'
               */
              npc_controller_DWork.adc_offset_vb_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_l / (real32_T)
                npc_controller_DWork.cnt_calib + vabc3_a / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S139>/Add4' incorporates:
               *  Constant: '<S139>/Constant4'
               *  DataStoreRead: '<S139>/Data Store Read4'
               *  DataStoreWrite: '<S134>/Data Store Write3'
               *  DataTypeConversion: '<S139>/Cast To Single'
               *  Delay: '<S139>/Delay2'
               *  Product: '<S139>/Divide3'
               *  Product: '<S139>/Divide4'
               *  Sum: '<S139>/Subtract1'
               */
              npc_controller_DWork.adc_offset_vc_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_i / (real32_T)
                npc_controller_DWork.cnt_calib + vabc3_d / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S138>/Add4' incorporates:
               *  Constant: '<S138>/Constant4'
               *  DataStoreRead: '<S138>/Data Store Read4'
               *  DataStoreWrite: '<S134>/Data Store Write4'
               *  DataTypeConversion: '<S138>/Cast To Single'
               *  Delay: '<S138>/Delay2'
               *  Product: '<S138>/Divide3'
               *  Product: '<S138>/Divide4'
               *  Sum: '<S138>/Subtract1'
               */
              npc_controller_DWork.adc_offset_ia_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_m / (real32_T)
                npc_controller_DWork.cnt_calib + vabc3_aq / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S137>/Add4' incorporates:
               *  Constant: '<S137>/Constant4'
               *  DataStoreRead: '<S137>/Data Store Read4'
               *  DataStoreWrite: '<S134>/Data Store Write'
               *  DataTypeConversion: '<S137>/Cast To Single'
               *  Delay: '<S137>/Delay2'
               *  Product: '<S137>/Divide3'
               *  Product: '<S137>/Divide4'
               *  Sum: '<S137>/Subtract1'
               */
              npc_controller_DWork.adc_offset_ib_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_j / (real32_T)
                npc_controller_DWork.cnt_calib + vabc3_e / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Sum: '<S136>/Add4' incorporates:
               *  Constant: '<S136>/Constant4'
               *  DataStoreRead: '<S136>/Data Store Read4'
               *  DataStoreWrite: '<S134>/Data Store Write1'
               *  DataTypeConversion: '<S136>/Cast To Single'
               *  Delay: '<S136>/Delay2'
               *  Product: '<S136>/Divide3'
               *  Product: '<S136>/Divide4'
               *  Sum: '<S136>/Subtract1'
               */
              npc_controller_DWork.adc_offset_ic_tmp = ((real32_T)
                npc_controller_DWork.cnt_calib - 1.0F) *
                npc_controller_DWork.Delay2_DSTATE_n / (real32_T)
                npc_controller_DWork.cnt_calib + vabc3_b3 / (real32_T)
                npc_controller_DWork.cnt_calib;

              /* Merge: '<S122>/Merge' incorporates:
               *  Constant: '<S134>/Constant1'
               */
              Constant1 = false;

              /* Update for Delay: '<S141>/Delay2' incorporates:
               *  DataStoreWrite: '<S134>/Data Store Write5'
               */
              npc_controller_DWork.Delay2_DSTATE =
                npc_controller_DWork.adc_offset_va_tmp;

              /* Update for Delay: '<S140>/Delay2' incorporates:
               *  DataStoreWrite: '<S134>/Data Store Write6'
               */
              npc_controller_DWork.Delay2_DSTATE_l =
                npc_controller_DWork.adc_offset_vb_tmp;

              /* Update for Delay: '<S139>/Delay2' incorporates:
               *  DataStoreWrite: '<S134>/Data Store Write3'
               */
              npc_controller_DWork.Delay2_DSTATE_i =
                npc_controller_DWork.adc_offset_vc_tmp;

              /* Update for Delay: '<S138>/Delay2' incorporates:
               *  DataStoreWrite: '<S134>/Data Store Write4'
               */
              npc_controller_DWork.Delay2_DSTATE_m =
                npc_controller_DWork.adc_offset_ia_tmp;

              /* Update for Delay: '<S137>/Delay2' incorporates:
               *  DataStoreWrite: '<S134>/Data Store Write'
               */
              npc_controller_DWork.Delay2_DSTATE_j =
                npc_controller_DWork.adc_offset_ib_tmp;

              /* Update for Delay: '<S136>/Delay2' incorporates:
               *  DataStoreWrite: '<S134>/Data Store Write1'
               */
              npc_controller_DWork.Delay2_DSTATE_n =
                npc_controller_DWork.adc_offset_ic_tmp;

              /* End of Outputs for SubSystem: '<S122>/cnt' */
            }

            /* End of If: '<S122>/If' */
            /* End of Outputs for SubSystem: '<S112>/updateCalib' */
            npc_controller_B.calib_ok = Constant1;
            npc_controller_B.state = 0U;

            /* exit */
            /* Transition: '<S112>:540' */
            /* Transition: '<S112>:732' */
            /* Transition: '<S112>:782' */
            /* Transition: '<S112>:708' */
            /* Transition: '<S112>:667' */
            /* Transition: '<S112>:718' */
            /* Transition: '<S112>:761' */
            /* Transition: '<S112>:535' */
          }
        } else {
          /* Transition: '<S112>:602' */
          npc_controller_DWork.start_cnt++;

          /* disCmpssTz();
             exit */
          /* Transition: '<S112>:603' */
          /* Transition: '<S112>:540' */
          /* Transition: '<S112>:732' */
          /* Transition: '<S112>:782' */
          /* Transition: '<S112>:708' */
          /* Transition: '<S112>:667' */
          /* Transition: '<S112>:718' */
          /* Transition: '<S112>:761' */
          /* Transition: '<S112>:535' */
        }

        if (guard1) {
          /* Outputs for Function Call SubSystem: '<S112>/disablePwm' */
          /* Transition: '<S112>:714' */
          /* Transition: '<S112>:436' */
          /* Simulink Function 'disablePwm': '<S112>:24' */

          /* user code (Output function Body for TID3) */

          /* System '<S112>/disablePwm' */
          /*Force PWM to LOW*/
          EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
          EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
          EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

          /* End of Outputs for SubSystem: '<S112>/disablePwm' */
          npc_controller_B.eoss = false;

          /* disDigCmpMode(); */
          cpu2cla_pha_en = false;
          cpu2cla_phb_en = false;
          cpu2cla_phc_en = false;
          cpu2cla_ref = npc_controller_B.ADC3;

          /* state = 3; */
          cpu2cla_pfc_ok2 = false;
          npc_controller_B.control_en = false;
          if ((!npc_controller_DWork.pfc_en) || npc_controller_B.tfv_v_UvpOvp) {
            /* Transition: '<S112>:758' */
            if (npc_controller_DWork.relayOff_cnt > 2600.0) {
              /* Transition: '<S112>:629' */
              /* 40ms delay to turn-OFF pre-charge relay */
              npc_controller_B.relay_ctrl = false;

              /* pre-charge relay OFF */
              npc_controller_DWork.relayOff_cnt = 0.0;
              npc_controller_DWork.relay_cnt = 0.0;
              npc_controller_DWork.eoss_cnt = 0.0;
              npc_controller_DWork.delay_cnt = 0.0;
            } else {
              /* Transition: '<S112>:640' */
              npc_controller_DWork.relayOff_cnt++;

              /* Transition: '<S112>:633' */
              /* Transition: '<S112>:634' */
            }

            /* Transition: '<S112>:328' */
            /* Transition: '<S112>:534' */
          } else {
            /* Transition: '<S112>:760' */
            /* Transition: '<S112>:535' */
          }
        }

        /* End of Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

        /* DataStoreWrite: '<S13>/Data Store Write' */
        npc_controller_DWork.u16Debug1 = npc_controller_B.state;

        /* DataStoreWrite: '<S13>/Data Store Write12' */
        npc_controller_DWork.relay_ctrl = npc_controller_B.relay_ctrl;

        /* DataStoreWrite: '<S13>/Data Store Write13' */
        npc_controller_DWork.pfc_ok = cpu2cla_pfc_ok2;

        /* Logic: '<S13>/NOT' incorporates:
         *  DataStoreWrite: '<S13>/Data Store Write3'
         */
        npc_controller_DWork.ac_ok = !npc_controller_B.tfv_v_UvpOvp;

        /* S-Function (c280xgpio_di): '<S13>/PFC_EN_GPIO60' */
        {
          npc_controller_B.PFC_EN_GPIO60 = GpioDataRegs.GPBDAT.bit.GPIO60;
        }

        /* MATLABSystem: '<S113>/Validate_DI' incorporates:
         *  Constant: '<S113>/Constant'
         *  Constant: '<S113>/Constant1'
         *  DataStoreWrite: '<S13>/Data Store Write4'
         */
        /*  din -> Digital Input Signal from GPIO */
        /*  assert_logic -> true - Assert if GPIO is High and Set State */
        /*                  false - Assert if GPIO is Low and Set State */
        /*  assert_dly -> Delay in 1mS Counter to Assert Din Signal     */
        /*  deassert_dly -> Delay in 1mS Counter to DeAssert Din Signal                  */
        /* if Assert Logic is True */
        if (!npc_controller_DWork.obj_nw.din_state) {
          /* Din State is Low */
          if (npc_controller_B.PFC_EN_GPIO60) {
            qY = npc_controller_DWork.obj_nw.cnt + 1U;
            if (npc_controller_DWork.obj_nw.cnt + 1U <
                npc_controller_DWork.obj_nw.cnt) {
              qY = MAX_uint16_T;
            }

            npc_controller_DWork.obj_nw.cnt = qY;
            if (npc_controller_DWork.obj_nw.cnt >= 67U) {
              npc_controller_DWork.obj_nw.din_state = true;

              /* Assert Signal State */
              npc_controller_DWork.obj_nw.cnt = 0U;
            }
          } else {
            npc_controller_DWork.obj_nw.cnt = 0U;
          }
        } else if (!npc_controller_B.PFC_EN_GPIO60) {
          qY = npc_controller_DWork.obj_nw.cnt + 1U;
          if (npc_controller_DWork.obj_nw.cnt + 1U <
              npc_controller_DWork.obj_nw.cnt) {
            qY = MAX_uint16_T;
          }

          npc_controller_DWork.obj_nw.cnt = qY;
          if (npc_controller_DWork.obj_nw.cnt >= 67U) {
            npc_controller_DWork.obj_nw.din_state = false;

            /* DeAssert Signal State */
            npc_controller_DWork.obj_nw.cnt = 0U;
          }
        } else {
          npc_controller_DWork.obj_nw.cnt = 0U;
        }

        npc_controller_DWork.pfc_en = npc_controller_DWork.obj_nw.din_state;

        /* End of MATLABSystem: '<S113>/Validate_DI' */

        /* SignalConversion generated from: '<S13>/angle' */
        cpu2cla_angle = 0.0;

        /* End of Outputs for S-Function (fcgen): '<S2>/Function-Call Generator' */

        /* DataStoreWrite: '<S2>/Data Store Write' */
        npc_controller_DWork.control_en = npc_controller_B.control_en;
      }

      /* End of Outputs for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
    }
  }
}

/* Hardware Interrupt Block: '<Root>/C28x Hardware Interrupt2' */
void isr_int9pie5_task_fcn(void)
{
  if (1 == runModel) {
    /* Call the system: <Root>/CANRX */
    {
      /* S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
      npc_controller_CANRX(&npc_controller_DWork.b05_MB10Received,
                           &npc_controller_DWork.b06_MB11Received,
                           &npc_controller_DWork.b07_MB12Received,
                           npc_controller_DWork.u8CanDataRx10,
                           npc_controller_DWork.u8CanDataRx11,
                           npc_controller_DWork.u8CanDataRx12,
                           &npc_controller_B.CANRX);

      /* End of Outputs for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
    }
  }
}

/* Idle Task Block: '<S187>/Idle Task' */
void idle_num1_task_fcn(void)
{
  /* Call the system: <S187>/IDLE */
  {
    /* S-Function (idletask): '<S187>/Idle Task' */

    /* Output and update for function-call system: '<S187>/IDLE' */
    {
      real_T tmp;
      real_T tmp_e;
      real_T tmp_i;
      real_T tmp_p;
      real32_T rtb_Saturation;
      real32_T rtb_Sum;
      real32_T rtb_Sum_cw;
      real32_T rtb_Sum_if;
      real32_T tmp_m;
      boolean_T tmp_g;

      /* S-Function (fcgen): '<S190>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S190>/idle_task'
       */
      /* SwitchCase: '<S296>/Switch Case' incorporates:
       *  DataStoreRead: '<S296>/Data Store Read'
       *  DataStoreRead: '<S299>/Data Store Read10'
       *  DataStoreRead: '<S299>/Data Store Read11'
       *  DataStoreRead: '<S299>/Data Store Read32'
       *  DataStoreRead: '<S299>/Data Store Read5'
       *  DataStoreRead: '<S299>/Data Store Read6'
       *  DataStoreRead: '<S299>/Data Store Read7'
       *  DataStoreRead: '<S299>/Data Store Read8'
       *  DataStoreRead: '<S299>/Data Store Read9'
       *  DataStoreRead: '<S302>/Data Store Read10'
       *  DataStoreRead: '<S302>/Data Store Read13'
       *  DataStoreRead: '<S302>/Data Store Read5'
       *  DataStoreRead: '<S302>/Data Store Read7'
       *  DataTypeConversion: '<S299>/Cast To Boolean4'
       *  DataTypeConversion: '<S299>/Cast To Boolean5'
       *  DataTypeConversion: '<S299>/Cast To Boolean6'
       *  DataTypeConversion: '<S299>/Cast To Boolean7'
       *  DataTypeConversion: '<S299>/Cast To Boolean8'
       *  DataTypeConversion: '<S302>/Data Type Conversion1'
       *  DataTypeConversion: '<S302>/Data Type Conversion2'
       *  DataTypeConversion: '<S302>/Data Type Conversion3'
       *  DataTypeConversion: '<S302>/Data Type Conversion4'
       *  DataTypeConversion: '<S302>/Data Type Conversion5'
       *  DataTypeConversion: '<S302>/Data Type Conversion6'
       *  DataTypeConversion: '<S302>/Data Type Conversion7'
       *  DataTypeConversion: '<S302>/Data Type Conversion8'
       */
      switch ((int32_T)npc_controller_DWork.cnt_idle) {
       case 0L:
        /* Outputs for IfAction SubSystem: '<S296>/report_status_flag_bits' incorporates:
         *  ActionPort: '<S302>/Action Port'
         */
        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift1' */
        npc_controller_BitShift1((uint16_T)npc_controller_DWork.pfc_en,
          &npc_controller_B.BitShift1);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift1' */

        /* DataTypeConversion: '<S302>/Data Type Conversion2' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read10'
         *  DataStoreRead: '<S302>/Data Store Read12'
         *  DataTypeConversion: '<S302>/Data Type Conversion1'
         */
        tmp_i = floor(npc_controller_DWork.rec_en);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift2' */
        npc_controller_BitShift2(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift2);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift2' */

        /* DataTypeConversion: '<S302>/Data Type Conversion3' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read4'
         *  DataTypeConversion: '<S302>/Data Type Conversion2'
         */
        tmp_i = floor(npc_controller_DWork.inv_en);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift3' */
        npc_controller_BitShift3(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift3);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift3' */

        /* DataTypeConversion: '<S302>/Data Type Conversion4' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read14'
         *  DataTypeConversion: '<S302>/Data Type Conversion3'
         */
        tmp_i = floor(npc_controller_DWork.can_on_cmd);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift6' */
        npc_controller_BitShift6(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift6);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift6' */

        /* DataTypeConversion: '<S302>/Data Type Conversion5' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read1'
         *  DataTypeConversion: '<S302>/Data Type Conversion4'
         */
        tmp_i = floor(npc_controller_DWork.pos_seq);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift4' */
        npc_controller_BitShift4(tmp_i < 0.0 ? (uint16_T)-(int16_T)(uint16_T)
          -tmp_i : (uint16_T)tmp_i, &npc_controller_B.BitShift4);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift4' */

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift5' */
        npc_controller_BitShift5((uint16_T)npc_controller_DWork.relay_ctrl,
          &npc_controller_B.BitShift5);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift5' */

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift7' */
        npc_controller_BitShift7((uint16_T)npc_controller_DWork.ac_ok,
          &npc_controller_B.BitShift7);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift7' */

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift8' */
        npc_controller_BitShift8((uint16_T)npc_controller_DWork.pfc_ok,
          &npc_controller_B.BitShift8);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift8' */

        /* DataTypeConversion: '<S302>/Data Type Conversion' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read13'
         *  DataStoreRead: '<S302>/Data Store Read5'
         *  DataStoreRead: '<S302>/Data Store Read6'
         *  DataStoreRead: '<S302>/Data Store Read7'
         *  DataTypeConversion: '<S302>/Data Type Conversion5'
         *  DataTypeConversion: '<S302>/Data Type Conversion6'
         *  DataTypeConversion: '<S302>/Data Type Conversion7'
         *  DataTypeConversion: '<S302>/Data Type Conversion8'
         */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S373>:1' */
        /* '<S373>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S363>:1' */
        /* '<S363>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S364>:1' */
        /* '<S364>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S365>:1' */
        /* '<S365>:1:6' */
        tmp_i = floor(npc_controller_DWork.state_control);
        if (rtIsNaN(tmp_i) || rtIsInf(tmp_i)) {
          tmp_i = 0.0;
        } else {
          tmp_i = fmod(tmp_i, 65536.0);
        }

        /* DataTypeConversion: '<S302>/Data Type Conversion9' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read2'
         */
        tmp = floor(npc_controller_DWork.clllc_ok);
        if (rtIsNaN(tmp) || rtIsInf(tmp)) {
          tmp = 0.0;
        } else {
          tmp = fmod(tmp, 65536.0);
        }

        /* DataTypeConversion: '<S302>/Data Type Conversion10' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read3'
         */
        tmp_p = floor(npc_controller_DWork.npc_fault);
        if (rtIsNaN(tmp_p) || rtIsInf(tmp_p)) {
          tmp_p = 0.0;
        } else {
          tmp_p = fmod(tmp_p, 65536.0);
        }

        /* DataTypeConversion: '<S302>/Data Type Conversion11' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read44'
         */
        rtb_Saturation = (real32_T)floor(npc_controller_DWork.otp_fault);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 65536.0);
        }

        /* DataTypeConversion: '<S302>/Data Type Conversion12' incorporates:
         *  DataStoreRead: '<S302>/Data Store Read9'
         */
        tmp_e = floor(npc_controller_DWork.can_timeout);
        if (rtIsNaN(tmp_e) || rtIsInf(tmp_e)) {
          tmp_e = 0.0;
        } else {
          tmp_e = fmod(tmp_e, 65536.0);
        }

        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift9' */
        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift10' */
        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift11' */
        /* Outputs for Atomic SubSystem: '<S302>/Bit Shift12' */
        /* Sum: '<S302>/Add' incorporates:
         *  DataStoreWrite: '<S302>/Data Store Write'
         *  DataTypeConversion: '<S302>/Data Type Conversion'
         *  DataTypeConversion: '<S302>/Data Type Conversion10'
         *  DataTypeConversion: '<S302>/Data Type Conversion11'
         *  DataTypeConversion: '<S302>/Data Type Conversion12'
         *  DataTypeConversion: '<S302>/Data Type Conversion9'
         *  MATLAB Function: '<S351>/bit_shift'
         *  MATLAB Function: '<S352>/bit_shift'
         *  MATLAB Function: '<S353>/bit_shift'
         *  MATLAB Function: '<S361>/bit_shift'
         */
        npc_controller_DWork.sPriStatus = ((((((((((((tmp_i < 0.0 ? (uint16_T)
          -(int16_T)(uint16_T)-tmp_i : (uint16_T)tmp_i) +
          npc_controller_B.BitShift1.y) + npc_controller_B.BitShift2.y) +
          npc_controller_B.BitShift3.y) + npc_controller_B.BitShift6.y) +
          npc_controller_B.BitShift4.y) + npc_controller_B.BitShift5.y) +
          npc_controller_B.BitShift7.y) + npc_controller_B.BitShift8.y) + ((tmp <
          0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)tmp) << 12)) +
          ((tmp_p < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp_p : (uint16_T)tmp_p)
           << 13)) + ((rtb_Saturation < 0.0F ? (uint16_T)-(int16_T)(uint16_T)
                       -rtb_Saturation : (uint16_T)rtb_Saturation) << 14)) +
          ((tmp_e < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp_e : (uint16_T)tmp_e)
           << 15);

        /* End of Outputs for SubSystem: '<S302>/Bit Shift12' */
        /* End of Outputs for SubSystem: '<S302>/Bit Shift11' */
        /* End of Outputs for SubSystem: '<S302>/Bit Shift10' */
        /* End of Outputs for SubSystem: '<S302>/Bit Shift9' */
        /* End of Outputs for SubSystem: '<S296>/report_status_flag_bits' */
        break;

       case 1L:
        /* Outputs for IfAction SubSystem: '<S296>/watchdog' incorporates:
         *  ActionPort: '<S303>/Action Port'
         */
        /* S-Function (c28xwatchdog): '<S303>/Watchdog' */
        {
          KickDog();
        }

        /* End of Outputs for SubSystem: '<S296>/watchdog' */
        break;

       case 2L:
        /* Outputs for IfAction SubSystem: '<S296>/hkeep' incorporates:
         *  ActionPort: '<S300>/Action Port'
         */
        /* S-Function (fcgen): '<S300>/Function-Call Generator1' incorporates:
         *  SubSystem: '<S300>/tz'
         */

        /* user code (Output function Body for TID5) */

        /* System '<S300>/tz' */
        npc_controller_DWork.tz_ocp = EPwm2Regs.TZOSTFLG.bit.OST1;
        npc_controller_DWork.tz_ovp = EPwm2Regs.TZOSTFLG.bit.OST2;

        /*npc_controller_DWork.tz_cmpssocp = EPwm2Regs.TZOSTFLG.bit.DCAEVT1 | EPwm2Regs.TZOSTFLG.bit.DCBEVT1 | EPwm7Regs.TZOSTFLG.bit.DCAEVT1 | EPwm7Regs.TZOSTFLG.bit.DCBEVT1 | EPwm8Regs.TZOSTFLG.bit.DCAEVT1 | EPwm8Regs.TZOSTFLG.bit.DCBEVT1 | EPwm9Regs.TZOSTFLG.bit.DCAEVT1 | EPwm9Regs.TZOSTFLG.bit.DCBEVT1| EPwm10Regs.TZOSTFLG.bit.DCAEVT1 | EPwm10Regs.TZOSTFLG.bit.DCBEVT1 | EPwm11Regs.TZOSTFLG.bit.DCAEVT1 | EPwm11Regs.TZOSTFLG.bit.DCBEVT1;*/
        /*npc_controller_DWork.tz_cmpssocp = EPwm2Regs.TZFLG.bit.DCAEVT1 | EPwm2Regs.TZFLG.bit.DCBEVT1 | EPwm7Regs.TZFLG.bit.DCAEVT1 | EPwm7Regs.TZFLG.bit.DCBEVT1 | EPwm8Regs.TZFLG.bit.DCAEVT1 | EPwm8Regs.TZFLG.bit.DCBEVT1 | EPwm9Regs.TZFLG.bit.DCAEVT1 | EPwm9Regs.TZFLG.bit.DCBEVT1| EPwm10Regs.TZFLG.bit.DCAEVT1 | EPwm10Regs.TZFLG.bit.DCBEVT1 | EPwm11Regs.TZFLG.bit.DCAEVT1 | EPwm11Regs.TZFLG.bit.DCBEVT1;*/
        /*npc_controller_DWork.tz_ocp = EPwm7Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm7Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm8Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm8Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm9Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm9Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm10Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm10Regs.TZOSTFLG.bit.OST2;
           npc_controller_DWork.tz_ocp = EPwm11Regs.TZOSTFLG.bit.OST1;
           npc_controller_DWork.tz_ovp = EPwm11Regs.TZOSTFLG.bit.OST2;*/

        /* S-Function (fcgen): '<S300>/Function-Call Generator1' incorporates:
         *  SubSystem: '<S300>/tfv'
         */
        /* Chart: '<S326>/hkeep1' incorporates:
         *  DataStoreRead: '<S329>/Data Store Read'
         *  DataStoreRead: '<S330>/Data Store Read'
         *  DataStoreRead: '<S331>/Data Store Read'
         *  DataStoreRead: '<S332>/Data Store Read'
         *  DataStoreRead: '<S333>/Data Store Read'
         *  DataStoreRead: '<S334>/Data Store Read'
         *  DataTypeConversion: '<S329>/Data Type Conversion'
         *  DataTypeConversion: '<S330>/Data Type Conversion'
         *  DataTypeConversion: '<S331>/Data Type Conversion'
         *  DataTypeConversion: '<S332>/Data Type Conversion'
         *  DataTypeConversion: '<S333>/Data Type Conversion'
         *  DataTypeConversion: '<S334>/Data Type Conversion'
         */
        /* Gateway: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
        /* During: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
        if (npc_controller_DWork.is_active_c23_npc_controller == 0U) {
          /* Entry: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
          npc_controller_DWork.is_active_c23_npc_controller = 1U;

          /* Entry Internal: IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1 */
          /* Transition: '<S328>:390' */
          /* Entry 'HKEEP': '<S328>:1' */
        } else {
          /* During 'HKEEP': '<S328>:1' */
          npc_controller_B.input = (uint16_T)npc_controller_DWork.adc_va;
          npc_controller_B.assert_lim = 2940U;
          npc_controller_B.assert_vld = 3U;
          npc_controller_B.deassert_lim = 1U;
          npc_controller_B.deassert_vld = 3U;

          /* Outputs for Function Call SubSystem: '<S328>/HKEEP.tfvVa' */
          /* Simulink Function 'tfvVa': '<S328>:304' */
          npc_controller_MATLABSystem(npc_controller_B.input, 2940U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem,
            &npc_controller_DWork.MATLABSystem);
          npc_controller_DWork.tfv_va =
            (npc_controller_B.MATLABSystem.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S328>/HKEEP.tfvVa' */
          /* 400Vac,pk */
          npc_controller_B.input_a = (uint16_T)npc_controller_DWork.adc_vb;
          npc_controller_B.assert_lim_h = 2940U;
          npc_controller_B.assert_vld_f = 3U;
          npc_controller_B.deassert_lim_c = 1U;
          npc_controller_B.deassert_vld_o = 3U;

          /* Outputs for Function Call SubSystem: '<S328>/HKEEP.tfvVb' */
          /* Simulink Function 'tfvVb': '<S328>:311' */
          npc_controller_MATLABSystem(npc_controller_B.input_a, 2940U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n,
            &npc_controller_DWork.MATLABSystem_n);
          npc_controller_DWork.tfv_vb =
            (npc_controller_B.MATLABSystem_n.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S328>/HKEEP.tfvVb' */
          /* 400Vac,pk */
          npc_controller_B.input_n = (uint16_T)npc_controller_DWork.adc_vc;
          npc_controller_B.assert_lim_c = 2940U;
          npc_controller_B.assert_vld_d = 3U;
          npc_controller_B.deassert_lim_e = 1U;
          npc_controller_B.deassert_vld_n = 3U;

          /* Outputs for Function Call SubSystem: '<S328>/HKEEP.tfvVc' */
          /* Simulink Function 'tfvVc': '<S328>:318' */
          npc_controller_MATLABSystem(npc_controller_B.input_n, 2940U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2,
            &npc_controller_DWork.MATLABSystem_n2);
          npc_controller_DWork.tfv_vc =
            (npc_controller_B.MATLABSystem_n2.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S328>/HKEEP.tfvVc' */
          /* 400Vac,pk
             tfv_iphasea = tfvIphaseA(uint16(adc_iphasea), uint16(2100), uint16(1), uint16(1), uint16(3)); //2A
             tfv_iphaseb = tfvIphaseB(uint16(adc_iphaseb), uint16(2100), uint16(1), uint16(1), uint16(3)); //2A
             tfv_iphasec = tfvIphaseC(uint16(adc_iphasec), uint16(2100), uint16(1), uint16(1), uint16(3)); //2A */
          npc_controller_B.input_j = (uint16_T)npc_controller_DWork.adc_vbulk;
          npc_controller_B.assert_lim_p = 3821U;
          npc_controller_B.assert_vld_h = 3U;
          npc_controller_B.deassert_lim_b = 1U;
          npc_controller_B.deassert_vld_e = 3U;

          /* Outputs for Function Call SubSystem: '<S328>/HKEEP.tfvVbulk' */
          /* Simulink Function 'tfvVbulk': '<S328>:297' */
          npc_controller_MATLABSystem(npc_controller_B.input_j, 3821U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2n,
            &npc_controller_DWork.MATLABSystem_n2n);
          npc_controller_DWork.tfv_vbulk =
            (npc_controller_B.MATLABSystem_n2n.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S328>/HKEEP.tfvVbulk' */
          /* 850V */
          npc_controller_B.input_m = (uint16_T)npc_controller_DWork.adc_vmid;
          npc_controller_B.assert_lim_b = 3443U;
          npc_controller_B.assert_vld_m = 3U;
          npc_controller_B.deassert_lim_p = 1U;
          npc_controller_B.deassert_vld_c = 3U;

          /* Outputs for Function Call SubSystem: '<S328>/HKEEP.tfvVmid' */
          /* Simulink Function 'tfvVmid': '<S328>:71' */
          npc_controller_MATLABSystem(npc_controller_B.input_m, 3443U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2nv,
            &npc_controller_DWork.MATLABSystem_n2nv);
          npc_controller_DWork.tfv_vmid =
            (npc_controller_B.MATLABSystem_n2nv.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S328>/HKEEP.tfvVmid' */
          /* 430V */
          npc_controller_B.input_ah = (uint16_T)npc_controller_DWork.adc_vaux;
          npc_controller_B.assert_lim_m = 3722U;
          npc_controller_B.assert_vld_k = 3U;
          npc_controller_B.deassert_lim_py = 1U;
          npc_controller_B.deassert_vld_j = 3U;

          /* Outputs for Function Call SubSystem: '<S328>/HKEEP.tfvVaux' */
          /* Simulink Function 'tfvVaux': '<S328>:389' */
          npc_controller_MATLABSystem(npc_controller_B.input_ah, 3722U, 3U,
            npc_controller_DWork.cnt_1ms, &npc_controller_B.MATLABSystem_n2nvq,
            &npc_controller_DWork.MATLABSystem_n2nvq);
          npc_controller_DWork.tfv_vaux =
            (npc_controller_B.MATLABSystem_n2nvq.MATLABSystem != 0U);

          /* End of Outputs for SubSystem: '<S328>/HKEEP.tfvVaux' */
          /* 3V */
        }

        /* End of Chart: '<S326>/hkeep1' */
        /* End of Outputs for S-Function (fcgen): '<S300>/Function-Call Generator1' */
        /* End of Outputs for SubSystem: '<S296>/hkeep' */
        break;

       case 3L:
        /* Outputs for IfAction SubSystem: '<S296>/report_adc' incorporates:
         *  ActionPort: '<S301>/Action Port'
         */
        /* Sum: '<S336>/Sum' incorporates:
         *  Delay: '<S336>/Delay'
         *  Delay: '<S336>/Delay1'
         *  Gain: '<S336>/1 - Lambda'
         *  Gain: '<S336>/Lambda'
         */
        rtb_Sum = 0.008F * npc_controller_DWork.Delay1_DSTATE + 0.992F *
          npc_controller_DWork.Delay_DSTATE;

        /* DataTypeConversion: '<S301>/Cast To Single3' incorporates:
         *  DataStoreWrite: '<S301>/Data Store Write3'
         */
        rtb_Saturation = (real32_T)floor(rtb_Sum);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 256.0);
        }

        npc_controller_DWork.u8TnpcB = (uint16_T)(int16_T)rtb_Saturation & 255U;

        /* End of DataTypeConversion: '<S301>/Cast To Single3' */

        /* Sum: '<S337>/Sum' incorporates:
         *  Delay: '<S337>/Delay'
         *  Delay: '<S337>/Delay1'
         *  Gain: '<S337>/1 - Lambda'
         *  Gain: '<S337>/Lambda'
         */
        rtb_Sum_cw = 0.008F * npc_controller_DWork.Delay1_DSTATE_p + 0.992F *
          npc_controller_DWork.Delay_DSTATE_m;

        /* DataTypeConversion: '<S301>/Cast To Single4' incorporates:
         *  DataStoreWrite: '<S301>/Data Store Write4'
         */
        rtb_Saturation = (real32_T)floor(rtb_Sum_cw);
        if (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation)) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 256.0);
        }

        npc_controller_DWork.u8TnpcC = (uint16_T)(int16_T)rtb_Saturation & 255U;

        /* End of DataTypeConversion: '<S301>/Cast To Single4' */

        /* Sum: '<S335>/Sum' incorporates:
         *  Delay: '<S335>/Delay'
         *  Delay: '<S335>/Delay1'
         *  Gain: '<S335>/1 - Lambda'
         *  Gain: '<S335>/Lambda'
         */
        rtb_Sum_if = 0.008F * npc_controller_DWork.Delay1_DSTATE_c + 0.992F *
          npc_controller_DWork.Delay_DSTATE_o;

        /* DataTypeConversion: '<S301>/Cast To Single2' incorporates:
         *  DataStoreWrite: '<S301>/Data Store Write'
         *  DataTypeConversion: '<S301>/Cast To Single1'
         */
        rtb_Saturation = (real32_T)floor(rtb_Sum_if);
        tmp_g = (rtIsNaNF(rtb_Saturation) || rtIsInfF(rtb_Saturation));
        if (tmp_g) {
          tmp_m = 0.0F;
        } else {
          tmp_m = (real32_T)fmod(rtb_Saturation, 256.0);
        }

        npc_controller_DWork.u8TnpcA = (uint16_T)(int16_T)tmp_m & 255U;

        /* End of DataTypeConversion: '<S301>/Cast To Single2' */

        /* DataTypeConversion: '<S301>/Cast To Single' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read26'
         *  DataStoreWrite: '<S301>/Data Store Write1'
         */
        tmp_m = (real32_T)floor(npc_controller_DWork.adc_temp_npca);
        if (rtIsNaNF(tmp_m) || rtIsInfF(tmp_m)) {
          tmp_m = 0.0F;
        } else {
          tmp_m = (real32_T)fmod(tmp_m, 65536.0);
        }

        npc_controller_DWork.u16Debug5 = tmp_m < 0.0F ? (uint16_T)-(int16_T)
          (uint16_T)-tmp_m : (uint16_T)tmp_m;

        /* End of DataTypeConversion: '<S301>/Cast To Single' */

        /* DataTypeConversion: '<S301>/Cast To Single1' incorporates:
         *  DataStoreWrite: '<S301>/Data Store Write2'
         */
        if (tmp_g) {
          rtb_Saturation = 0.0F;
        } else {
          rtb_Saturation = (real32_T)fmod(rtb_Saturation, 65536.0);
        }

        npc_controller_DWork.u16Debug4 = rtb_Saturation < 0.0F ? (uint16_T)
          -(int16_T)(uint16_T)-rtb_Saturation : (uint16_T)rtb_Saturation;

        /* Sum: '<S339>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read23'
         *  DataStoreRead: '<S301>/Data Store Read31'
         */
        rtb_Saturation = npc_controller_DWork.rms_ia -
          npc_controller_DWork.f32OffsetLineCurrentCS;

        /* Saturate: '<S339>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S339>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read'
         *  DataStoreWrite: '<S301>/Data Store Write13'
         *  Saturate: '<S339>/Saturation'
         */
        npc_controller_DWork.f32IinA = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentCS;

        /* Sum: '<S342>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read2'
         *  DataStoreRead: '<S301>/Data Store Read25'
         */
        rtb_Saturation = npc_controller_DWork.rms_ib -
          npc_controller_DWork.f32OffsetLineCurrentCS;

        /* Saturate: '<S342>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S342>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read1'
         *  DataStoreWrite: '<S301>/Data Store Write12'
         *  Saturate: '<S342>/Saturation'
         */
        npc_controller_DWork.f32IinB = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentCS;

        /* Sum: '<S348>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read13'
         *  DataStoreRead: '<S301>/Data Store Read7'
         */
        rtb_Saturation = npc_controller_DWork.rms_vb -
          npc_controller_DWork.f32OffsetLineVoltage;

        /* Saturate: '<S348>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S348>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read10'
         *  DataStoreWrite: '<S301>/Data Store Write18'
         *  Saturate: '<S348>/Saturation'
         */
        npc_controller_DWork.f32VinB = rtb_Saturation *
          npc_controller_DWork.f32GainLineVoltage;

        /* Product: '<S349>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read11'
         *  DataStoreRead: '<S301>/Data Store Read36'
         *  DataStoreWrite: '<S301>/Data Store Write42'
         */
        npc_controller_DWork.f32Vpfc = npc_controller_DWork.adc_vbulk *
          npc_controller_DWork.f32GainVbulk;

        /* Sum: '<S341>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read15'
         *  DataStoreRead: '<S301>/Data Store Read9'
         */
        rtb_Saturation = npc_controller_DWork.rms_vc -
          npc_controller_DWork.f32OffsetLineVoltage;

        /* Saturate: '<S341>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S341>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read12'
         *  DataStoreWrite: '<S301>/Data Store Write45'
         *  Saturate: '<S341>/Saturation'
         */
        npc_controller_DWork.f32VinC = rtb_Saturation *
          npc_controller_DWork.f32GainLineVoltage;

        /* Gain: '<S301>/Gain' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read14'
         *  DataStoreWrite: '<S301>/Data Store Write44'
         */
        npc_controller_DWork.f32Vaux = 0.000805860793F *
          npc_controller_DWork.adc_vaux;

        /* Product: '<S340>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read16'
         *  DataStoreRead: '<S301>/Data Store Read37'
         *  DataStoreWrite: '<S301>/Data Store Write41'
         */
        npc_controller_DWork.f32VpfcMid = npc_controller_DWork.adc_vmid *
          npc_controller_DWork.f32GainVmid;

        /* Sum: '<S344>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read17'
         *  DataStoreRead: '<S301>/Data Store Read19'
         */
        rtb_Saturation = npc_controller_DWork.rms_iphasea -
          npc_controller_DWork.f32OffsetLineCurrentHE;

        /* Saturate: '<S344>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S344>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read18'
         *  DataStoreWrite: '<S301>/Data Store Write43'
         *  Saturate: '<S344>/Saturation'
         */
        npc_controller_DWork.f32IphaseA = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentHE;

        /* Sum: '<S347>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read20'
         *  DataStoreRead: '<S301>/Data Store Read35'
         */
        rtb_Saturation = npc_controller_DWork.rms_iphasec -
          npc_controller_DWork.f32OffsetLineCurrentHE;

        /* Saturate: '<S347>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S347>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read34'
         *  DataStoreWrite: '<S301>/Data Store Write40'
         *  Saturate: '<S347>/Saturation'
         */
        npc_controller_DWork.f32IphaseC = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentHE;

        /* Sum: '<S345>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read22'
         *  DataStoreRead: '<S301>/Data Store Read33'
         */
        rtb_Saturation = npc_controller_DWork.rms_iphaseb -
          npc_controller_DWork.f32OffsetLineCurrentHE;

        /* Saturate: '<S345>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S345>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read32'
         *  DataStoreWrite: '<S301>/Data Store Write23'
         *  Saturate: '<S345>/Saturation'
         */
        npc_controller_DWork.f32IphaseB = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentHE;

        /* Sum: '<S343>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read27'
         *  DataStoreRead: '<S301>/Data Store Read6'
         */
        rtb_Saturation = npc_controller_DWork.rms_ic -
          npc_controller_DWork.f32OffsetLineCurrentCS;

        /* Saturate: '<S343>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S343>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read4'
         *  DataStoreWrite: '<S301>/Data Store Write24'
         *  Saturate: '<S343>/Saturation'
         */
        npc_controller_DWork.f32IinC = rtb_Saturation *
          npc_controller_DWork.f32GainLineCurrentCS;

        /* Sum: '<S346>/Subtract' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read3'
         *  DataStoreRead: '<S301>/Data Store Read5'
         */
        rtb_Saturation = npc_controller_DWork.rms_va -
          npc_controller_DWork.f32OffsetLineVoltage;

        /* Saturate: '<S346>/Saturation' */
        if (rtb_Saturation <= 0.0F) {
          rtb_Saturation = 0.0F;
        }

        /* Product: '<S346>/Product6' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read8'
         *  DataStoreWrite: '<S301>/Data Store Write19'
         *  Saturate: '<S346>/Saturation'
         */
        npc_controller_DWork.f32VinA = rtb_Saturation *
          npc_controller_DWork.f32GainLineVoltage;

        /* S-Function (c280xgpio_do): '<S301>/GPIO86' incorporates:
         *  Constant: '<S301>/Constant8'
         */
        {
          GpioDataRegs.GPCTOGGLE.bit.GPIO86 = (uint16_T)((1.0F) != 0);
        }

        /* Update for Delay: '<S336>/Delay1' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read28'
         *  Lookup_n-D: '<S301>/1-D Lookup Table1'
         */
        /* Gateway: IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP */
        /* During: IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP */
        /* Entry Internal: IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP */
        /* Transition: '<S338>:17' */
        npc_controller_DWork.Delay1_DSTATE = look1_iflf_binlxpw
          (npc_controller_DWork.adc_temp_npcb, npc_controller_ConstP.pooled43,
           npc_controller_ConstP.pooled42, 190UL);

        /* Update for Delay: '<S336>/Delay' */
        npc_controller_DWork.Delay_DSTATE = rtb_Sum;

        /* Update for Delay: '<S337>/Delay1' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read29'
         *  Lookup_n-D: '<S301>/1-D Lookup Table2'
         */
        npc_controller_DWork.Delay1_DSTATE_p = look1_iflf_binlxpw
          (npc_controller_DWork.adc_temp_npcc, npc_controller_ConstP.pooled43,
           npc_controller_ConstP.pooled42, 190UL);

        /* Update for Delay: '<S337>/Delay' */
        npc_controller_DWork.Delay_DSTATE_m = rtb_Sum_cw;

        /* Update for Delay: '<S335>/Delay1' incorporates:
         *  DataStoreRead: '<S301>/Data Store Read26'
         *  Lookup_n-D: '<S301>/1-D Lookup Table3'
         */
        npc_controller_DWork.Delay1_DSTATE_c = look1_iflf_binlxpw
          (npc_controller_DWork.adc_temp_npca, npc_controller_ConstP.pooled43,
           npc_controller_ConstP.pooled42, 190UL);

        /* Update for Delay: '<S335>/Delay' */
        npc_controller_DWork.Delay_DSTATE_o = rtb_Sum_if;

        /* End of Outputs for SubSystem: '<S296>/report_adc' */
        break;

       case 4L:
       case 5L:
        break;

       case 6L:
        /* Outputs for IfAction SubSystem: '<S296>/fault_bitwise' incorporates:
         *  ActionPort: '<S299>/Action Port'
         */
        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift3' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S315>:1' */
        /* '<S315>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S316>:1' */
        /* '<S316>:1:6' */
        /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S317>:1' */
        /* '<S317>:1:6' */
        npc_controller_BitShift1((uint16_T)npc_controller_DWork.tfv_iphaseb,
          &npc_controller_B.BitShift3_g);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift3' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift4' */
        npc_controller_BitShift2((uint16_T)npc_controller_DWork.tfv_iphasec,
          &npc_controller_B.BitShift4_b);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift4' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift5' */
        npc_controller_BitShift3((uint16_T)npc_controller_DWork.tfv_vbulk,
          &npc_controller_B.BitShift5_o);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift5' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift6' */
        npc_controller_BitShift6((uint16_T)npc_controller_DWork.tfv_vmid,
          &npc_controller_B.BitShift6_l);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift6' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift7' */
        npc_controller_BitShift4((uint16_T)npc_controller_DWork.tfv_vaux,
          &npc_controller_B.BitShift7_h);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift7' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift8' */
        npc_controller_BitShift5(npc_controller_DWork.tz_ocp,
          &npc_controller_B.BitShift8_h);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift8' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift9' */
        npc_controller_BitShift7(npc_controller_DWork.tz_ovp,
          &npc_controller_B.BitShift9_l);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift9' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift27' */
        npc_controller_BitShift8(npc_controller_DWork.tz_cmpssocp,
          &npc_controller_B.BitShift27);

        /* End of Outputs for SubSystem: '<S299>/Bit Shift27' */

        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift' */
        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift1' */
        /* Outputs for Atomic SubSystem: '<S299>/Bit Shift2' */
        /* Sum: '<S299>/Add' incorporates:
         *  DataStoreRead: '<S299>/Data Store Read1'
         *  DataStoreRead: '<S299>/Data Store Read10'
         *  DataStoreRead: '<S299>/Data Store Read11'
         *  DataStoreRead: '<S299>/Data Store Read2'
         *  DataStoreRead: '<S299>/Data Store Read3'
         *  DataStoreRead: '<S299>/Data Store Read32'
         *  DataStoreRead: '<S299>/Data Store Read4'
         *  DataStoreRead: '<S299>/Data Store Read5'
         *  DataStoreRead: '<S299>/Data Store Read6'
         *  DataStoreRead: '<S299>/Data Store Read7'
         *  DataStoreRead: '<S299>/Data Store Read8'
         *  DataStoreRead: '<S299>/Data Store Read9'
         *  DataStoreWrite: '<S299>/Data Store Write1'
         *  DataTypeConversion: '<S299>/Cast To Boolean'
         *  DataTypeConversion: '<S299>/Cast To Boolean1'
         *  DataTypeConversion: '<S299>/Cast To Boolean2'
         *  DataTypeConversion: '<S299>/Cast To Boolean3'
         *  DataTypeConversion: '<S299>/Cast To Boolean4'
         *  DataTypeConversion: '<S299>/Cast To Boolean5'
         *  DataTypeConversion: '<S299>/Cast To Boolean6'
         *  DataTypeConversion: '<S299>/Cast To Boolean7'
         *  DataTypeConversion: '<S299>/Cast To Boolean8'
         *  MATLAB Function: '<S304>/bit_shift'
         *  MATLAB Function: '<S305>/bit_shift'
         *  MATLAB Function: '<S306>/bit_shift'
         */
        npc_controller_DWork.u16Debug0 = ((((((((((((uint16_T)
          npc_controller_DWork.tfv_vb << 1) + npc_controller_DWork.tfv_va) +
          ((uint16_T)npc_controller_DWork.tfv_vc << 2)) + ((uint16_T)
          npc_controller_DWork.tfv_iphasea << 3)) +
          npc_controller_B.BitShift3_g.y) + npc_controller_B.BitShift4_b.y) +
          npc_controller_B.BitShift5_o.y) + npc_controller_B.BitShift6_l.y) +
          npc_controller_B.BitShift7_h.y) + npc_controller_B.BitShift8_h.y) +
          npc_controller_B.BitShift9_l.y) + npc_controller_B.BitShift27.y;

        /* End of Outputs for SubSystem: '<S299>/Bit Shift2' */
        /* End of Outputs for SubSystem: '<S299>/Bit Shift1' */
        /* End of Outputs for SubSystem: '<S299>/Bit Shift' */

        /* DataStoreWrite: '<S299>/Data Store Write4' */
        npc_controller_DWork.u8ThermalFlags = 0U;

        /* DataStoreWrite: '<S299>/Data Store Write5' */
        npc_controller_DWork.u8Reserved1 = 0U;

        /* DataStoreWrite: '<S299>/Data Store Write6' */
        npc_controller_DWork.u16Reserved1 = 0U;

        /* End of Outputs for SubSystem: '<S296>/fault_bitwise' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of SwitchCase: '<S296>/Switch Case' */

      /* S-Function (fcgen): '<S190>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S190>/cnt_idle'
       */
      /* If: '<S295>/If' incorporates:
       *  DataStoreRead: '<S295>/Data Store Read'
       */
      if (npc_controller_DWork.cnt_idle < 6U) {
        /* Outputs for IfAction SubSystem: '<S295>/cnt_idle' incorporates:
         *  ActionPort: '<S297>/Action Port'
         */
        /* DataStoreWrite: '<S297>/Data Store Write' incorporates:
         *  Constant: '<S297>/Constant'
         *  DataStoreRead: '<S297>/Data Store Read1'
         *  Sum: '<S297>/Add'
         */
        npc_controller_DWork.cnt_idle++;

        /* End of Outputs for SubSystem: '<S295>/cnt_idle' */
      } else {
        /* Outputs for IfAction SubSystem: '<S295>/cnt_idle_sat' incorporates:
         *  ActionPort: '<S298>/Action Port'
         */
        /* DataStoreWrite: '<S298>/Data Store Write' incorporates:
         *  Constant: '<S298>/Constant'
         */
        npc_controller_DWork.cnt_idle = 0U;

        /* End of Outputs for SubSystem: '<S295>/cnt_idle_sat' */
      }

      /* End of If: '<S295>/If' */
      /* End of Outputs for S-Function (fcgen): '<S190>/Function-Call Generator1' */
    }

    /* End of Outputs for S-Function (idletask): '<S187>/Idle Task' */
  }
}

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to remember which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void npc_controller_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(npc_controller_M, 1));
  eventFlags[2] = ((boolean_T)rtmStepTask(npc_controller_M, 2));
}

/*
 *         This function updates active task flag for each subrate
 *         and rate transition flags for tasks that exchange data.
 *         The function assumes rate-monotonic multitasking scheduler.
 *         The function must be called at model base rate so that
 *         the generated code self-manages all its subrates and rate
 *         transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (npc_controller_M->Timing.TaskCounters.TID[2])++;
  if ((npc_controller_M->Timing.TaskCounters.TID[2]) > 19) {/* Sample time: [0.02s, 0.0s] */
    npc_controller_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/*
 * System initialize for function-call system:
 *    '<S112>/detectZCPhA'
 *    '<S112>/detectZCPhB'
 *    '<S112>/detectZCPhC'
 */
void npc_contro_detectZCPhA_Init(rtB_detectZCPhA_npc_controller *localB)
{
  /* SystemInitialize for Merge: '<S117>/Merge1' */
  localB->Merge1 = false;
}

/*
 * Output and update for function-call system:
 *    '<S112>/detectZCPhA'
 *    '<S112>/detectZCPhB'
 *    '<S112>/detectZCPhC'
 */
void npc_controller_detectZCPhA(real_T rtu_vxn, rtB_detectZCPhA_npc_controller
  *localB)
{
  /* Outputs for IfAction SubSystem: '<S117>/false' incorporates:
   *  ActionPort: '<S128>/Action Port'
   */
  /* Outputs for IfAction SubSystem: '<S117>/true' incorporates:
   *  ActionPort: '<S129>/Action Port'
   */
  /* If: '<S117>/If1' incorporates:
   *  Constant: '<S128>/Constant1'
   *  Constant: '<S129>/Constant'
   *  Merge: '<S117>/Merge1'
   */
  localB->Merge1 = ((rtu_vxn > -5.0) && (rtu_vxn < 5.0));

  /* End of Outputs for SubSystem: '<S117>/true' */
  /* End of Outputs for SubSystem: '<S117>/false' */
}

/*
 * System initialize for atomic system:
 *    '<S145>/Chart2'
 *    '<S159>/Chart2'
 *    '<S173>/Chart2'
 */
void npc_controller_Chart2_Init(rtB_Chart2_npc_controller *localB,
  rtDW_Chart2_npc_controller *localDW)
{
  localDW->is_active_c44_npc_controller = 0U;
  localDW->is_c44_npc_controller = npc_controll_IN_NO_ACTIVE_CHILD;
  localB->PWM_burst_en = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S145>/Chart2'
 *    '<S159>/Chart2'
 *    '<S173>/Chart2'
 */
void npc_controller_Chart2_Reset(rtB_Chart2_npc_controller *localB,
  rtDW_Chart2_npc_controller *localDW)
{
  localDW->is_active_c44_npc_controller = 0U;
  localDW->is_c44_npc_controller = npc_controll_IN_NO_ACTIVE_CHILD;
  localB->PWM_burst_en = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S145>/Chart2'
 *    '<S159>/Chart2'
 *    '<S173>/Chart2'
 */
void npc_controller_Chart2(real32_T rtu_I_ref, real32_T rtu_zc, real32_T
  rtu_I_th, rtB_Chart2_npc_controller *localB, rtDW_Chart2_npc_controller
  *localDW)
{
  /* Chart: '<S145>/Chart2' */
  /* Gateway: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/Chart2 */
  /* During: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/Chart2 */
  if (localDW->is_active_c44_npc_controller == 0U) {
    /* Entry: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/Chart2 */
    localDW->is_active_c44_npc_controller = 1U;

    /* Entry Internal: CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/Chart2 */
    /* Transition: '<S146>:2' */
    localDW->is_c44_npc_controller = npc_controller_IN_Contineous;

    /* Entry 'Contineous': '<S146>:1' */
    localB->PWM_burst_en = 1.0F;
  } else if (localDW->is_c44_npc_controller == 1U) {
    /* During 'Burst': '<S146>:3' */
    if ((rtu_I_ref > rtu_I_th + 25.0F) && (rtu_zc > 0.0F)) {
      /* Transition: '<S146>:6' */
      localDW->is_c44_npc_controller = npc_controller_IN_Contineous;

      /* Entry 'Contineous': '<S146>:1' */
      localB->PWM_burst_en = 1.0F;
    } else {
      localB->PWM_burst_en = 0.0F;
    }

    /* During 'Contineous': '<S146>:1' */
  } else if ((rtu_I_ref < rtu_I_th) && (rtu_zc > 0.0F)) {
    /* Transition: '<S146>:4' */
    localDW->is_c44_npc_controller = npc_controller_IN_Burst;

    /* Entry 'Burst': '<S146>:3' */
    localB->PWM_burst_en = 0.0F;
  } else {
    localB->PWM_burst_en = 1.0F;
  }

  /* End of Chart: '<S145>/Chart2' */
}

/*
 * Output and update for atomic system:
 *    '<S226>/Bit Shift'
 *    '<S227>/Bit Shift'
 *    '<S228>/Bit Shift'
 *    '<S235>/Bit Shift'
 *    '<S236>/Bit Shift'
 *    '<S237>/Bit Shift'
 *    '<S249>/Bit Shift'
 *    '<S250>/Bit Shift'
 *    '<S251>/Bit Shift'
 *    '<S253>/Bit Shift'
 *    ...
 */
void npc_controller_BitShift(uint16_T rtu_u, rtB_BitShift_npc_controller *localB)
{
  /* MATLAB Function: '<S229>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S230>:1' */
  /* '<S230>:1:8' */
  localB->y = rtu_u >> 8;
}

/* Output and update for function-call system: '<S187>/CAN_Task' */
void npc_controller_CAN_Task(boolean_T *rtd_b00_DebugEnabled, boolean_T
  *rtd_b01_ReadRequest, boolean_T *rtd_b05_MB10Received, boolean_T
  *rtd_b06_MB11Received, boolean_T *rtd_b07_MB12Received, const real32_T
  *rtd_f32IinA, const real32_T *rtd_f32IinB, const real32_T *rtd_f32IinC,
  real32_T *rtd_f32IoutTarget, const real32_T *rtd_f32IphaseA, const real32_T
  *rtd_f32IphaseB, const real32_T *rtd_f32IphaseC, real32_T *rtd_f32V2GPwrTarget,
  const real32_T *rtd_f32Vaux, const real32_T *rtd_f32VinA, const real32_T
  *rtd_f32VinB, const real32_T *rtd_f32VinC, real32_T *rtd_f32VoutTarget, const
  real32_T *rtd_f32Vpfc, const real32_T *rtd_f32VpfcMid, const uint16_T
  *rtd_sPriFault, const uint16_T *rtd_sPriStatus, const uint16_T *rtd_u16Debug0,
  const uint16_T *rtd_u16Debug1, const uint16_T *rtd_u16Debug2, const uint16_T
  *rtd_u16Debug3, const uint16_T *rtd_u16Debug4, const uint16_T *rtd_u16Debug5,
  const uint16_T *rtd_u16Reserved1, uint16_T *rtd_u16TxDelayCount, uint16_T
  *rtd_u8AliveCounter, const uint16_T rtd_u8CanDataRx10[8], const uint16_T
  rtd_u8CanDataRx11[8], const uint16_T rtd_u8CanDataRx12[8], uint16_T
  *rtd_u8CanTxIndex, const uint16_T rtd_u8FwRevData[8], uint16_T
  *rtd_u8GridPhaseType, uint16_T *rtd_u8ModeCmd, uint16_T *rtd_u8PriFutEnable,
  uint16_T *rtd_u8RdReqMsgPntr, uint16_T *rtd_u8RedunModeCmd, const uint16_T
  *rtd_u8Reserved1, uint16_T *rtd_u8SinglePhaseLeg, const uint16_T
  *rtd_u8TclllcP1, const uint16_T *rtd_u8TclllcP2, const uint16_T
  *rtd_u8ThermalFlags, const uint16_T *rtd_u8TnpcA, const uint16_T *rtd_u8TnpcB,
  const uint16_T *rtd_u8TnpcC, rtB_CAN_Task_npc_controller *localB)
{
  real32_T tmp;
  int16_T i;
  uint16_T rtb_y_a;

  /* S-Function (fcgen): '<S188>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S188>/Rx_Handler'
   */
  /* If: '<S193>/If' */
  if (*rtd_b05_MB10Received) {
    /* Outputs for IfAction SubSystem: '<S193>/ ProcessMB10' incorporates:
     *  ActionPort: '<S195>/Action Port'
     */
    /* DataStoreWrite: '<S195>/Data Store Write2' incorporates:
     *  Constant: '<S195>/Constant'
     *  Constant: '<S195>/Constant3'
     *  Constant: '<S195>/Constant4'
     *  DataStoreRead: '<S195>/Data Store Read'
     *  DataTypeConversion: '<S195>/Data Type Conversion3'
     *  DataTypeConversion: '<S195>/Data Type Conversion4'
     *  Gain: '<S195>/Multiply1'
     *  Product: '<S195>/Divide'
     *  Selector: '<S195>/Selector2'
     *  Selector: '<S195>/Selector3'
     *  Sum: '<S195>/Sum'
     */
    *rtd_f32VoutTarget = (real32_T)((real32_T)(((uint32_T)rtd_u8CanDataRx10[2] <<
      7U) + ((uint32_T)rtd_u8CanDataRx10[3] << 15U)) * 0.0078125F / 10.0);

    /* DataStoreWrite: '<S195>/Data Store Write3' incorporates:
     *  Constant: '<S195>/Constant5'
     *  Constant: '<S195>/Constant6'
     *  Constant: '<S195>/Constant7'
     *  DataStoreRead: '<S195>/Data Store Read'
     *  DataTypeConversion: '<S195>/Data Type Conversion7'
     *  DataTypeConversion: '<S195>/Data Type Conversion8'
     *  Gain: '<S195>/Multiply2'
     *  Product: '<S195>/Divide1'
     *  Selector: '<S195>/Selector4'
     *  Selector: '<S195>/Selector5'
     *  Sum: '<S195>/Sum1'
     */
    *rtd_f32IoutTarget = (real32_T)((real32_T)(((uint32_T)rtd_u8CanDataRx10[4] <<
      7U) + ((uint32_T)rtd_u8CanDataRx10[5] << 15U)) * 0.0078125F / 100.0);

    /* DataStoreWrite: '<S195>/Data Store Write4' incorporates:
     *  Constant: '<S195>/Constant10'
     *  Constant: '<S195>/Constant9'
     *  DataStoreRead: '<S195>/Data Store Read'
     *  DataTypeConversion: '<S195>/Data Type Conversion11'
     *  Gain: '<S195>/Multiply3'
     *  Selector: '<S195>/Selector6'
     *  Selector: '<S195>/Selector7'
     *  Sum: '<S195>/Sum2'
     */
    *rtd_f32V2GPwrTarget = (real32_T)(((uint32_T)rtd_u8CanDataRx10[6] << 7U) +
      ((uint32_T)rtd_u8CanDataRx10[7] << 15U)) * 0.0078125F;

    /* DataStoreWrite: '<S195>/Data Store Write1' incorporates:
     *  Constant: '<S195>/Constant1'
     */
    *rtd_b05_MB10Received = false;

    /* Outputs for Atomic SubSystem: '<S195>/Bit Shift' */
    /* MATLAB Function: '<S199>/bit_shift' incorporates:
     *  Constant: '<S195>/Constant11'
     *  DataStoreRead: '<S195>/Data Store Read'
     *  S-Function (sfix_bitop): '<S195>/Bitwise AND1'
     *  Selector: '<S195>/Selector8'
     */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S206>:1' */
    /* '<S206>:1:8' */
    rtb_y_a = (rtd_u8CanDataRx10[1] & 14U) >> 1;

    /* End of Outputs for SubSystem: '<S195>/Bit Shift' */

    /* If: '<S195>/If2' */
    if (rtb_y_a == 1U) {
      /* Outputs for IfAction SubSystem: '<S195>/Leg A' incorporates:
       *  ActionPort: '<S200>/Action Port'
       */
      /* DataStoreWrite: '<S200>/Data Store Write1' incorporates:
       *  Constant: '<S200>/Leg A'
       */
      *rtd_u8SinglePhaseLeg = 1U;

      /* End of Outputs for SubSystem: '<S195>/Leg A' */
    } else if (rtb_y_a == 2U) {
      /* Outputs for IfAction SubSystem: '<S195>/Leg B' incorporates:
       *  ActionPort: '<S201>/Action Port'
       */
      /* DataStoreWrite: '<S201>/Data Store Write1' incorporates:
       *  Constant: '<S201>/Leg B'
       */
      *rtd_u8SinglePhaseLeg = 2U;

      /* End of Outputs for SubSystem: '<S195>/Leg B' */
    } else if (rtb_y_a == 3U) {
      /* Outputs for IfAction SubSystem: '<S195>/Leg C' incorporates:
       *  ActionPort: '<S202>/Action Port'
       */
      /* DataStoreWrite: '<S202>/Data Store Write1' incorporates:
       *  Constant: '<S202>/Leg C'
       */
      *rtd_u8SinglePhaseLeg = 3U;

      /* End of Outputs for SubSystem: '<S195>/Leg C' */
    } else if (rtb_y_a == 4U) {
      /* Outputs for IfAction SubSystem: '<S195>/All Legs' incorporates:
       *  ActionPort: '<S198>/Action Port'
       */
      /* DataStoreWrite: '<S198>/Data Store Write1' incorporates:
       *  Constant: '<S198>/Leg All'
       */
      *rtd_u8SinglePhaseLeg = 4U;

      /* End of Outputs for SubSystem: '<S195>/All Legs' */
    }

    /* End of If: '<S195>/If2' */

    /* If: '<S195>/If' incorporates:
     *  Constant: '<S195>/Constant2'
     *  DataStoreRead: '<S195>/Data Store Read'
     *  Logic: '<S195>/OR'
     *  RelationalOperator: '<S195>/Equal'
     *  RelationalOperator: '<S195>/Equal1'
     *  RelationalOperator: '<S195>/Equal2'
     *  RelationalOperator: '<S195>/Equal3'
     *  RelationalOperator: '<S195>/Equal4'
     *  Selector: '<S195>/Selector1'
     */
    if ((rtd_u8CanDataRx10[0] == 160U) || (rtd_u8CanDataRx10[0] == 161U) ||
        (rtd_u8CanDataRx10[0] == 162U) || (rtd_u8CanDataRx10[0] == 163U) ||
        (rtd_u8CanDataRx10[0] == 164U)) {
      /* Outputs for IfAction SubSystem: '<S195>/Mode_Cmd' incorporates:
       *  ActionPort: '<S203>/Action Port'
       */
      /* DataStoreWrite: '<S203>/Data Store Write1' */
      *rtd_u8ModeCmd = rtd_u8CanDataRx10[0];

      /* End of Outputs for SubSystem: '<S195>/Mode_Cmd' */
    }

    /* End of If: '<S195>/If' */

    /* Outputs for IfAction SubSystem: '<S195>/Phase Type 3 Phase' incorporates:
     *  ActionPort: '<S205>/Action Port'
     */
    /* Outputs for IfAction SubSystem: '<S195>/Phase Type 1 Phase' incorporates:
     *  ActionPort: '<S204>/Action Port'
     */
    /* If: '<S195>/If1' incorporates:
     *  Constant: '<S195>/Constant11'
     *  DataStoreRead: '<S195>/Data Store Read'
     *  DataStoreWrite: '<S204>/Data Store Write1'
     *  DataStoreWrite: '<S205>/Data Store Write1'
     *  S-Function (sfix_bitop): '<S195>/Bitwise AND'
     *  Selector: '<S195>/Selector8'
     */
    *rtd_u8GridPhaseType = (uint16_T)((rtd_u8CanDataRx10[1] & 1U) == 1U);

    /* End of Outputs for SubSystem: '<S195>/Phase Type 1 Phase' */
    /* End of Outputs for SubSystem: '<S195>/Phase Type 3 Phase' */
    /* End of Outputs for SubSystem: '<S193>/ ProcessMB10' */
  } else if (*rtd_b06_MB11Received) {
    /* Outputs for IfAction SubSystem: '<S193>/ProcessMB11' incorporates:
     *  ActionPort: '<S196>/Action Port'
     */
    /* DataStoreWrite: '<S196>/Data Store Write1' incorporates:
     *  Constant: '<S196>/Constant'
     */
    *rtd_b06_MB11Received = false;

    /* DataStoreWrite: '<S196>/Data Store Write5' incorporates:
     *  Constant: '<S196>/Constant2'
     *  DataStoreRead: '<S196>/Data Store Read'
     *  Selector: '<S196>/Selector1'
     */
    *rtd_u8AliveCounter = rtd_u8CanDataRx11[0];

    /* If: '<S196>/If' incorporates:
     *  Constant: '<S196>/Constant1'
     *  DataStoreRead: '<S196>/Data Store Read'
     *  Logic: '<S196>/OR'
     *  RelationalOperator: '<S196>/Equal'
     *  RelationalOperator: '<S196>/Equal1'
     *  RelationalOperator: '<S196>/Equal2'
     *  RelationalOperator: '<S196>/Equal3'
     *  Selector: '<S196>/Selector2'
     */
    if ((rtd_u8CanDataRx11[1] == 176U) || (rtd_u8CanDataRx11[1] == 177U) ||
        (rtd_u8CanDataRx11[1] == 178U) || (rtd_u8CanDataRx11[1] == 179U)) {
      /* Outputs for IfAction SubSystem: '<S196>/Red_Mode_Cmd' incorporates:
       *  ActionPort: '<S207>/Action Port'
       */
      /* DataStoreWrite: '<S207>/Data Store Write1' */
      *rtd_u8RedunModeCmd = rtd_u8CanDataRx11[1];

      /* End of Outputs for SubSystem: '<S196>/Red_Mode_Cmd' */
    }

    /* End of If: '<S196>/If' */
    /* End of Outputs for SubSystem: '<S193>/ProcessMB11' */
  } else if (*rtd_b07_MB12Received) {
    /* Outputs for IfAction SubSystem: '<S193>/ProcessMB12' incorporates:
     *  ActionPort: '<S197>/Action Port'
     */
    /* DataStoreWrite: '<S197>/Data Store Write1' incorporates:
     *  Constant: '<S197>/Constant'
     */
    *rtd_b07_MB12Received = false;

    /* If: '<S197>/If' incorporates:
     *  Constant: '<S197>/Constant2'
     *  DataStoreRead: '<S197>/Data Store Read'
     *  Selector: '<S197>/Selector1'
     */
    if (rtd_u8CanDataRx12[0] == 0U) {
      /* Outputs for IfAction SubSystem: '<S197>/Debug_Read' incorporates:
       *  ActionPort: '<S209>/Action Port'
       */
      /* If: '<S209>/If' incorporates:
       *  Constant: '<S209>/Constant2'
       *  DataStoreRead: '<S209>/Data Store Read'
       *  Logic: '<S209>/OR'
       *  RelationalOperator: '<S209>/Equal'
       *  RelationalOperator: '<S209>/Equal1'
       *  RelationalOperator: '<S209>/Equal2'
       *  RelationalOperator: '<S209>/Equal3'
       *  Selector: '<S209>/Selector1'
       */
      if ((rtd_u8CanDataRx12[1] == 240U) || (rtd_u8CanDataRx12[1] == 208U) ||
          (rtd_u8CanDataRx12[1] == 209U) || (rtd_u8CanDataRx12[1] == 210U)) {
        /* Outputs for IfAction SubSystem: '<S209>/Debug_Cmd' incorporates:
         *  ActionPort: '<S217>/Action Port'
         */
        /* DataStoreWrite: '<S217>/Data Store Write2' */
        *rtd_u8RdReqMsgPntr = rtd_u8CanDataRx12[1];

        /* DataStoreWrite: '<S217>/Data Store Write1' incorporates:
         *  Constant: '<S217>/Constant'
         */
        *rtd_b01_ReadRequest = true;

        /* End of Outputs for SubSystem: '<S209>/Debug_Cmd' */
      }

      /* End of If: '<S209>/If' */
      /* End of Outputs for SubSystem: '<S197>/Debug_Read' */
    } else if ((rtd_u8CanDataRx12[0] != 1U) && (rtd_u8CanDataRx12[0] == 2U)) {
      /* Outputs for IfAction SubSystem: '<S197>/Debug_Cmd' incorporates:
       *  ActionPort: '<S208>/Action Port'
       */
      /* If: '<S208>/If1' incorporates:
       *  Constant: '<S208>/Constant3'
       *  DataStoreRead: '<S208>/Data Store Read1'
       *  Selector: '<S208>/Selector3'
       */
      if (rtd_u8CanDataRx12[1] == 218U) {
        /* Outputs for IfAction SubSystem: '<S208>/Debug En//Dis' incorporates:
         *  ActionPort: '<S211>/Action Port'
         */
        /* If: '<S211>/If' incorporates:
         *  Constant: '<S211>/Constant3'
         *  DataStoreRead: '<S211>/Data Store Read1'
         *  Selector: '<S211>/Selector3'
         */
        if (rtd_u8CanDataRx12[2] == 170U) {
          /* Outputs for IfAction SubSystem: '<S211>/Debug_En' incorporates:
           *  ActionPort: '<S214>/Action Port'
           */
          /* DataStoreWrite: '<S214>/Data Store Write1' incorporates:
           *  Constant: '<S214>/Constant'
           */
          *rtd_b00_DebugEnabled = true;

          /* End of Outputs for SubSystem: '<S211>/Debug_En' */
        } else if (rtd_u8CanDataRx12[2] == 85U) {
          /* Outputs for IfAction SubSystem: '<S211>/Debug_Dis' incorporates:
           *  ActionPort: '<S213>/Action Port'
           */
          /* DataStoreWrite: '<S213>/Data Store Write1' incorporates:
           *  Constant: '<S213>/Constant'
           */
          *rtd_b00_DebugEnabled = false;

          /* End of Outputs for SubSystem: '<S211>/Debug_Dis' */
        }

        /* End of If: '<S211>/If' */
        /* End of Outputs for SubSystem: '<S208>/Debug En//Dis' */
      } else if (rtd_u8CanDataRx12[1] == 219U) {
        /* Outputs for IfAction SubSystem: '<S208>/FUT En Dis' incorporates:
         *  ActionPort: '<S212>/Action Port'
         */
        /* If: '<S212>/If' incorporates:
         *  Constant: '<S212>/Constant3'
         *  DataStoreRead: '<S212>/Data Store Read1'
         *  Selector: '<S212>/Selector3'
         */
        if (rtd_u8CanDataRx12[2] == 187U) {
          /* Outputs for IfAction SubSystem: '<S212>/Enable FUT' incorporates:
           *  ActionPort: '<S216>/Action Port'
           */
          /* DataStoreWrite: '<S216>/Data Store Write1' incorporates:
           *  Constant: '<S216>/Constant'
           */
          *rtd_u8PriFutEnable = 1U;

          /* End of Outputs for SubSystem: '<S212>/Enable FUT' */
        } else if (rtd_u8CanDataRx12[2] == 68U) {
          /* Outputs for IfAction SubSystem: '<S212>/Disable FUT' incorporates:
           *  ActionPort: '<S215>/Action Port'
           */
          /* DataStoreWrite: '<S215>/Data Store Write1' incorporates:
           *  Constant: '<S215>/Constant'
           */
          *rtd_u8PriFutEnable = 0U;

          /* End of Outputs for SubSystem: '<S212>/Disable FUT' */
        }

        /* End of If: '<S212>/If' */
        /* End of Outputs for SubSystem: '<S208>/FUT En Dis' */
      }

      /* End of If: '<S208>/If1' */
      /* End of Outputs for SubSystem: '<S197>/Debug_Cmd' */
    }

    /* End of If: '<S197>/If' */
    /* End of Outputs for SubSystem: '<S193>/ProcessMB12' */
  }

  /* End of If: '<S193>/If' */

  /* S-Function (fcgen): '<S188>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S188>/Tx_Handler'
   */
  /* Sum: '<S218>/FixPt Sum1' incorporates:
   *  Constant: '<S218>/FixPt Constant'
   */
  rtb_y_a = *rtd_u16TxDelayCount + 1U;

  /* DataStoreWrite: '<S194>/Data Store Write1' incorporates:
   *  Constant: '<S218>/FixPt Constant'
   *  Sum: '<S218>/FixPt Sum1'
   */
  (*rtd_u16TxDelayCount)++;

  /* If: '<S194>/If2' incorporates:
   *  Constant: '<S194>/Constant4'
   */
  if (rtb_y_a == 10U) {
    /* Outputs for IfAction SubSystem: '<S194>/Run Tx Routine' incorporates:
     *  ActionPort: '<S219>/Action Port'
     */
    /* DataStoreWrite: '<S219>/Data Store Write1' incorporates:
     *  Constant: '<S219>/Constant1'
     */
    *rtd_u16TxDelayCount = 0U;

    /* If: '<S219>/If1' */
    if ((*rtd_b01_ReadRequest) && (*rtd_b00_DebugEnabled)) {
      /* Outputs for IfAction SubSystem: '<S219>/TxReadRequest' incorporates:
       *  ActionPort: '<S220>/Action Port'
       */
      /* DataStoreWrite: '<S220>/Data Store Write1' incorporates:
       *  Constant: '<S220>/Constant1'
       */
      *rtd_b01_ReadRequest = false;

      /* SwitchCase: '<S220>/Switch Case' incorporates:
       *  S-Function (sfix_bitop): '<S226>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S227>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S228>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S235>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S236>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S237>/Bitwise AND1'
       */
      switch ((int32_T)*rtd_u8RdReqMsgPntr) {
       case 240L:
        /* Outputs for IfAction SubSystem: '<S220>/ Tx FW Rev ID134' incorporates:
         *  ActionPort: '<S222>/Action Port'
         */
        for (i = 0; i < 8; i++) {
          /* DataStoreRead: '<S222>/Data Store Read2' */
          localB->DataStoreRead2[i] = rtd_u8FwRevData[i];
        }

        /* S-Function (scanpack): '<S222>/CAN Pack1' */
        /* S-Function (scanpack): '<S222>/CAN Pack1' */
        localB->CANPack1_l.ID = 308U;
        localB->CANPack1_l.Length = 8U;
        localB->CANPack1_l.Extended = 0U;
        localB->CANPack1_l.Remote = 0;
        localB->CANPack1_l.Data[0] = 0;
        localB->CANPack1_l.Data[1] = 0;
        localB->CANPack1_l.Data[2] = 0;
        localB->CANPack1_l.Data[3] = 0;
        localB->CANPack1_l.Data[4] = 0;
        localB->CANPack1_l.Data[5] = 0;
        localB->CANPack1_l.Data[6] = 0;
        localB->CANPack1_l.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_l.Data), &localB->DataStoreRead2[0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S222>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_l.Length;
          uint32_T messageID = localB->CANPack1_l.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_l.Data;
          uint16_T isExtended = localB->CANPack1_l.Extended;
          CAN_setupMessageObject(CANA_BASE, 6, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 6, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S220>/ Tx FW Rev ID134' */
        break;

       case 208L:
        break;

       case 209L:
        /* Outputs for IfAction SubSystem: '<S220>/Tx TxDeb Dat1 136' incorporates:
         *  ActionPort: '<S224>/Action Port'
         */
        /* DataTypeConversion: '<S226>/Data Type Conversion' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S226>/Bitwise AND'
         */
        localB->VectorConcatenate_b[0] = *rtd_u16Debug0 & 255U;

        /* Outputs for Atomic SubSystem: '<S226>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug0 & 65280U, &localB->BitShift_j);

        /* End of Outputs for SubSystem: '<S226>/Bit Shift' */

        /* DataTypeConversion: '<S226>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S226>/Bitwise AND1'
         */
        localB->VectorConcatenate_b[1] = localB->BitShift_j.y & 255U;

        /* DataTypeConversion: '<S228>/Data Type Conversion' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S228>/Bitwise AND'
         */
        localB->VectorConcatenate_b[2] = *rtd_u16Debug1 & 255U;

        /* Outputs for Atomic SubSystem: '<S228>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug1 & 65280U, &localB->BitShift_p);

        /* End of Outputs for SubSystem: '<S228>/Bit Shift' */

        /* DataTypeConversion: '<S228>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S228>/Bitwise AND1'
         */
        localB->VectorConcatenate_b[3] = localB->BitShift_p.y & 255U;

        /* DataTypeConversion: '<S227>/Data Type Conversion' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S227>/Bitwise AND'
         */
        localB->VectorConcatenate_b[4] = *rtd_u16Debug2 & 255U;

        /* Outputs for Atomic SubSystem: '<S227>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug2 & 65280U, &localB->BitShift_ji);

        /* End of Outputs for SubSystem: '<S227>/Bit Shift' */

        /* DataTypeConversion: '<S227>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S227>/Bitwise AND1'
         */
        localB->VectorConcatenate_b[5] = localB->BitShift_ji.y & 255U;

        /* SignalConversion generated from: '<S224>/Vector Concatenate' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  Constant: '<S224>/Constant4'
         */
        localB->VectorConcatenate_b[6] = 0U;

        /* SignalConversion generated from: '<S224>/Vector Concatenate' incorporates:
         *  Concatenate: '<S224>/Vector Concatenate'
         *  Constant: '<S224>/Constant4'
         */
        localB->VectorConcatenate_b[7] = 0U;

        /* S-Function (scanpack): '<S224>/CAN Pack1' */
        /* S-Function (scanpack): '<S224>/CAN Pack1' */
        localB->CANPack1_k.ID = 310U;
        localB->CANPack1_k.Length = 8U;
        localB->CANPack1_k.Extended = 0U;
        localB->CANPack1_k.Remote = 0;
        localB->CANPack1_k.Data[0] = 0;
        localB->CANPack1_k.Data[1] = 0;
        localB->CANPack1_k.Data[2] = 0;
        localB->CANPack1_k.Data[3] = 0;
        localB->CANPack1_k.Data[4] = 0;
        localB->CANPack1_k.Data[5] = 0;
        localB->CANPack1_k.Data[6] = 0;
        localB->CANPack1_k.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_k.Data), &localB->VectorConcatenate_b
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S224>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_k.Length;
          uint32_T messageID = localB->CANPack1_k.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_k.Data;
          uint16_T isExtended = localB->CANPack1_k.Extended;
          CAN_setupMessageObject(CANA_BASE, 8, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 8, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S220>/Tx TxDeb Dat1 136' */
        break;

       case 210L:
        /* Outputs for IfAction SubSystem: '<S220>/Tx TxDeb Dat2 137' incorporates:
         *  ActionPort: '<S225>/Action Port'
         */
        /* DataTypeConversion: '<S235>/Data Type Conversion' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S235>/Bitwise AND'
         */
        localB->VectorConcatenate_o[0] = *rtd_u16Debug3 & 255U;

        /* Outputs for Atomic SubSystem: '<S235>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug3 & 65280U, &localB->BitShift_e);

        /* End of Outputs for SubSystem: '<S235>/Bit Shift' */

        /* DataTypeConversion: '<S235>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S235>/Bitwise AND1'
         */
        localB->VectorConcatenate_o[1] = localB->BitShift_e.y & 255U;

        /* DataTypeConversion: '<S237>/Data Type Conversion' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S237>/Bitwise AND'
         */
        localB->VectorConcatenate_o[2] = *rtd_u16Debug4 & 255U;

        /* Outputs for Atomic SubSystem: '<S237>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug4 & 65280U, &localB->BitShift_eq);

        /* End of Outputs for SubSystem: '<S237>/Bit Shift' */

        /* DataTypeConversion: '<S237>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S237>/Bitwise AND1'
         */
        localB->VectorConcatenate_o[3] = localB->BitShift_eq.y & 255U;

        /* DataTypeConversion: '<S236>/Data Type Conversion' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S236>/Bitwise AND'
         */
        localB->VectorConcatenate_o[4] = *rtd_u16Debug5 & 255U;

        /* Outputs for Atomic SubSystem: '<S236>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Debug5 & 65280U, &localB->BitShift_f);

        /* End of Outputs for SubSystem: '<S236>/Bit Shift' */

        /* DataTypeConversion: '<S236>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S236>/Bitwise AND1'
         */
        localB->VectorConcatenate_o[5] = localB->BitShift_f.y & 255U;

        /* SignalConversion generated from: '<S225>/Vector Concatenate' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  Constant: '<S225>/Constant4'
         */
        localB->VectorConcatenate_o[6] = 0U;

        /* SignalConversion generated from: '<S225>/Vector Concatenate' incorporates:
         *  Concatenate: '<S225>/Vector Concatenate'
         *  Constant: '<S225>/Constant4'
         */
        localB->VectorConcatenate_o[7] = 0U;

        /* S-Function (scanpack): '<S225>/CAN Pack1' */
        /* S-Function (scanpack): '<S225>/CAN Pack1' */
        localB->CANPack1_h.ID = 311U;
        localB->CANPack1_h.Length = 8U;
        localB->CANPack1_h.Extended = 0U;
        localB->CANPack1_h.Remote = 0;
        localB->CANPack1_h.Data[0] = 0;
        localB->CANPack1_h.Data[1] = 0;
        localB->CANPack1_h.Data[2] = 0;
        localB->CANPack1_h.Data[3] = 0;
        localB->CANPack1_h.Data[4] = 0;
        localB->CANPack1_h.Data[5] = 0;
        localB->CANPack1_h.Data[6] = 0;
        localB->CANPack1_h.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_h.Data), &localB->VectorConcatenate_o
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S225>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_h.Length;
          uint32_T messageID = localB->CANPack1_h.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_h.Data;
          uint16_T isExtended = localB->CANPack1_h.Extended;
          CAN_setupMessageObject(CANA_BASE, 9, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 9, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S220>/Tx TxDeb Dat2 137' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of SwitchCase: '<S220>/Switch Case' */
      /* End of Outputs for SubSystem: '<S219>/TxReadRequest' */
    } else {
      /* Outputs for IfAction SubSystem: '<S219>/TxStatusData' incorporates:
       *  ActionPort: '<S221>/Action Port'
       */
      /* SwitchCase: '<S221>/Switch Case' incorporates:
       *  S-Function (sfix_bitop): '<S249>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S250>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S251>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S253>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S262>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S263>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S264>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S271>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S272>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S273>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S274>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S283>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S284>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S285>/Bitwise AND1'
       *  S-Function (sfix_bitop): '<S286>/Bitwise AND1'
       */
      switch ((int32_T)*rtd_u8CanTxIndex) {
       case 0L:
        /* Outputs for IfAction SubSystem: '<S221>/Tx Pri Status ID110' incorporates:
         *  ActionPort: '<S244>/Action Port'
         */
        /* DataTypeConversion: '<S253>/Data Type Conversion' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S253>/Bitwise AND'
         */
        localB->VectorConcatenate_c[0] = *rtd_sPriStatus & 255U;

        /* Outputs for Atomic SubSystem: '<S253>/Bit Shift' */
        npc_controller_BitShift(*rtd_sPriStatus & 65280U, &localB->BitShift_ed);

        /* End of Outputs for SubSystem: '<S253>/Bit Shift' */

        /* DataTypeConversion: '<S253>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S253>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[1] = localB->BitShift_ed.y & 255U;

        /* DataTypeConversion: '<S249>/Data Type Conversion2' incorporates:
         *  Constant: '<S244>/Constant1'
         *  Product: '<S249>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VinA / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S249>/Data Type Conversion2' */

        /* DataTypeConversion: '<S249>/Data Type Conversion' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S249>/Bitwise AND'
         */
        localB->VectorConcatenate_c[2] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S249>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_o);

        /* End of Outputs for SubSystem: '<S249>/Bit Shift' */

        /* DataTypeConversion: '<S249>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S249>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[3] = localB->BitShift_o.y & 255U;

        /* DataTypeConversion: '<S250>/Data Type Conversion2' incorporates:
         *  Constant: '<S244>/Constant3'
         *  Product: '<S250>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IinA / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S250>/Data Type Conversion2' */

        /* DataTypeConversion: '<S250>/Data Type Conversion' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S250>/Bitwise AND'
         */
        localB->VectorConcatenate_c[4] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S250>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_pb);

        /* End of Outputs for SubSystem: '<S250>/Bit Shift' */

        /* DataTypeConversion: '<S250>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S250>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[5] = localB->BitShift_pb.y & 255U;

        /* DataTypeConversion: '<S251>/Data Type Conversion2' incorporates:
         *  Constant: '<S244>/Constant4'
         *  Product: '<S251>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VpfcMid / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S251>/Data Type Conversion2' */

        /* DataTypeConversion: '<S251>/Data Type Conversion' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S251>/Bitwise AND'
         */
        localB->VectorConcatenate_c[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S251>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_d);

        /* End of Outputs for SubSystem: '<S251>/Bit Shift' */

        /* DataTypeConversion: '<S251>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S244>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S251>/Bitwise AND1'
         */
        localB->VectorConcatenate_c[7] = localB->BitShift_d.y & 255U;

        /* S-Function (scanpack): '<S244>/CAN Pack1' */
        /* S-Function (scanpack): '<S244>/CAN Pack1' */
        localB->CANPack1_c.ID = 272U;
        localB->CANPack1_c.Length = 8U;
        localB->CANPack1_c.Extended = 0U;
        localB->CANPack1_c.Remote = 0;
        localB->CANPack1_c.Data[0] = 0;
        localB->CANPack1_c.Data[1] = 0;
        localB->CANPack1_c.Data[2] = 0;
        localB->CANPack1_c.Data[3] = 0;
        localB->CANPack1_c.Data[4] = 0;
        localB->CANPack1_c.Data[5] = 0;
        localB->CANPack1_c.Data[6] = 0;
        localB->CANPack1_c.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_c.Data), &localB->VectorConcatenate_c
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S244>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_c.Length;
          uint32_T messageID = localB->CANPack1_c.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_c.Data;
          uint16_T isExtended = localB->CANPack1_c.Extended;
          CAN_setupMessageObject(CANA_BASE, 1, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 1, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* If: '<S244>/If1' */
        if (*rtd_b00_DebugEnabled) {
          /* Outputs for IfAction SubSystem: '<S244>/TxReadRequest' incorporates:
           *  ActionPort: '<S252>/Action Port'
           */
          /* DataStoreWrite: '<S252>/Data Store Write1' incorporates:
           *  Constant: '<S252>/Constant1'
           */
          *rtd_u8CanTxIndex = 1U;

          /* End of Outputs for SubSystem: '<S244>/TxReadRequest' */
        }

        /* End of If: '<S244>/If1' */
        /* End of Outputs for SubSystem: '<S221>/Tx Pri Status ID110' */
        break;

       case 1L:
        /* Outputs for IfAction SubSystem: '<S221>/Tx Pri1 ID130' incorporates:
         *  ActionPort: '<S245>/Action Port'
         */
        /* DataStoreWrite: '<S245>/Data Store Write1' incorporates:
         *  Constant: '<S245>/Constant1'
         */
        *rtd_u8CanTxIndex = 2U;

        /* DataTypeConversion: '<S263>/Data Type Conversion' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S263>/Bitwise AND'
         */
        localB->VectorConcatenate_g[0] = *rtd_sPriFault & 255U;

        /* Outputs for Atomic SubSystem: '<S263>/Bit Shift' */
        npc_controller_BitShift(*rtd_sPriFault & 65280U, &localB->BitShift_i);

        /* End of Outputs for SubSystem: '<S263>/Bit Shift' */

        /* DataTypeConversion: '<S263>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S263>/Bitwise AND1'
         */
        localB->VectorConcatenate_g[1] = localB->BitShift_i.y & 255U;

        /* DataStoreRead: '<S245>/Data Store Read2' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         */
        localB->VectorConcatenate_g[2] = *rtd_u8ThermalFlags;

        /* DataStoreRead: '<S245>/Data Store Read4' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         */
        localB->VectorConcatenate_g[3] = *rtd_u8Reserved1;

        /* DataTypeConversion: '<S264>/Data Type Conversion' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S264>/Bitwise AND'
         */
        localB->VectorConcatenate_g[4] = *rtd_u16Reserved1 & 255U;

        /* Outputs for Atomic SubSystem: '<S264>/Bit Shift' */
        npc_controller_BitShift(*rtd_u16Reserved1 & 65280U, &localB->BitShift_c);

        /* End of Outputs for SubSystem: '<S264>/Bit Shift' */

        /* DataTypeConversion: '<S264>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S264>/Bitwise AND1'
         */
        localB->VectorConcatenate_g[5] = localB->BitShift_c.y & 255U;

        /* DataTypeConversion: '<S262>/Data Type Conversion2' incorporates:
         *  Constant: '<S245>/Constant4'
         *  Product: '<S262>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32Vaux / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S262>/Data Type Conversion2' */

        /* DataTypeConversion: '<S262>/Data Type Conversion' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S262>/Bitwise AND'
         */
        localB->VectorConcatenate_g[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S262>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_g);

        /* End of Outputs for SubSystem: '<S262>/Bit Shift' */

        /* DataTypeConversion: '<S262>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S245>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S262>/Bitwise AND1'
         */
        localB->VectorConcatenate_g[7] = localB->BitShift_g.y & 255U;

        /* S-Function (scanpack): '<S245>/CAN Pack1' */
        /* S-Function (scanpack): '<S245>/CAN Pack1' */
        localB->CANPack1_i.ID = 304U;
        localB->CANPack1_i.Length = 8U;
        localB->CANPack1_i.Extended = 0U;
        localB->CANPack1_i.Remote = 0;
        localB->CANPack1_i.Data[0] = 0;
        localB->CANPack1_i.Data[1] = 0;
        localB->CANPack1_i.Data[2] = 0;
        localB->CANPack1_i.Data[3] = 0;
        localB->CANPack1_i.Data[4] = 0;
        localB->CANPack1_i.Data[5] = 0;
        localB->CANPack1_i.Data[6] = 0;
        localB->CANPack1_i.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_i.Data), &localB->VectorConcatenate_g
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S245>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_i.Length;
          uint32_T messageID = localB->CANPack1_i.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_i.Data;
          uint16_T isExtended = localB->CANPack1_i.Extended;
          CAN_setupMessageObject(CANA_BASE, 2, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 2, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S221>/Tx Pri1 ID130' */
        break;

       case 2L:
        /* Outputs for IfAction SubSystem: '<S221>/Tx Pri2 ID131' incorporates:
         *  ActionPort: '<S246>/Action Port'
         */
        /* DataStoreWrite: '<S246>/Data Store Write1' incorporates:
         *  Constant: '<S246>/Constant1'
         */
        *rtd_u8CanTxIndex = 3U;

        /* DataTypeConversion: '<S274>/Data Type Conversion2' incorporates:
         *  Constant: '<S246>/Constant5'
         *  Product: '<S274>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VinB / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S274>/Data Type Conversion2' */

        /* DataTypeConversion: '<S274>/Data Type Conversion' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S274>/Bitwise AND'
         */
        localB->VectorConcatenate_e[0] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S274>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_a);

        /* End of Outputs for SubSystem: '<S274>/Bit Shift' */

        /* DataTypeConversion: '<S274>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S274>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[1] = localB->BitShift_a.y & 255U;

        /* DataTypeConversion: '<S271>/Data Type Conversion2' incorporates:
         *  Constant: '<S246>/Constant2'
         *  Product: '<S271>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32VinC / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S271>/Data Type Conversion2' */

        /* DataTypeConversion: '<S271>/Data Type Conversion' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S271>/Bitwise AND'
         */
        localB->VectorConcatenate_e[2] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S271>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_du);

        /* End of Outputs for SubSystem: '<S271>/Bit Shift' */

        /* DataTypeConversion: '<S271>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S271>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[3] = localB->BitShift_du.y & 255U;

        /* DataTypeConversion: '<S272>/Data Type Conversion2' incorporates:
         *  Constant: '<S246>/Constant3'
         *  Product: '<S272>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IinB / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S272>/Data Type Conversion2' */

        /* DataTypeConversion: '<S272>/Data Type Conversion' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S272>/Bitwise AND'
         */
        localB->VectorConcatenate_e[4] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S272>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_b);

        /* End of Outputs for SubSystem: '<S272>/Bit Shift' */

        /* DataTypeConversion: '<S272>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S272>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[5] = localB->BitShift_b.y & 255U;

        /* DataTypeConversion: '<S273>/Data Type Conversion2' incorporates:
         *  Constant: '<S246>/Constant4'
         *  Product: '<S273>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IinC / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S273>/Data Type Conversion2' */

        /* DataTypeConversion: '<S273>/Data Type Conversion' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S273>/Bitwise AND'
         */
        localB->VectorConcatenate_e[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S273>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_ij);

        /* End of Outputs for SubSystem: '<S273>/Bit Shift' */

        /* DataTypeConversion: '<S273>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S246>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S273>/Bitwise AND1'
         */
        localB->VectorConcatenate_e[7] = localB->BitShift_ij.y & 255U;

        /* S-Function (scanpack): '<S246>/CAN Pack1' */
        /* S-Function (scanpack): '<S246>/CAN Pack1' */
        localB->CANPack1_g.ID = 305U;
        localB->CANPack1_g.Length = 8U;
        localB->CANPack1_g.Extended = 0U;
        localB->CANPack1_g.Remote = 0;
        localB->CANPack1_g.Data[0] = 0;
        localB->CANPack1_g.Data[1] = 0;
        localB->CANPack1_g.Data[2] = 0;
        localB->CANPack1_g.Data[3] = 0;
        localB->CANPack1_g.Data[4] = 0;
        localB->CANPack1_g.Data[5] = 0;
        localB->CANPack1_g.Data[6] = 0;
        localB->CANPack1_g.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_g.Data), &localB->VectorConcatenate_e
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S246>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_g.Length;
          uint32_T messageID = localB->CANPack1_g.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_g.Data;
          uint16_T isExtended = localB->CANPack1_g.Extended;
          CAN_setupMessageObject(CANA_BASE, 3, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 3, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S221>/Tx Pri2 ID131' */
        break;

       case 3L:
        /* Outputs for IfAction SubSystem: '<S221>/Tx Pri3 ID132' incorporates:
         *  ActionPort: '<S247>/Action Port'
         */
        /* DataStoreWrite: '<S247>/Data Store Write1' incorporates:
         *  Constant: '<S247>/Constant1'
         */
        *rtd_u8CanTxIndex = 4U;

        /* DataTypeConversion: '<S286>/Data Type Conversion2' incorporates:
         *  Constant: '<S247>/Constant5'
         *  Product: '<S286>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IphaseA / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S286>/Data Type Conversion2' */

        /* DataTypeConversion: '<S286>/Data Type Conversion' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S286>/Bitwise AND'
         */
        localB->VectorConcatenate_d[0] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S286>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_ab);

        /* End of Outputs for SubSystem: '<S286>/Bit Shift' */

        /* DataTypeConversion: '<S286>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S286>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[1] = localB->BitShift_ab.y & 255U;

        /* DataTypeConversion: '<S283>/Data Type Conversion2' incorporates:
         *  Constant: '<S247>/Constant2'
         *  Product: '<S283>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IphaseB / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S283>/Data Type Conversion2' */

        /* DataTypeConversion: '<S283>/Data Type Conversion' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S283>/Bitwise AND'
         */
        localB->VectorConcatenate_d[2] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S283>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_jj);

        /* End of Outputs for SubSystem: '<S283>/Bit Shift' */

        /* DataTypeConversion: '<S283>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S283>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[3] = localB->BitShift_jj.y & 255U;

        /* DataTypeConversion: '<S284>/Data Type Conversion2' incorporates:
         *  Constant: '<S247>/Constant3'
         *  Product: '<S284>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32IphaseC / 0.01F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S284>/Data Type Conversion2' */

        /* DataTypeConversion: '<S284>/Data Type Conversion' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S284>/Bitwise AND'
         */
        localB->VectorConcatenate_d[4] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S284>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_g0);

        /* End of Outputs for SubSystem: '<S284>/Bit Shift' */

        /* DataTypeConversion: '<S284>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S284>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[5] = localB->BitShift_g0.y & 255U;

        /* DataTypeConversion: '<S285>/Data Type Conversion2' incorporates:
         *  Constant: '<S247>/Constant4'
         *  Product: '<S285>/Divide'
         */
        tmp = (real32_T)floor(*rtd_f32Vpfc / 0.1F);
        if (rtIsNaNF(tmp) || rtIsInfF(tmp)) {
          tmp = 0.0F;
        } else {
          tmp = (real32_T)fmod(tmp, 65536.0);
        }

        rtb_y_a = tmp < 0.0F ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
          tmp;

        /* End of DataTypeConversion: '<S285>/Data Type Conversion2' */

        /* DataTypeConversion: '<S285>/Data Type Conversion' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S285>/Bitwise AND'
         */
        localB->VectorConcatenate_d[6] = rtb_y_a & 255U;

        /* Outputs for Atomic SubSystem: '<S285>/Bit Shift' */
        npc_controller_BitShift(rtb_y_a & 65280U, &localB->BitShift_cy);

        /* End of Outputs for SubSystem: '<S285>/Bit Shift' */

        /* DataTypeConversion: '<S285>/Data Type Conversion1' incorporates:
         *  Concatenate: '<S247>/Vector Concatenate'
         *  S-Function (sfix_bitop): '<S285>/Bitwise AND1'
         */
        localB->VectorConcatenate_d[7] = localB->BitShift_cy.y & 255U;

        /* S-Function (scanpack): '<S247>/CAN Pack1' */
        /* S-Function (scanpack): '<S247>/CAN Pack1' */
        localB->CANPack1_p.ID = 306U;
        localB->CANPack1_p.Length = 8U;
        localB->CANPack1_p.Extended = 0U;
        localB->CANPack1_p.Remote = 0;
        localB->CANPack1_p.Data[0] = 0;
        localB->CANPack1_p.Data[1] = 0;
        localB->CANPack1_p.Data[2] = 0;
        localB->CANPack1_p.Data[3] = 0;
        localB->CANPack1_p.Data[4] = 0;
        localB->CANPack1_p.Data[5] = 0;
        localB->CANPack1_p.Data[6] = 0;
        localB->CANPack1_p.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1_p.Data), &localB->VectorConcatenate_d
                        [0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S247>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1_p.Length;
          uint32_T messageID = localB->CANPack1_p.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1_p.Data;
          uint16_T isExtended = localB->CANPack1_p.Extended;
          CAN_setupMessageObject(CANA_BASE, 3, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 3, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S221>/Tx Pri3 ID132' */
        break;

       case 4L:
        /* Outputs for IfAction SubSystem: '<S221>/Tx Pri4 ID133' incorporates:
         *  ActionPort: '<S248>/Action Port'
         */
        /* DataStoreWrite: '<S248>/Data Store Write1' incorporates:
         *  Constant: '<S248>/Constant1'
         */
        *rtd_u8CanTxIndex = 0U;

        /* DataStoreRead: '<S248>/Data Store Read1' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         */
        localB->VectorConcatenate[0] = *rtd_u8TnpcA;

        /* DataStoreRead: '<S248>/Data Store Read3' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         */
        localB->VectorConcatenate[1] = *rtd_u8TnpcB;

        /* DataStoreRead: '<S248>/Data Store Read2' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         */
        localB->VectorConcatenate[2] = *rtd_u8TnpcC;

        /* DataStoreRead: '<S248>/Data Store Read6' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         */
        localB->VectorConcatenate[3] = *rtd_u8TclllcP1;

        /* DataStoreRead: '<S248>/Data Store Read4' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         */
        localB->VectorConcatenate[4] = *rtd_u8TclllcP2;

        /* SignalConversion generated from: '<S248>/Vector Concatenate' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         *  Constant: '<S248>/Constant2'
         */
        localB->VectorConcatenate[5] = 0U;

        /* SignalConversion generated from: '<S248>/Vector Concatenate' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         *  Constant: '<S248>/Constant2'
         */
        localB->VectorConcatenate[6] = 0U;

        /* SignalConversion generated from: '<S248>/Vector Concatenate' incorporates:
         *  Concatenate: '<S248>/Vector Concatenate'
         *  Constant: '<S248>/Constant2'
         */
        localB->VectorConcatenate[7] = 0U;

        /* S-Function (scanpack): '<S248>/CAN Pack1' */
        /* S-Function (scanpack): '<S248>/CAN Pack1' */
        localB->CANPack1.ID = 307U;
        localB->CANPack1.Length = 8U;
        localB->CANPack1.Extended = 0U;
        localB->CANPack1.Remote = 0;
        localB->CANPack1.Data[0] = 0;
        localB->CANPack1.Data[1] = 0;
        localB->CANPack1.Data[2] = 0;
        localB->CANPack1.Data[3] = 0;
        localB->CANPack1.Data[4] = 0;
        localB->CANPack1.Data[5] = 0;
        localB->CANPack1.Data[6] = 0;
        localB->CANPack1.Data[7] = 0;

        {
          (void) memcpy((localB->CANPack1.Data), &localB->VectorConcatenate[0],
                        8 * sizeof(uint16_T));
        }

        /* S-Function (c280xcanxmt): '<S248>/eCAN Transmit' */
        {
          uint16_T messageLength = localB->CANPack1.Length;
          uint32_T messageID = localB->CANPack1.ID;
          unsigned char* ucTXMsgData;
          ucTXMsgData = (unsigned char*)localB->CANPack1.Data;
          uint16_T isExtended = localB->CANPack1.Extended;
          CAN_setupMessageObject(CANA_BASE, 4, messageID, isExtended,
            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, messageLength);
          CAN_sendMessage(CANA_BASE, 4, messageLength, (uint16_T*)ucTXMsgData);
        }

        /* End of Outputs for SubSystem: '<S221>/Tx Pri4 ID133' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of SwitchCase: '<S221>/Switch Case' */
      /* End of Outputs for SubSystem: '<S219>/TxStatusData' */
    }

    /* End of If: '<S219>/If1' */
    /* End of Outputs for SubSystem: '<S194>/Run Tx Routine' */
  }

  /* End of If: '<S194>/If2' */
  /* End of Outputs for S-Function (fcgen): '<S188>/Function-Call Generator1' */
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift1'
 *    '<S299>/Bit Shift3'
 */
void npc_controller_BitShift1(uint16_T rtu_u, rtB_BitShift1_npc_controller
  *localB)
{
  /* MATLAB Function: '<S350>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S362>:1' */
  /* '<S362>:1:6' */
  localB->y = rtu_u << 4;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift2'
 *    '<S299>/Bit Shift4'
 */
void npc_controller_BitShift2(uint16_T rtu_u, rtB_BitShift2_npc_controller
  *localB)
{
  /* MATLAB Function: '<S354>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S366>:1' */
  /* '<S366>:1:6' */
  localB->y = rtu_u << 5;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift3'
 *    '<S299>/Bit Shift5'
 */
void npc_controller_BitShift3(uint16_T rtu_u, rtB_BitShift3_npc_controller
  *localB)
{
  /* MATLAB Function: '<S355>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S367>:1' */
  /* '<S367>:1:6' */
  localB->y = rtu_u << 6;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift4'
 *    '<S299>/Bit Shift7'
 */
void npc_controller_BitShift4(uint16_T rtu_u, rtB_BitShift4_npc_controller
  *localB)
{
  /* MATLAB Function: '<S356>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S368>:1' */
  /* '<S368>:1:6' */
  localB->y = rtu_u << 8;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift5'
 *    '<S299>/Bit Shift8'
 */
void npc_controller_BitShift5(uint16_T rtu_u, rtB_BitShift5_npc_controller
  *localB)
{
  /* MATLAB Function: '<S357>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S369>:1' */
  /* '<S369>:1:6' */
  localB->y = rtu_u << 9;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift6'
 *    '<S299>/Bit Shift6'
 */
void npc_controller_BitShift6(uint16_T rtu_u, rtB_BitShift6_npc_controller
  *localB)
{
  /* MATLAB Function: '<S358>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S370>:1' */
  /* '<S370>:1:6' */
  localB->y = rtu_u << 7;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift7'
 *    '<S299>/Bit Shift9'
 */
void npc_controller_BitShift7(uint16_T rtu_u, rtB_BitShift7_npc_controller
  *localB)
{
  /* MATLAB Function: '<S359>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S371>:1' */
  /* '<S371>:1:6' */
  localB->y = rtu_u << 10;
}

/*
 * Output and update for atomic system:
 *    '<S302>/Bit Shift8'
 *    '<S299>/Bit Shift27'
 */
void npc_controller_BitShift8(uint16_T rtu_u, rtB_BitShift8_npc_controller
  *localB)
{
  /* MATLAB Function: '<S360>/bit_shift' */
  /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S372>:1' */
  /* '<S372>:1:6' */
  localB->y = rtu_u << 11;
}

/* System initialize for atomic system: */
void npc_contr_MATLABSystem_Init(rtDW_MATLABSystem_npc_controlle *localDW)
{
  /* Start for MATLABSystem: '<S329>/MATLAB System' */
  localDW->objisempty = true;

  /*  Perform one-time calculations, such as computing constants */
  localDW->obj.status = 0U;
  localDW->obj.ref = 0U;
  localDW->obj.now = 0U;
  localDW->obj.cnt = 0U;

  /* InitializeConditions for MATLABSystem: '<S329>/MATLAB System' */
  /*  Initialize / reset discrete-state properties */
  localDW->status = localDW->obj.status;
  localDW->ref = localDW->obj.status;
  localDW->now = localDW->obj.status;
  localDW->cnt = localDW->obj.status;
}

/* Output and update for atomic system: */
void npc_controller_MATLABSystem(uint16_T rtu_0, uint16_T rtu_1, uint16_T rtu_2,
  uint16_T rtu_5, rtB_MATLABSystem_npc_controller *localB,
  rtDW_MATLABSystem_npc_controlle *localDW)
{
  uint16_T qY;

  /* MATLABSystem: '<S329>/MATLAB System' */
  /*  Implement algorithm. Calculate y as a function of input u and */
  /*  discrete states. */
  /* if(assert_lim>deassert_lim) %assert above */
  if (rtu_0 >= rtu_1) {
    localDW->obj.now = rtu_5;
    qY = localDW->obj.now - localDW->obj.ref;
    if (qY > localDW->obj.now) {
      qY = 0U;
    }

    localDW->obj.cnt = qY;
    if (localDW->obj.cnt > rtu_2) {
      localDW->obj.status = 1U;
      localDW->obj.cnt = 0U;
    }
  } else {
    localDW->obj.ref = rtu_5;
  }

  /* MATLABSystem: '<S329>/MATLAB System' */
  /* elseif(assert_lim<deassert_lim) %assert under */
  /*     if(input<=assert_lim) */
  /*         obj.now = tmr; */
  /*         obj.cnt = obj.now - obj.ref; */
  /*         if(obj.cnt>assert_vld) */
  /*             obj.status = uint16(1); */
  /*             obj.cnt = uint16(0); */
  /*         end */
  /*     else */
  /*         obj.ref = tmr; */
  /*     end */
  /* else %invalid case */
  /* end */
  localB->MATLABSystem = localDW->obj.status;

  /* MATLABSystem: '<S329>/MATLAB System' */
  localDW->status = localDW->obj.status;
  localDW->ref = localDW->obj.ref;
  localDW->now = localDW->obj.now;
  localDW->cnt = localDW->obj.cnt;
}

/* Termination for atomic system: */
void npc_contr_MATLABSystem_Term(rtDW_MATLABSystem_npc_controlle *localDW)
{
  /* Terminate for MATLABSystem: '<S329>/MATLAB System' */
  localDW->status = localDW->obj.status;
  localDW->ref = localDW->obj.ref;
  localDW->now = localDW->obj.now;
  localDW->cnt = localDW->obj.cnt;
}

/* Model step function for TID0 */
void npc_controller_step0(void)        /* Explicit Task: timer_1ms */
{
  {                                    /* Explicit Task: timer_1ms */
    rate_monotonic_scheduler();
  }

  /* Outputs for Atomic SubSystem: '<S377>/periodic_timer1' */
  npc_control_periodic_timer1(&npc_controller_DWork.cnt_1ms);

  /* End of Outputs for SubSystem: '<S377>/periodic_timer1' */
}

/* Model step function for TID1 */
void npc_controller_step1(void)        /* Sample time: [0.001s, 0.0s] */
{
  CMPSS_ModuleVal_type COMPModuleValue;
  uint16_T latchoutref;

  /* S-Function (c280xgpio_do): '<S187>/AC_OK_GPIO41' incorporates:
   *  DataStoreRead: '<S187>/Data Store Read2'
   */
  {
    if (npc_controller_DWork.ac_ok) {
      GpioDataRegs.GPBSET.bit.GPIO41 = 1U;
    } else {
      GpioDataRegs.GPBCLEAR.bit.GPIO41 = 1U;
    }
  }

  /* S-Function (c280xgpio_do): '<S187>/RELAY_GPIO4_EPWM3A1' incorporates:
   *  DataStoreRead: '<S187>/Data Store Read'
   */
  {
    if (npc_controller_DWork.relay_ctrl) {
      GpioDataRegs.GPASET.bit.GPIO4 = 1U;
    } else {
      GpioDataRegs.GPACLEAR.bit.GPIO4 = 1U;
    }
  }

  /* S-Function (c280xgpio_do): '<S187>/PFC_OK_GPIO58' incorporates:
   *  DataStoreRead: '<S187>/Data Store Read1'
   */
  {
    if (npc_controller_DWork.pfc_ok) {
      GpioDataRegs.GPBSET.bit.GPIO58 = 1U;
    } else {
      GpioDataRegs.GPBCLEAR.bit.GPIO58 = 1U;
    }
  }

  /* MATLABSystem: '<S374>/CMPSS4H' */
  COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain2, 1U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 1U);

  /* MATLABSystem: '<S374>/CMPSS4L' */
  COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain3, 0U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 0U);

  /* MATLABSystem: '<S374>/CMPSS2H' */
  COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain1, 1U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 1U);

  /* MATLABSystem: '<S374>/CMPSS1H' */
  COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain4, 1U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 1U);

  /* MATLABSystem: '<S374>/CMPSS2L' */
  COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain6, 0U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 0U);

  /* MATLABSystem: '<S374>/CMPSS1L' */
  COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
  MW_CMPSS_DAC_Update(COMPModuleValue, npc_controller_ConstB.Gain5, 0U);
  MW_CMPSS_Status_Update(COMPModuleValue, 0U, &latchoutref, 0U, 0U, 0U);

  /* End of Outputs for S-Function (fcgen): '<S191>/Function-Call Generator1' */
}

/* Model step function for TID2 */
void npc_controller_step2(void)        /* Sample time: [0.02s, 0.0s] */
{
  real32_T f32IoutTarget;
  real32_T f32V2GPwrTarget;
  real32_T f32VoutTarget;
  uint16_T u8AliveCounter;
  uint16_T u8GridPhaseType;
  uint16_T u8ModeCmd;
  uint16_T u8RedunModeCmd;
  uint16_T u8SinglePhaseLeg;

  /* Chart: '<S187>/Chart1' */
  /* Gateway: IDLE_AND_TIMER/codegen/Chart1 */
  /* During: IDLE_AND_TIMER/codegen/Chart1 */
  if (npc_controller_DWork.is_active_c3_npc_controller == 0U) {
    /* Entry: IDLE_AND_TIMER/codegen/Chart1 */
    npc_controller_DWork.is_active_c3_npc_controller = 1U;

    /* Outputs for Function Call SubSystem: '<S187>/CAN_Task' */
    /* Entry Internal: IDLE_AND_TIMER/codegen/Chart1 */
    /* Transition: '<S189>:48' */
    /* Entry 'INIT': '<S189>:45' */
    /* Event: '<S189>:28' */
    npc_controller_CAN_Task(&npc_controller_DWork.b00_DebugEnabled,
      &npc_controller_DWork.b01_ReadRequest,
      &npc_controller_DWork.b05_MB10Received,
      &npc_controller_DWork.b06_MB11Received,
      &npc_controller_DWork.b07_MB12Received, &npc_controller_DWork.f32IinA,
      &npc_controller_DWork.f32IinB, &npc_controller_DWork.f32IinC,
      &f32IoutTarget, &npc_controller_DWork.f32IphaseA,
      &npc_controller_DWork.f32IphaseB, &npc_controller_DWork.f32IphaseC,
      &f32V2GPwrTarget, &npc_controller_DWork.f32Vaux,
      &npc_controller_DWork.f32VinA, &npc_controller_DWork.f32VinB,
      &npc_controller_DWork.f32VinC, &f32VoutTarget,
      &npc_controller_DWork.f32Vpfc, &npc_controller_DWork.f32VpfcMid,
      &npc_controller_DWork.sPriFault, &npc_controller_DWork.sPriStatus,
      &npc_controller_DWork.u16Debug0, &npc_controller_DWork.u16Debug1,
      &npc_controller_DWork.u16Debug2, &npc_controller_DWork.u16Debug3,
      &npc_controller_DWork.u16Debug4, &npc_controller_DWork.u16Debug5,
      &npc_controller_DWork.u16Reserved1, &npc_controller_DWork.u16TxDelayCount,
      &u8AliveCounter, npc_controller_DWork.u8CanDataRx10,
      npc_controller_DWork.u8CanDataRx11, npc_controller_DWork.u8CanDataRx12,
      &npc_controller_DWork.u8CanTxIndex, npc_controller_DWork.u8FwRevData,
      &u8GridPhaseType, &u8ModeCmd, &npc_controller_DWork.u8PriFutEnable,
      &npc_controller_DWork.u8RdReqMsgPntr, &u8RedunModeCmd,
      &npc_controller_DWork.u8Reserved1, &u8SinglePhaseLeg,
      &npc_controller_DWork.u8TclllcP1, &npc_controller_DWork.u8TclllcP2,
      &npc_controller_DWork.u8ThermalFlags, &npc_controller_DWork.u8TnpcA,
      &npc_controller_DWork.u8TnpcB, &npc_controller_DWork.u8TnpcC,
      &npc_controller_B.CAN_Task);

    /* End of Outputs for SubSystem: '<S187>/CAN_Task' */
  } else {
    /* Outputs for Function Call SubSystem: '<S187>/CAN_Task' */
    /* During 'INIT': '<S189>:45' */
    /* Transition: '<S189>:49' */
    /* Entry 'INIT': '<S189>:45' */
    /* Event: '<S189>:28' */
    npc_controller_CAN_Task(&npc_controller_DWork.b00_DebugEnabled,
      &npc_controller_DWork.b01_ReadRequest,
      &npc_controller_DWork.b05_MB10Received,
      &npc_controller_DWork.b06_MB11Received,
      &npc_controller_DWork.b07_MB12Received, &npc_controller_DWork.f32IinA,
      &npc_controller_DWork.f32IinB, &npc_controller_DWork.f32IinC,
      &f32IoutTarget, &npc_controller_DWork.f32IphaseA,
      &npc_controller_DWork.f32IphaseB, &npc_controller_DWork.f32IphaseC,
      &f32V2GPwrTarget, &npc_controller_DWork.f32Vaux,
      &npc_controller_DWork.f32VinA, &npc_controller_DWork.f32VinB,
      &npc_controller_DWork.f32VinC, &f32VoutTarget,
      &npc_controller_DWork.f32Vpfc, &npc_controller_DWork.f32VpfcMid,
      &npc_controller_DWork.sPriFault, &npc_controller_DWork.sPriStatus,
      &npc_controller_DWork.u16Debug0, &npc_controller_DWork.u16Debug1,
      &npc_controller_DWork.u16Debug2, &npc_controller_DWork.u16Debug3,
      &npc_controller_DWork.u16Debug4, &npc_controller_DWork.u16Debug5,
      &npc_controller_DWork.u16Reserved1, &npc_controller_DWork.u16TxDelayCount,
      &u8AliveCounter, npc_controller_DWork.u8CanDataRx10,
      npc_controller_DWork.u8CanDataRx11, npc_controller_DWork.u8CanDataRx12,
      &npc_controller_DWork.u8CanTxIndex, npc_controller_DWork.u8FwRevData,
      &u8GridPhaseType, &u8ModeCmd, &npc_controller_DWork.u8PriFutEnable,
      &npc_controller_DWork.u8RdReqMsgPntr, &u8RedunModeCmd,
      &npc_controller_DWork.u8Reserved1, &u8SinglePhaseLeg,
      &npc_controller_DWork.u8TclllcP1, &npc_controller_DWork.u8TclllcP2,
      &npc_controller_DWork.u8ThermalFlags, &npc_controller_DWork.u8TnpcA,
      &npc_controller_DWork.u8TnpcB, &npc_controller_DWork.u8TnpcC,
      &npc_controller_B.CAN_Task);

    /* End of Outputs for SubSystem: '<S187>/CAN_Task' */
  }

  /* End of Chart: '<S187>/Chart1' */
}

/* Model initialize function */
void npc_controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)npc_controller_M, 0,
                sizeof(RT_MODEL_npc_controller));

  /* block I/O */
  (void) memset(((void *) &npc_controller_B), 0,
                sizeof(BlockIO_npc_controller));

  {
    npc_controller_B.CAN_Task.CANPack1 = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_p = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_g = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_i = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_c = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_h = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_k = CAN_DATATYPE_GROUND;
    npc_controller_B.CAN_Task.CANPack1_l = CAN_DATATYPE_GROUND;
  }

  /* custom signals */
  cpu2cla_angle = 0.0;
  cla2cpu_Vpk = 0.0;
  cpu2cla_ref = 0.0F;
  cla2cpu_Ipk = 0.0F;
  cpu2cla_van = 0.0F;
  cpu2cla_vbn = 0.0F;
  cpu2cla_vcn = 0.0F;
  cpu2cla_ia = 0.0F;
  cpu2cla_ib = 0.0F;
  cpu2cla_ic = 0.0F;
  cpu2cla_vbulk = 0.0F;
  cpu2cla_vmid = 0.0F;
  cpu2cla_control_en = false;
  cpu2cla_pha_en = false;
  cpu2cla_phb_en = false;
  cpu2cla_phc_en = false;
  cpu2cla_pfc_ok2 = false;
  cpu2cla_pol_pha = false;
  cpu2cla_pol_phb = false;
  cpu2cla_pol_phc = false;

  /* states (dwork) */
  (void) memset((void *)&npc_controller_DWork, 0,
                sizeof(D_Work_npc_controller));

  /* custom states */
  vbulk_pid1 = 0.0F;
  vbulk_pid2 = 0.0F;
  vbulk_pid3 = 0.0F;
  vbulk_pid4 = 0.0F;
  vmid_delay1 = 0.0F;
  vmid_delay2 = 0.0F;
  vbulk_delay1 = 0.0F;
  vbulk_delay2 = 0.0F;
  ia_pid3 = 0.0F;
  ia_pid1 = 0.0F;
  ia_pid2 = 0.0F;
  ia_pid4 = 0.0F;
  ib_pid3 = 0.0F;
  ib_pid1 = 0.0F;
  ib_pid2 = 0.0F;
  ib_pid4 = 0.0F;
  ic_pid3 = 0.0F;
  ic_pid1 = 0.0F;
  ic_pid2 = 0.0F;
  ic_pid4 = 0.0F;

  /* external inputs */
  npc_controller_U.sim_adc_quantized = 0.0;

  {
    CMPSS_ModuleVal_type COMPModuleValue;

    /* Start for S-Function (c280xgpio_do): '<S187>/AC_OK_GPIO41' */
    EALLOW;
    GpioCtrlRegs.GPBMUX1.all &= 0xFFF3FFFFU;
    GpioCtrlRegs.GPBDIR.all |= 0x200U;
    EDIS;

    /* Start for S-Function (c280xgpio_do): '<S187>/RELAY_GPIO4_EPWM3A1' */
    EALLOW;
    GpioCtrlRegs.GPAMUX1.all &= 0xFFFFFCFFU;
    GpioCtrlRegs.GPADIR.all |= 0x10U;
    EDIS;

    /* Start for S-Function (c280xgpio_do): '<S187>/PFC_OK_GPIO58' */
    EALLOW;
    GpioCtrlRegs.GPBMUX2.all &= 0xFFCFFFFFU;
    GpioCtrlRegs.GPBDIR.all |= 0x4000000U;
    EDIS;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory28' */
    npc_controller_DWork.cnt_calib = 1U;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget1' */
    npc_controller_DWork.f32GainLineCurrentCS = 0.0412775092F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget2' */
    npc_controller_DWork.f32GainVbulk = 0.226365402F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget3' */
    npc_controller_DWork.f32GainVmid = 0.12730819F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget4' */
    npc_controller_DWork.f32GainLineCurrentHE = 0.0402930416F;

    /* Start for DataStoreMemory: '<Root>/f32IoutTarget6' */
    npc_controller_DWork.f32GainLineVoltage = 0.44794932F;

    /* SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' incorporates:
     *  SubSystem: '<Root>/CONTROL'
     */
    /* System initialize for function-call system: '<Root>/CONTROL' */

    /* SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/GET_ADC'
     */
    /* SystemInitialize for S-Function (fcgen): '<S67>/Function-Call Generator' incorporates:
     *  SubSystem: '<S67>/ADCA'
     */
    /* Start for S-Function (c2802xadc): '<S68>/ADC18' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC0 ();

    /* Start for S-Function (c2802xadc): '<S68>/ADC5' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC4 ();

    /* Start for S-Function (c2802xadc): '<S68>/ADC7' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC3 ();

    /* Start for S-Function (c2802xadc): '<S68>/ADC3' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC2 ();

    /* Start for S-Function (c2802xadc): '<S68>/ADC6' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC5 ();

    /* Start for S-Function (c2802xadc): '<S68>/ADC17' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC6 ();

    /* Start for S-Function (c2802xadc): '<S68>/ADC8' */
    if (MW_adcAInitFlag == 0U) {
      InitAdcA();
      MW_adcAInitFlag = 1U;
    }

    config_ADCA_SOC7 ();

    /* SystemInitialize for S-Function (fcgen): '<S67>/Function-Call Generator' incorporates:
     *  SubSystem: '<S67>/ADCC'
     */
    /* Start for S-Function (c2802xadc): '<S69>/ADC6' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC0 ();

    /* Start for S-Function (c2802xadc): '<S69>/ADC2' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC1 ();

    /* Start for S-Function (c2802xadc): '<S69>/ADC5' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC2 ();

    /* Start for S-Function (c2802xadc): '<S69>/ADC3' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC3 ();

    /* Start for S-Function (c2802xadc): '<S69>/ADC4' */
    if (MW_adcBInitFlag == 0U) {
      InitAdcB();
      MW_adcBInitFlag = 1U;
    }

    config_ADCB_SOC4 ();

    /* End of SystemInitialize for S-Function (fcgen): '<S67>/Function-Call Generator' */

    /* SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/CONTROL'
     */
    /* SystemInitialize for IfAction SubSystem: '<S8>/false' */
    /* SystemInitialize for S-Function (c2000cla): '<S14>/CLA Task1' incorporates:
     *  SubSystem: '<S14>/CLA_CONTROL'
     */
    /* System initialize for function-call system: '<S14>/CLA_CONTROL' */

    /* SystemInitialize for S-Function (fcgen): '<S15>/Function-Call Generator' incorporates:
     *  SubSystem: '<S15>/CONTROL'
     */
    /* Start for S-Function (c2802xpwm): '<S30>/ePWM1 - EXTSYNC1' */

    /*** Initialize ePWM1 modules ***/
    {
      /*  // Time Base Control Register
         EPwm1Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm1Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm1Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm1Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm1Regs.TBCTL.bit.PHSEN                = 0U;          // Phase Load Enable
         EPwm1Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm1Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm1Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm1Regs.TBCTL.all = (EPwm1Regs.TBCTL.all & ~0x3FFFU) | 0x12U;
      EPwm1Regs.TBCTL2.all = (EPwm1Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm1Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm1Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm1Regs.TBPHS.all = (EPwm1Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm1Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm1Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm1Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm1Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm1Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm1Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm1Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm1Regs.CMPCTL.all = (EPwm1Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm1Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm1Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm1Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm1Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm1Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm1Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm1Regs.CMPCTL2.all = (EPwm1Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm1Regs.CMPA.bit.CMPA = 154U;  // Counter Compare A Register
      EPwm1Regs.CMPB.bit.CMPB = 154U;  // Counter Compare B Register
      EPwm1Regs.CMPC = 0U;             // Counter Compare C Register
      EPwm1Regs.CMPD = 0U;             // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm1Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm1Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm1Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm1Regs.AQSFRC.all = (EPwm1Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm1Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm1Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm1Regs.AQCSFRC.all = (EPwm1Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm1Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm1Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm1Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm1Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm1Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm1Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm1Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm1Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm1Regs.DBCTL.all = (EPwm1Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm1Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm1Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm1Regs.ETSEL.bit.SOCAEN               = 1U;          // Start of Conversion A Enable
         EPwm1Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm1Regs.ETSEL.bit.SOCASEL              = 2U;          // Start of Conversion A Select
         EPwm1Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM1SOC Period Select
         EPwm1Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm1Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm1Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm1Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm1Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM1SOCB Period Select
         EPwm1Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm1Regs.ETSEL.bit.INTEN                = 0U;          // EPWM1INTn Enable
         EPwm1Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm1Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm1Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM1INTn Period Select
         EPwm1Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm1Regs.ETSEL.all = (EPwm1Regs.ETSEL.all & ~0xFF7FU) | 0x1A01U;
      EPwm1Regs.ETPS.all = (EPwm1Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm1Regs.ETSOCPS.all = (EPwm1Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm1Regs.ETINTPS.all = (EPwm1Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm1Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm1Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm1Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm1Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm1Regs.PCCTL.all = (EPwm1Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm1Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm1Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM1A
         EPwm1Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM1B
         EPwm1Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM1A action on DCAEVT1
         EPwm1Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM1A action on DCAEVT2
         EPwm1Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM1B action on DCBEVT1
         EPwm1Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM1B action on DCBEVT2
       */
      EPwm1Regs.TZCTL.all = (EPwm1Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm1Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm1Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm1Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm1Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm1Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm1Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm1Regs.TZEINT.all = (EPwm1Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm1Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm1Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm1Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm1Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm1Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm1Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm1Regs.DCACTL.all = (EPwm1Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm1Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm1Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm1Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm1Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm1Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm1Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm1Regs.DCBCTL.all = (EPwm1Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm1Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm1Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm1Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm1Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm1Regs.DCTRIPSEL.all = (EPwm1Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm1Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm1Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm1Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm1Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm1Regs.TZDCSEL.all = (EPwm1Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm1Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm1Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm1Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm1Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm1Regs.DCFCTL.all = (EPwm1Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm1Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm1Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm1Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm1Regs.DCCAPCTL.all = (EPwm1Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm1Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm1Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm1Regs.HRCNFG.all = (EPwm1Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm1Regs.EPWMXLINK.bit.TBPRDLINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPALINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPBLINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPCLINK = 0U;
      EPwm1Regs.EPWMXLINK.bit.CMPDLINK = 0U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm1Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm1Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm1Regs.HRPCTL.all = (EPwm1Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM10_SR3' */

    /*** Initialize ePWM10 modules ***/
    {
      /*  // Time Base Control Register
         EPwm10Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm10Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm10Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm10Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm10Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm10Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm10Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm10Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm10Regs.TBCTL.all = (EPwm10Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm10Regs.TBCTL2.all = (EPwm10Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm10Regs.TBPRD = 1538U;        // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm10Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm10Regs.TBPHS.all = (EPwm10Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm10Regs.TBCTR = 0x0000U;      /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm10Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm10Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm10Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm10Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm10Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm10Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm10Regs.CMPCTL.all = (EPwm10Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm10Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm10Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm10Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm10Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm10Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm10Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm10Regs.CMPCTL2.all = (EPwm10Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm10Regs.CMPA.bit.CMPA = 335U; // Counter Compare A Register
      EPwm10Regs.CMPB.bit.CMPB = 435U; // Counter Compare B Register
      EPwm10Regs.CMPC = 32000U;        // Counter Compare C Register
      EPwm10Regs.CMPD = 32000U;        // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm10Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm10Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm10Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm10Regs.AQSFRC.all = (EPwm10Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm10Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm10Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm10Regs.AQCSFRC.all = (EPwm10Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm10Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm10Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm10Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm10Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm10Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm10Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm10Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm10Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm10Regs.DBCTL.all = (EPwm10Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm10Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm10Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm10Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm10Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm10Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm10Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM10SOC Period Select
         EPwm10Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm10Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm10Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm10Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm10Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM10SOCB Period Select
         EPwm10Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm10Regs.ETSEL.bit.INTEN                = 0U;          // EPWM10INTn Enable
         EPwm10Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm10Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm10Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM10INTn Period Select
         EPwm10Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm10Regs.ETSEL.all = (EPwm10Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm10Regs.ETPS.all = (EPwm10Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm10Regs.ETSOCPS.all = (EPwm10Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm10Regs.ETINTPS.all = (EPwm10Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm10Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm10Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm10Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm10Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm10Regs.PCCTL.all = (EPwm10Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm10Regs.TZSEL.all = 960U;     // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm10Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM10A
         EPwm10Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM10B
         EPwm10Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM10A action on DCAEVT1
         EPwm10Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM10A action on DCAEVT2
         EPwm10Regs.TZCTL.bit.DCBEVT1              = 2U;          // EPWM10B action on DCBEVT1
         EPwm10Regs.TZCTL.bit.DCBEVT2              = 2U;          // EPWM10B action on DCBEVT2
       */
      EPwm10Regs.TZCTL.all = (EPwm10Regs.TZCTL.all & ~0xFFFU) | 0xAFAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm10Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm10Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm10Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm10Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm10Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm10Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm10Regs.TZEINT.all = (EPwm10Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm10Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm10Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm10Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm10Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm10Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCAEVT2 Force Sync Signal
         EPwm10Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm10Regs.DCACTL.all = (EPwm10Regs.DCACTL.all & ~0x30FU) | 0x204U;

      /*	// Digital Compare B Control Register
         EPwm10Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm10Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm10Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm10Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm10Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCBEVT2 Force Sync Signal
         EPwm10Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm10Regs.DCBCTL.all = (EPwm10Regs.DCBCTL.all & ~0x30FU) | 0x200U;

      /*	// Digital Compare Trip Select Register
         EPwm10Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 4U;          // Digital Compare A High COMP Input Select

         EPwm10Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm10Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 4U;          // Digital Compare B High COMP Input Select
         EPwm10Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 8U;          // Digital Compare B Low COMP Input Select
       */
      EPwm10Regs.DCTRIPSEL.all = (EPwm10Regs.DCTRIPSEL.all & ~ 0xFFFFU) |
        0x8414U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm10Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm10Regs.TZDCSEL.bit.DCAEVT2            = 2U;          // Digital Compare Output A Event 2
         EPwm10Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm10Regs.TZDCSEL.bit.DCBEVT2            = 2U;          // Digital Compare Output B Event 2
       */
      EPwm10Regs.TZDCSEL.all = (EPwm10Regs.TZDCSEL.all & ~0xFFFU) | 0x410U;

      /*	// Digital Compare Filter Control Register
         EPwm10Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm10Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm10Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm10Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm10Regs.DCFCTL.all = (EPwm10Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm10Regs.DCFOFFSET = 0U;       // Digital Compare Filter Offset Register
      EPwm10Regs.DCFWINDOW = 0U;       // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm10Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm10Regs.DCCAPCTL.all = (EPwm10Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm10Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm10Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm10Regs.HRCNFG.all = (EPwm10Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm10Regs.EPWMXLINK.bit.TBPRDLINK = 9U;
      EPwm10Regs.EPWMXLINK.bit.CMPALINK = 9U;
      EPwm10Regs.EPWMXLINK.bit.CMPBLINK = 9U;
      EPwm10Regs.EPWMXLINK.bit.CMPCLINK = 9U;
      EPwm10Regs.EPWMXLINK.bit.CMPDLINK = 9U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm10Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm10Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm10Regs.HRPCTL.all = (EPwm10Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM11_SR3' */

    /*** Initialize ePWM11 modules ***/
    {
      /*  // Time Base Control Register
         EPwm11Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm11Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm11Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm11Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm11Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm11Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm11Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm11Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm11Regs.TBCTL.all = (EPwm11Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm11Regs.TBCTL2.all = (EPwm11Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm11Regs.TBPRD = 1538U;        // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm11Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm11Regs.TBPHS.all = (EPwm11Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm11Regs.TBCTR = 0x0000U;      /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm11Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm11Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm11Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm11Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm11Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm11Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm11Regs.CMPCTL.all = (EPwm11Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm11Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm11Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm11Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm11Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm11Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm11Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm11Regs.CMPCTL2.all = (EPwm11Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm11Regs.CMPA.bit.CMPA = 335U; // Counter Compare A Register
      EPwm11Regs.CMPB.bit.CMPB = 435U; // Counter Compare B Register
      EPwm11Regs.CMPC = 32000U;        // Counter Compare C Register
      EPwm11Regs.CMPD = 32000U;        // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm11Regs.AQCTLA.all = 96U;
                               // Action Qualifier Control Register For Output A
      EPwm11Regs.AQCTLB.all = 2304U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm11Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm11Regs.AQSFRC.all = (EPwm11Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm11Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm11Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm11Regs.AQCSFRC.all = (EPwm11Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm11Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm11Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm11Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm11Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm11Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm11Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm11Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm11Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm11Regs.DBCTL.all = (EPwm11Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm11Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm11Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm11Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm11Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm11Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm11Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM11SOC Period Select
         EPwm11Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm11Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm11Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm11Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm11Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM11SOCB Period Select
         EPwm11Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm11Regs.ETSEL.bit.INTEN                = 0U;          // EPWM11INTn Enable
         EPwm11Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm11Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm11Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM11INTn Period Select
         EPwm11Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm11Regs.ETSEL.all = (EPwm11Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm11Regs.ETPS.all = (EPwm11Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm11Regs.ETSOCPS.all = (EPwm11Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm11Regs.ETINTPS.all = (EPwm11Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm11Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm11Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm11Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm11Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm11Regs.PCCTL.all = (EPwm11Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm11Regs.TZSEL.all = 960U;     // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm11Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM11A
         EPwm11Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM11B
         EPwm11Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM11A action on DCAEVT1
         EPwm11Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM11A action on DCAEVT2
         EPwm11Regs.TZCTL.bit.DCBEVT1              = 2U;          // EPWM11B action on DCBEVT1
         EPwm11Regs.TZCTL.bit.DCBEVT2              = 2U;          // EPWM11B action on DCBEVT2
       */
      EPwm11Regs.TZCTL.all = (EPwm11Regs.TZCTL.all & ~0xFFFU) | 0xAFAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm11Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm11Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm11Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm11Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm11Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm11Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm11Regs.TZEINT.all = (EPwm11Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm11Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm11Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm11Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm11Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm11Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCAEVT2 Force Sync Signal
         EPwm11Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm11Regs.DCACTL.all = (EPwm11Regs.DCACTL.all & ~0x30FU) | 0x204U;

      /*	// Digital Compare B Control Register
         EPwm11Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm11Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm11Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm11Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm11Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCBEVT2 Force Sync Signal
         EPwm11Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm11Regs.DCBCTL.all = (EPwm11Regs.DCBCTL.all & ~0x30FU) | 0x200U;

      /*	// Digital Compare Trip Select Register
         EPwm11Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 4U;          // Digital Compare A High COMP Input Select

         EPwm11Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 9U;          // Digital Compare A Low COMP Input Select
         EPwm11Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 4U;          // Digital Compare B High COMP Input Select
         EPwm11Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm11Regs.DCTRIPSEL.all = (EPwm11Regs.DCTRIPSEL.all & ~ 0xFFFFU) |
        0x1494U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm11Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm11Regs.TZDCSEL.bit.DCAEVT2            = 2U;          // Digital Compare Output A Event 2
         EPwm11Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm11Regs.TZDCSEL.bit.DCBEVT2            = 2U;          // Digital Compare Output B Event 2
       */
      EPwm11Regs.TZDCSEL.all = (EPwm11Regs.TZDCSEL.all & ~0xFFFU) | 0x410U;

      /*	// Digital Compare Filter Control Register
         EPwm11Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm11Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm11Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm11Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm11Regs.DCFCTL.all = (EPwm11Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm11Regs.DCFOFFSET = 0U;       // Digital Compare Filter Offset Register
      EPwm11Regs.DCFWINDOW = 0U;       // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm11Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm11Regs.DCCAPCTL.all = (EPwm11Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm11Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm11Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm11Regs.HRCNFG.all = (EPwm11Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm11Regs.EPWMXLINK.bit.TBPRDLINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPALINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPBLINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPCLINK = 10U;
      EPwm11Regs.EPWMXLINK.bit.CMPDLINK = 10U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm11Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm11Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm11Regs.HRPCTL.all = (EPwm11Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM2_SR3' */

    /*** Initialize ePWM2 modules ***/
    {
      /*  // Time Base Control Register
         EPwm2Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm2Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm2Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm2Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm2Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm2Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm2Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm2Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm2Regs.TBCTL.all = (EPwm2Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm2Regs.TBCTL2.all = (EPwm2Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm2Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm2Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm2Regs.TBPHS.all = (EPwm2Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm2Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm2Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm2Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm2Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm2Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm2Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm2Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm2Regs.CMPCTL.all = (EPwm2Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm2Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm2Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm2Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm2Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm2Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm2Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm2Regs.CMPCTL2.all = (EPwm2Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm2Regs.CMPA.bit.CMPA = 335U;  // Counter Compare A Register
      EPwm2Regs.CMPB.bit.CMPB = 435U;  // Counter Compare B Register
      EPwm2Regs.CMPC = 32000U;         // Counter Compare C Register
      EPwm2Regs.CMPD = 32000U;         // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm2Regs.AQCTLA.all = 96U;
                               // Action Qualifier Control Register For Output A
      EPwm2Regs.AQCTLB.all = 2304U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm2Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm2Regs.AQSFRC.all = (EPwm2Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm2Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm2Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm2Regs.AQCSFRC.all = (EPwm2Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm2Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm2Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm2Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm2Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm2Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm2Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm2Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm2Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm2Regs.DBCTL.all = (EPwm2Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm2Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm2Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm2Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm2Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm2Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm2Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM2SOC Period Select
         EPwm2Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm2Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm2Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm2Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm2Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM2SOCB Period Select
         EPwm2Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm2Regs.ETSEL.bit.INTEN                = 0U;          // EPWM2INTn Enable
         EPwm2Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm2Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm2Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM2INTn Period Select
         EPwm2Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm2Regs.ETSEL.all = (EPwm2Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm2Regs.ETPS.all = (EPwm2Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm2Regs.ETSOCPS.all = (EPwm2Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm2Regs.ETINTPS.all = (EPwm2Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm2Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm2Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm2Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm2Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm2Regs.PCCTL.all = (EPwm2Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm2Regs.TZSEL.all = 960U;      // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm2Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM2A
         EPwm2Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM2B
         EPwm2Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM2A action on DCAEVT1
         EPwm2Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM2A action on DCAEVT2
         EPwm2Regs.TZCTL.bit.DCBEVT1              = 2U;          // EPWM2B action on DCBEVT1
         EPwm2Regs.TZCTL.bit.DCBEVT2              = 2U;          // EPWM2B action on DCBEVT2
       */
      EPwm2Regs.TZCTL.all = (EPwm2Regs.TZCTL.all & ~0xFFFU) | 0xAFEU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm2Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm2Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm2Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm2Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm2Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm2Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm2Regs.TZEINT.all = (EPwm2Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm2Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm2Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm2Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm2Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm2Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCAEVT2 Force Sync Signal
         EPwm2Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm2Regs.DCACTL.all = (EPwm2Regs.DCACTL.all & ~0x30FU) | 0x204U;

      /*	// Digital Compare B Control Register
         EPwm2Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm2Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm2Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm2Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm2Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCBEVT2 Force Sync Signal
         EPwm2Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm2Regs.DCBCTL.all = (EPwm2Regs.DCBCTL.all & ~0x30FU) | 0x200U;

      /*	// Digital Compare Trip Select Register
         EPwm2Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 3U;          // Digital Compare A High COMP Input Select

         EPwm2Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 2U;          // Digital Compare A Low COMP Input Select
         EPwm2Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 3U;          // Digital Compare B High COMP Input Select
         EPwm2Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm2Regs.DCTRIPSEL.all = (EPwm2Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1323U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm2Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm2Regs.TZDCSEL.bit.DCAEVT2            = 2U;          // Digital Compare Output A Event 2
         EPwm2Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm2Regs.TZDCSEL.bit.DCBEVT2            = 2U;          // Digital Compare Output B Event 2
       */
      EPwm2Regs.TZDCSEL.all = (EPwm2Regs.TZDCSEL.all & ~0xFFFU) | 0x410U;

      /*	// Digital Compare Filter Control Register
         EPwm2Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm2Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm2Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm2Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm2Regs.DCFCTL.all = (EPwm2Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm2Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm2Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm2Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm2Regs.DCCAPCTL.all = (EPwm2Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm2Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm2Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm2Regs.HRCNFG.all = (EPwm2Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm2Regs.EPWMXLINK.bit.TBPRDLINK = 1U;
      EPwm2Regs.EPWMXLINK.bit.CMPALINK = 1U;
      EPwm2Regs.EPWMXLINK.bit.CMPBLINK = 1U;
      EPwm2Regs.EPWMXLINK.bit.CMPCLINK = 1U;
      EPwm2Regs.EPWMXLINK.bit.CMPDLINK = 1U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm2Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm2Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm2Regs.HRPCTL.all = (EPwm2Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM3 - Relay' */

    /*** Initialize ePWM3 modules ***/
    {
      /*  // Time Base Control Register
         EPwm3Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm3Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm3Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm3Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm3Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm3Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm3Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm3Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm3Regs.TBCTL.all = (EPwm3Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm3Regs.TBCTL2.all = (EPwm3Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm3Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm3Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm3Regs.TBPHS.all = (EPwm3Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm3Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm3Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm3Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm3Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm3Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm3Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm3Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm3Regs.CMPCTL.all = (EPwm3Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm3Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm3Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm3Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm3Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm3Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm3Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm3Regs.CMPCTL2.all = (EPwm3Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm3Regs.CMPA.bit.CMPA = 1230U; // Counter Compare A Register
      EPwm3Regs.CMPB.bit.CMPB = 1230U; // Counter Compare B Register
      EPwm3Regs.CMPC = 0U;             // Counter Compare C Register
      EPwm3Regs.CMPD = 0U;             // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm3Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm3Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm3Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm3Regs.AQSFRC.all = (EPwm3Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm3Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm3Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm3Regs.AQCSFRC.all = (EPwm3Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm3Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm3Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm3Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm3Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm3Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm3Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm3Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm3Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm3Regs.DBCTL.all = (EPwm3Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm3Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm3Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm3Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm3Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm3Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm3Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM3SOC Period Select
         EPwm3Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm3Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm3Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm3Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm3Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM3SOCB Period Select
         EPwm3Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm3Regs.ETSEL.bit.INTEN                = 0U;          // EPWM3INTn Enable
         EPwm3Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm3Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm3Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM3INTn Period Select
         EPwm3Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm3Regs.ETSEL.all = (EPwm3Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm3Regs.ETPS.all = (EPwm3Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm3Regs.ETSOCPS.all = (EPwm3Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm3Regs.ETINTPS.all = (EPwm3Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm3Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm3Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm3Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm3Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm3Regs.PCCTL.all = (EPwm3Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm3Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm3Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM3A
         EPwm3Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM3B
         EPwm3Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM3A action on DCAEVT1
         EPwm3Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM3A action on DCAEVT2
         EPwm3Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM3B action on DCBEVT1
         EPwm3Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM3B action on DCBEVT2
       */
      EPwm3Regs.TZCTL.all = (EPwm3Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm3Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm3Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm3Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm3Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm3Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm3Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm3Regs.TZEINT.all = (EPwm3Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm3Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm3Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm3Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm3Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm3Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm3Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm3Regs.DCACTL.all = (EPwm3Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm3Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm3Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm3Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm3Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm3Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm3Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm3Regs.DCBCTL.all = (EPwm3Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm3Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm3Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm3Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm3Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm3Regs.DCTRIPSEL.all = (EPwm3Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm3Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm3Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm3Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm3Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm3Regs.TZDCSEL.all = (EPwm3Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm3Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm3Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm3Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm3Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm3Regs.DCFCTL.all = (EPwm3Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm3Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm3Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm3Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm3Regs.DCCAPCTL.all = (EPwm3Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm3Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm3Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm3Regs.HRCNFG.all = (EPwm3Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm3Regs.EPWMXLINK.bit.TBPRDLINK = 2U;
      EPwm3Regs.EPWMXLINK.bit.CMPALINK = 2U;
      EPwm3Regs.EPWMXLINK.bit.CMPBLINK = 2U;
      EPwm3Regs.EPWMXLINK.bit.CMPCLINK = 2U;
      EPwm3Regs.EPWMXLINK.bit.CMPDLINK = 2U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm3Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm3Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm3Regs.HRPCTL.all = (EPwm3Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM4 - Unused' */

    /*** Initialize ePWM4 modules ***/
    {
      /*  // Time Base Control Register
         EPwm4Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm4Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm4Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm4Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm4Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm4Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm4Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm4Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm4Regs.TBCTL.all = (EPwm4Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm4Regs.TBCTL2.all = (EPwm4Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm4Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm4Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm4Regs.TBPHS.all = (EPwm4Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm4Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm4Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm4Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm4Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm4Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm4Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm4Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm4Regs.CMPCTL.all = (EPwm4Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm4Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm4Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm4Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm4Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm4Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm4Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm4Regs.CMPCTL2.all = (EPwm4Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm4Regs.CMPA.bit.CMPA = 154U;  // Counter Compare A Register
      EPwm4Regs.CMPB.bit.CMPB = 154U;  // Counter Compare B Register
      EPwm4Regs.CMPC = 0U;             // Counter Compare C Register
      EPwm4Regs.CMPD = 0U;             // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm4Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm4Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm4Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm4Regs.AQSFRC.all = (EPwm4Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm4Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm4Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm4Regs.AQCSFRC.all = (EPwm4Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm4Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm4Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm4Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm4Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm4Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm4Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm4Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm4Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm4Regs.DBCTL.all = (EPwm4Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm4Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm4Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm4Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm4Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm4Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm4Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM4SOC Period Select
         EPwm4Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm4Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm4Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm4Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm4Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM4SOCB Period Select
         EPwm4Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm4Regs.ETSEL.bit.INTEN                = 0U;          // EPWM4INTn Enable
         EPwm4Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm4Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm4Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM4INTn Period Select
         EPwm4Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm4Regs.ETSEL.all = (EPwm4Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm4Regs.ETPS.all = (EPwm4Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm4Regs.ETSOCPS.all = (EPwm4Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm4Regs.ETINTPS.all = (EPwm4Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm4Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm4Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm4Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm4Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm4Regs.PCCTL.all = (EPwm4Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm4Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm4Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM4A
         EPwm4Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM4B
         EPwm4Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM4A action on DCAEVT1
         EPwm4Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM4A action on DCAEVT2
         EPwm4Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM4B action on DCBEVT1
         EPwm4Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM4B action on DCBEVT2
       */
      EPwm4Regs.TZCTL.all = (EPwm4Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm4Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm4Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm4Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm4Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm4Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm4Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm4Regs.TZEINT.all = (EPwm4Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm4Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm4Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm4Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm4Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm4Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm4Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm4Regs.DCACTL.all = (EPwm4Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm4Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm4Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm4Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm4Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm4Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm4Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm4Regs.DCBCTL.all = (EPwm4Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm4Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm4Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm4Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm4Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm4Regs.DCTRIPSEL.all = (EPwm4Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm4Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm4Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm4Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm4Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm4Regs.TZDCSEL.all = (EPwm4Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm4Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm4Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm4Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm4Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm4Regs.DCFCTL.all = (EPwm4Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm4Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm4Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm4Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm4Regs.DCCAPCTL.all = (EPwm4Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm4Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm4Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm4Regs.HRCNFG.all = (EPwm4Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm4Regs.EPWMXLINK.bit.TBPRDLINK = 3U;
      EPwm4Regs.EPWMXLINK.bit.CMPALINK = 3U;
      EPwm4Regs.EPWMXLINK.bit.CMPBLINK = 3U;
      EPwm4Regs.EPWMXLINK.bit.CMPCLINK = 3U;
      EPwm4Regs.EPWMXLINK.bit.CMPDLINK = 3U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm4Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm4Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm4Regs.HRPCTL.all = (EPwm4Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM7_SR3' */

    /*** Initialize ePWM7 modules ***/
    {
      /*  // Time Base Control Register
         EPwm7Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm7Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm7Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm7Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm7Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm7Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm7Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm7Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm7Regs.TBCTL.all = (EPwm7Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm7Regs.TBCTL2.all = (EPwm7Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm7Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm7Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm7Regs.TBPHS.all = (EPwm7Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm7Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm7Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm7Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm7Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm7Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm7Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm7Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm7Regs.CMPCTL.all = (EPwm7Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm7Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm7Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm7Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm7Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm7Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm7Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm7Regs.CMPCTL2.all = (EPwm7Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm7Regs.CMPA.bit.CMPA = 335U;  // Counter Compare A Register
      EPwm7Regs.CMPB.bit.CMPB = 435U;  // Counter Compare B Register
      EPwm7Regs.CMPC = 32000U;         // Counter Compare C Register
      EPwm7Regs.CMPD = 32000U;         // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm7Regs.AQCTLA.all = 96U;
                               // Action Qualifier Control Register For Output A
      EPwm7Regs.AQCTLB.all = 2304U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm7Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm7Regs.AQSFRC.all = (EPwm7Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm7Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm7Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm7Regs.AQCSFRC.all = (EPwm7Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm7Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm7Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm7Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm7Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm7Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm7Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm7Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm7Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm7Regs.DBCTL.all = (EPwm7Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm7Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm7Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm7Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm7Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm7Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm7Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM7SOC Period Select
         EPwm7Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm7Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm7Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm7Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm7Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM7SOCB Period Select
         EPwm7Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm7Regs.ETSEL.bit.INTEN                = 0U;          // EPWM7INTn Enable
         EPwm7Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm7Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm7Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM7INTn Period Select
         EPwm7Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm7Regs.ETSEL.all = (EPwm7Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm7Regs.ETPS.all = (EPwm7Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm7Regs.ETSOCPS.all = (EPwm7Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm7Regs.ETINTPS.all = (EPwm7Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm7Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm7Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm7Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm7Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm7Regs.PCCTL.all = (EPwm7Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm7Regs.TZSEL.all = 960U;      // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm7Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM7A
         EPwm7Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM7B
         EPwm7Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM7A action on DCAEVT1
         EPwm7Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM7A action on DCAEVT2
         EPwm7Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM7B action on DCBEVT1
         EPwm7Regs.TZCTL.bit.DCBEVT2              = 2U;          // EPWM7B action on DCBEVT2
       */
      EPwm7Regs.TZCTL.all = (EPwm7Regs.TZCTL.all & ~0xFFFU) | 0xBFBU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm7Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm7Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm7Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm7Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm7Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm7Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm7Regs.TZEINT.all = (EPwm7Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm7Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm7Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm7Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm7Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm7Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCAEVT2 Force Sync Signal
         EPwm7Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm7Regs.DCACTL.all = (EPwm7Regs.DCACTL.all & ~0x30FU) | 0x204U;

      /*	// Digital Compare B Control Register
         EPwm7Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm7Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm7Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm7Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm7Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCBEVT2 Force Sync Signal
         EPwm7Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm7Regs.DCBCTL.all = (EPwm7Regs.DCBCTL.all & ~0x30FU) | 0x200U;

      /*	// Digital Compare Trip Select Register
         EPwm7Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 3U;          // Digital Compare A High COMP Input Select

         EPwm7Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 4U;          // Digital Compare A Low COMP Input Select
         EPwm7Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 3U;          // Digital Compare B High COMP Input Select
         EPwm7Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm7Regs.DCTRIPSEL.all = (EPwm7Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1343U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm7Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm7Regs.TZDCSEL.bit.DCAEVT2            = 2U;          // Digital Compare Output A Event 2
         EPwm7Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm7Regs.TZDCSEL.bit.DCBEVT2            = 2U;          // Digital Compare Output B Event 2
       */
      EPwm7Regs.TZDCSEL.all = (EPwm7Regs.TZDCSEL.all & ~0xFFFU) | 0x410U;

      /*	// Digital Compare Filter Control Register
         EPwm7Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm7Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm7Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm7Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm7Regs.DCFCTL.all = (EPwm7Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm7Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm7Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm7Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm7Regs.DCCAPCTL.all = (EPwm7Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm7Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm7Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm7Regs.HRCNFG.all = (EPwm7Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm7Regs.EPWMXLINK.bit.TBPRDLINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPALINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPBLINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPCLINK = 6U;
      EPwm7Regs.EPWMXLINK.bit.CMPDLINK = 6U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm7Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm7Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm7Regs.HRPCTL.all = (EPwm7Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM8_SR3' */

    /*** Initialize ePWM8 modules ***/
    {
      /*  // Time Base Control Register
         EPwm8Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm8Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm8Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm8Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm8Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm8Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm8Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm8Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm8Regs.TBCTL.all = (EPwm8Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm8Regs.TBCTL2.all = (EPwm8Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm8Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm8Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm8Regs.TBPHS.all = (EPwm8Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm8Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm8Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm8Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm8Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm8Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm8Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm8Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm8Regs.CMPCTL.all = (EPwm8Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm8Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm8Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm8Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm8Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm8Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm8Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm8Regs.CMPCTL2.all = (EPwm8Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm8Regs.CMPA.bit.CMPA = 335U;  // Counter Compare A Register
      EPwm8Regs.CMPB.bit.CMPB = 435U;  // Counter Compare B Register
      EPwm8Regs.CMPC = 32000U;         // Counter Compare C Register
      EPwm8Regs.CMPD = 32000U;         // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm8Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm8Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm8Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm8Regs.AQSFRC.all = (EPwm8Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm8Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm8Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm8Regs.AQCSFRC.all = (EPwm8Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm8Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm8Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm8Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm8Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm8Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm8Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm8Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm8Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm8Regs.DBCTL.all = (EPwm8Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm8Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm8Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm8Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm8Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm8Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm8Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM8SOC Period Select
         EPwm8Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm8Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm8Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm8Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm8Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM8SOCB Period Select
         EPwm8Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm8Regs.ETSEL.bit.INTEN                = 0U;          // EPWM8INTn Enable
         EPwm8Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm8Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm8Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM8INTn Period Select
         EPwm8Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm8Regs.ETSEL.all = (EPwm8Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm8Regs.ETPS.all = (EPwm8Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm8Regs.ETSOCPS.all = (EPwm8Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm8Regs.ETINTPS.all = (EPwm8Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm8Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm8Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm8Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm8Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm8Regs.PCCTL.all = (EPwm8Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm8Regs.TZSEL.all = 960U;      // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm8Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM8A
         EPwm8Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM8B
         EPwm8Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM8A action on DCAEVT1
         EPwm8Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM8A action on DCAEVT2
         EPwm8Regs.TZCTL.bit.DCBEVT1              = 2U;          // EPWM8B action on DCBEVT1
         EPwm8Regs.TZCTL.bit.DCBEVT2              = 2U;          // EPWM8B action on DCBEVT2
       */
      EPwm8Regs.TZCTL.all = (EPwm8Regs.TZCTL.all & ~0xFFFU) | 0xAFAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm8Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm8Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm8Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm8Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm8Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm8Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm8Regs.TZEINT.all = (EPwm8Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm8Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm8Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm8Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm8Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm8Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCAEVT2 Force Sync Signal
         EPwm8Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm8Regs.DCACTL.all = (EPwm8Regs.DCACTL.all & ~0x30FU) | 0x204U;

      /*	// Digital Compare B Control Register
         EPwm8Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm8Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm8Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm8Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm8Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCBEVT2 Force Sync Signal
         EPwm8Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm8Regs.DCBCTL.all = (EPwm8Regs.DCBCTL.all & ~0x30FU) | 0x200U;

      /*	// Digital Compare Trip Select Register
         EPwm8Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 6U;          // Digital Compare A High COMP Input Select

         EPwm8Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm8Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 6U;          // Digital Compare B High COMP Input Select
         EPwm8Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 6U;          // Digital Compare B Low COMP Input Select
       */
      EPwm8Regs.DCTRIPSEL.all = (EPwm8Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x6616U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm8Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm8Regs.TZDCSEL.bit.DCAEVT2            = 2U;          // Digital Compare Output A Event 2
         EPwm8Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm8Regs.TZDCSEL.bit.DCBEVT2            = 2U;          // Digital Compare Output B Event 2
       */
      EPwm8Regs.TZDCSEL.all = (EPwm8Regs.TZDCSEL.all & ~0xFFFU) | 0x410U;

      /*	// Digital Compare Filter Control Register
         EPwm8Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm8Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm8Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm8Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm8Regs.DCFCTL.all = (EPwm8Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm8Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm8Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm8Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm8Regs.DCCAPCTL.all = (EPwm8Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm8Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm8Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm8Regs.HRCNFG.all = (EPwm8Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm8Regs.EPWMXLINK.bit.TBPRDLINK = 7U;
      EPwm8Regs.EPWMXLINK.bit.CMPALINK = 7U;
      EPwm8Regs.EPWMXLINK.bit.CMPBLINK = 7U;
      EPwm8Regs.EPWMXLINK.bit.CMPCLINK = 7U;
      EPwm8Regs.EPWMXLINK.bit.CMPDLINK = 7U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm8Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm8Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm8Regs.HRPCTL.all = (EPwm8Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM9_ORIG3' */

    /*** Initialize ePWM9 modules ***/
    {
      /*  // Time Base Control Register
         EPwm9Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm9Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm9Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm9Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm9Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm9Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm9Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm9Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm9Regs.TBCTL.all = (EPwm9Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm9Regs.TBCTL2.all = (EPwm9Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm9Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm9Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm9Regs.TBPHS.all = (EPwm9Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm9Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm9Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm9Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm9Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm9Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm9Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm9Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm9Regs.CMPCTL.all = (EPwm9Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm9Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm9Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm9Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm9Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm9Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm9Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm9Regs.CMPCTL2.all = (EPwm9Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm9Regs.CMPA.bit.CMPA = 335U;  // Counter Compare A Register
      EPwm9Regs.CMPB.bit.CMPB = 435U;  // Counter Compare B Register
      EPwm9Regs.CMPC = 32000U;         // Counter Compare C Register
      EPwm9Regs.CMPD = 32000U;         // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm9Regs.AQCTLA.all = 96U;
                               // Action Qualifier Control Register For Output A
      EPwm9Regs.AQCTLB.all = 2304U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm9Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm9Regs.AQSFRC.all = (EPwm9Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm9Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm9Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm9Regs.AQCSFRC.all = (EPwm9Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm9Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm9Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm9Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm9Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm9Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm9Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm9Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm9Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm9Regs.DBCTL.all = (EPwm9Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm9Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm9Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm9Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm9Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm9Regs.ETSEL.bit.SOCASEL              = 0U;          // Start of Conversion A Select
         EPwm9Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM9SOC Period Select
         EPwm9Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm9Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm9Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm9Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm9Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM9SOCB Period Select
         EPwm9Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm9Regs.ETSEL.bit.INTEN                = 0U;          // EPWM9INTn Enable
         EPwm9Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm9Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm9Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM9INTn Period Select
         EPwm9Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm9Regs.ETSEL.all = (EPwm9Regs.ETSEL.all & ~0xFF7FU) | 0x1001U;
      EPwm9Regs.ETPS.all = (EPwm9Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm9Regs.ETSOCPS.all = (EPwm9Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm9Regs.ETINTPS.all = (EPwm9Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm9Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm9Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm9Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm9Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm9Regs.PCCTL.all = (EPwm9Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm9Regs.TZSEL.all = 960U;      // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm9Regs.TZCTL.bit.TZA                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM9A
         EPwm9Regs.TZCTL.bit.TZB                  = 2U;          // TZ1 to TZ6 Trip Action On EPWM9B
         EPwm9Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM9A action on DCAEVT1
         EPwm9Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM9A action on DCAEVT2
         EPwm9Regs.TZCTL.bit.DCBEVT1              = 2U;          // EPWM9B action on DCBEVT1
         EPwm9Regs.TZCTL.bit.DCBEVT2              = 2U;          // EPWM9B action on DCBEVT2
       */
      EPwm9Regs.TZCTL.all = (EPwm9Regs.TZCTL.all & ~0xFFFU) | 0xAFAU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm9Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm9Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm9Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm9Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm9Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm9Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm9Regs.TZEINT.all = (EPwm9Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm9Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm9Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm9Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm9Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm9Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCAEVT2 Force Sync Signal
         EPwm9Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm9Regs.DCACTL.all = (EPwm9Regs.DCACTL.all & ~0x30FU) | 0x204U;

      /*	// Digital Compare B Control Register
         EPwm9Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm9Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm9Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm9Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm9Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 1U;          // DCBEVT2 Force Sync Signal
         EPwm9Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm9Regs.DCBCTL.all = (EPwm9Regs.DCBCTL.all & ~0x30FU) | 0x200U;

      /*	// Digital Compare Trip Select Register
         EPwm9Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 6U;          // Digital Compare A High COMP Input Select

         EPwm9Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 7U;          // Digital Compare A Low COMP Input Select
         EPwm9Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 6U;          // Digital Compare B High COMP Input Select
         EPwm9Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm9Regs.DCTRIPSEL.all = (EPwm9Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1676U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm9Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm9Regs.TZDCSEL.bit.DCAEVT2            = 2U;          // Digital Compare Output A Event 2
         EPwm9Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm9Regs.TZDCSEL.bit.DCBEVT2            = 2U;          // Digital Compare Output B Event 2
       */
      EPwm9Regs.TZDCSEL.all = (EPwm9Regs.TZDCSEL.all & ~0xFFFU) | 0x410U;

      /*	// Digital Compare Filter Control Register
         EPwm9Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm9Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm9Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm9Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm9Regs.DCFCTL.all = (EPwm9Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm9Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm9Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm9Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm9Regs.DCCAPCTL.all = (EPwm9Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm9Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm9Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm9Regs.HRCNFG.all = (EPwm9Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm9Regs.EPWMXLINK.bit.TBPRDLINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPALINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPBLINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPCLINK = 8U;
      EPwm9Regs.EPWMXLINK.bit.CMPDLINK = 8U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm9Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm9Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm9Regs.HRPCTL.all = (EPwm9Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* Start for S-Function (c2802xpwm): '<S30>/ePWM5 - Unused' */

    /*** Initialize ePWM5 modules ***/
    {
      /*  // Time Base Control Register
         EPwm5Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm5Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm5Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm5Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm5Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm5Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm5Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm5Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm5Regs.TBCTL.all = (EPwm5Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm5Regs.TBCTL2.all = (EPwm5Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm5Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm5Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm5Regs.TBPHS.all = (EPwm5Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm5Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm5Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm5Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm5Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm5Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm5Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm5Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm5Regs.CMPCTL.all = (EPwm5Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm5Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm5Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm5Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm5Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm5Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm5Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm5Regs.CMPCTL2.all = (EPwm5Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm5Regs.CMPA.bit.CMPA = 154U;  // Counter Compare A Register
      EPwm5Regs.CMPB.bit.CMPB = 154U;  // Counter Compare B Register
      EPwm5Regs.CMPC = 0U;             // Counter Compare C Register
      EPwm5Regs.CMPD = 0U;             // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm5Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm5Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm5Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm5Regs.AQSFRC.all = (EPwm5Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm5Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm5Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm5Regs.AQCSFRC.all = (EPwm5Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm5Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm5Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm5Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm5Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm5Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm5Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm5Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm5Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm5Regs.DBCTL.all = (EPwm5Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm5Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm5Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm5Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm5Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm5Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm5Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM5SOC Period Select
         EPwm5Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm5Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm5Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm5Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm5Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM5SOCB Period Select
         EPwm5Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm5Regs.ETSEL.bit.INTEN                = 0U;          // EPWM5INTn Enable
         EPwm5Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm5Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm5Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM5INTn Period Select
         EPwm5Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm5Regs.ETSEL.all = (EPwm5Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm5Regs.ETPS.all = (EPwm5Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm5Regs.ETSOCPS.all = (EPwm5Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm5Regs.ETINTPS.all = (EPwm5Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm5Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm5Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm5Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm5Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm5Regs.PCCTL.all = (EPwm5Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm5Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm5Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM5A
         EPwm5Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM5B
         EPwm5Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM5A action on DCAEVT1
         EPwm5Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM5A action on DCAEVT2
         EPwm5Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM5B action on DCBEVT1
         EPwm5Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM5B action on DCBEVT2
       */
      EPwm5Regs.TZCTL.all = (EPwm5Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm5Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm5Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm5Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm5Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm5Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm5Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm5Regs.TZEINT.all = (EPwm5Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm5Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm5Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm5Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm5Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm5Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm5Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm5Regs.DCACTL.all = (EPwm5Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm5Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm5Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm5Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm5Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm5Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm5Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm5Regs.DCBCTL.all = (EPwm5Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm5Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm5Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm5Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm5Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm5Regs.DCTRIPSEL.all = (EPwm5Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm5Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm5Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm5Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm5Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm5Regs.TZDCSEL.all = (EPwm5Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm5Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm5Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm5Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm5Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm5Regs.DCFCTL.all = (EPwm5Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm5Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm5Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm5Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm5Regs.DCCAPCTL.all = (EPwm5Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm5Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm5Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm5Regs.HRCNFG.all = (EPwm5Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm5Regs.EPWMXLINK.bit.TBPRDLINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPALINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPBLINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPCLINK = 4U;
      EPwm5Regs.EPWMXLINK.bit.CMPDLINK = 4U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm5Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm5Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm5Regs.HRPCTL.all = (EPwm5Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* SystemInitialize for SignalConversion generated from: '<S16>/Vpk' */
    cla2cpu_Vpk = 0.0;

    /* Start for MATLABSystem: '<S30>/DAC' */
    MW_ConfigureDACB();

    /* Start for MATLABSystem: '<S30>/DAC1' */
    MW_ConfigureDACC();

    /* End of SystemInitialize for S-Function (fcgen): '<S15>/Function-Call Generator' */

    /*  CLA Initialize*/
    EALLOW;

    /* Enable CLA */
    CpuSysRegs.PCLKCR0.bit.CLA1 = 1;

    /* Initialize and wait for CLA1ToCPUMsgRAM */
    MemCfgRegs.MSGxINIT.bit.INIT_CLA1TOCPU = 1;
    while (MemCfgRegs.MSGxINITDONE.bit.INITDONE_CLA1TOCPU != 1) {
    }

    /* Initialize and wait for CPUToCLA1MsgRAM */
    MemCfgRegs.MSGxINIT.bit.INIT_CPUTOCLA1 = 1;
    while (MemCfgRegs.MSGxINITDONE.bit.INITDONE_CPUTOCLA1 != 1) {
    }

    MemCfgRegs.LSxMSEL.all = 0x555;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS3 = 0;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS4 = 1;
    MemCfgRegs.LSxCLAPGM.bit.CLAPGM_LS5 = 1;
    Cla1Regs.MCTL.bit.IACKE = 1;
    EDIS;
    EALLOW;
    Cla1Regs.MVECT1 = (Uint16)(&Cla1Task1);
    Cla1Regs.MIER.bit.INT1 = 1;
    EDIS;

    /* Start for S-Function (c280xgpio_di): '<S13>/PFC_EN_GPIO60' */
    EALLOW;
    GpioCtrlRegs.GPBMUX2.all &= 0xFCFFFFFFU;
    GpioCtrlRegs.GPBDIR.all &= 0xEFFFFFFFU;
    EDIS;
    npc_controller_DWork.fault = false;
    npc_controller_DWork.fut_en = false;
    npc_controller_DWork.start_cnt = 0.0;
    npc_controller_DWork.relayOff_cnt = 0.0;
    npc_controller_DWork.relay_cnt = 0.0;
    npc_controller_DWork.eoss_cnt = 0.0;
    npc_controller_DWork.delay_cnt = 0.0;
    npc_controller_B.state = 0U;
    npc_controller_B.calib_ok = false;
    npc_controller_B.control_en = false;
    npc_controller_B.burst_en = false;
    npc_controller_B.eoss = false;
    cpu2cla_ref = 0.0F;
    cpu2cla_pha_en = false;
    cpu2cla_phb_en = false;
    cpu2cla_phc_en = false;
    cpu2cla_pfc_ok2 = false;
    npc_controller_B.relay_ctrl = false;
    npc_controller_B.tfv_v_UvpOvp = false;

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/updateCalib'
     */

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/detectUvpOvp'
     */
    /* SystemInitialize for Chart: '<S116>/OVP' */
    npc_controller_B.tfv_v_Ovp = 0.0;

    /* SystemInitialize for Chart: '<S116>/UVP' */
    npc_controller_B.tfv_v_Uvp = 0.0;

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/detectZCPhA'
     */
    npc_contro_detectZCPhA_Init(&npc_controller_B.detectZCPhA);

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/detectZCPhB'
     */
    npc_contro_detectZCPhA_Init(&npc_controller_B.detectZCPhB);

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/detectZCPhC'
     */
    npc_contro_detectZCPhA_Init(&npc_controller_B.detectZCPhC);

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/updateSequencePhA_burst'
     */
    /* SystemInitialize for S-Function (fcgen): '<S123>/Function-Call Generator' incorporates:
     *  SubSystem: '<S123>/pol_vxn1'
     */
    /* SystemInitialize for Chart: '<S145>/Chart2' */
    npc_controller_Chart2_Init(&npc_controller_B.sf_Chart2,
      &npc_controller_DWork.sf_Chart2);

    /* End of SystemInitialize for S-Function (fcgen): '<S123>/Function-Call Generator' */

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/updateSequencePhB_burst'
     */
    /* SystemInitialize for S-Function (fcgen): '<S124>/Function-Call Generator' incorporates:
     *  SubSystem: '<S124>/pol_vxn1'
     */
    /* SystemInitialize for Chart: '<S159>/Chart2' */
    npc_controller_Chart2_Init(&npc_controller_B.sf_Chart2_g,
      &npc_controller_DWork.sf_Chart2_g);

    /* End of SystemInitialize for S-Function (fcgen): '<S124>/Function-Call Generator' */

    /* SystemInitialize for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
     *  SubSystem: '<S112>/updateSequencePhC_burst'
     */
    /* SystemInitialize for S-Function (fcgen): '<S125>/Function-Call Generator' incorporates:
     *  SubSystem: '<S125>/pol_vxn1'
     */
    /* SystemInitialize for Chart: '<S173>/Chart2' */
    npc_controller_Chart2_Init(&npc_controller_B.sf_Chart2_p,
      &npc_controller_DWork.sf_Chart2_p);

    /* End of SystemInitialize for S-Function (fcgen): '<S125>/Function-Call Generator' */

    /* SystemInitialize for SignalConversion generated from: '<S13>/angle' */
    cpu2cla_angle = 0.0;

    /* Start for MATLABSystem: '<S113>/Validate_DI' */
    /*  Perform one-time calculations, such as computing constants */
    npc_controller_DWork.obj_nw.din_state = false;
    npc_controller_DWork.obj_nw.cnt = 0U;

    /* End of SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' */
    /*  Initialize / reset discrete-state properties */

    /* SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' incorporates:
     *  SubSystem: '<Root>/CANRX'
     */
    npc_controller_CANRX_Init(&npc_controller_B.CANRX);

    /* End of SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' */
    npc_controller_DWork.is_active_c3_npc_controller = 0U;

    /* SystemInitialize for S-Function (idletask): '<S187>/Idle Task' incorporates:
     *  SubSystem: '<S187>/IDLE'
     */

    /* System initialize for function-call system: '<S187>/IDLE' */
    {
      uint16_T rtb_DataStoreRead_dj;

      /* SystemInitialize for S-Function (fcgen): '<S190>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S190>/idle_task'
       */
      /* SystemInitialize for IfAction SubSystem: '<S296>/hkeep' */
      /* SystemInitialize for S-Function (fcgen): '<S300>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S300>/tz'
       */

      /* SystemInitialize for S-Function (fcgen): '<S300>/Function-Call Generator1' incorporates:
       *  SubSystem: '<S300>/tfv'
       */
      npc_controller_DWork.is_active_c23_npc_controller = 0U;

      /* SystemInitialize for Chart: '<S326>/hkeep1' incorporates:
       *  SubSystem: '<S328>/HKEEP.tfvVa'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem);

      /* SystemInitialize for Chart: '<S326>/hkeep1' incorporates:
       *  SubSystem: '<S328>/HKEEP.tfvVb'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n);

      /* SystemInitialize for Chart: '<S326>/hkeep1' incorporates:
       *  SubSystem: '<S328>/HKEEP.tfvVc'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2);

      /* SystemInitialize for Chart: '<S326>/hkeep1' incorporates:
       *  SubSystem: '<S328>/HKEEP.tfvVbulk'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2n);

      /* SystemInitialize for Chart: '<S326>/hkeep1' incorporates:
       *  SubSystem: '<S328>/HKEEP.tfvVmid'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2nv);

      /* SystemInitialize for Chart: '<S326>/hkeep1' incorporates:
       *  SubSystem: '<S328>/HKEEP.tfvVaux'
       */
      npc_contr_MATLABSystem_Init(&npc_controller_DWork.MATLABSystem_n2nvq);

      /* End of SystemInitialize for S-Function (fcgen): '<S300>/Function-Call Generator1' */
      /* End of SystemInitialize for SubSystem: '<S296>/hkeep' */

      /* SystemInitialize for IfAction SubSystem: '<S296>/report_adc' */
      /* Start for S-Function (c280xgpio_do): '<S301>/GPIO86' */
      EALLOW;
      GpioCtrlRegs.GPCMUX2.all &= 0xFFFFCFFFU;
      GpioCtrlRegs.GPCDIR.all |= 0x400000U;
      EDIS;

      /* End of SystemInitialize for SubSystem: '<S296>/report_adc' */
      /* End of SystemInitialize for S-Function (fcgen): '<S190>/Function-Call Generator1' */
    }

    /* End of SystemInitialize for S-Function (idletask): '<S187>/Idle Task' */

    /* SystemInitialize for S-Function (fcgen): '<S191>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S191>/epwm'
     */

    /* user code (Initialize function Body) */

    /* System '<S191>/epwm' */

    /*Initialize pwm sync*/
    EALLOW;
    XBAR_setInputPin(XBAR_INPUT5, 0);  //EXTSYNC1 from PWM1A
    SyncSocRegs.SYNCSELECT.bit.EPWM4SYNCIN = 0b101;//Sync PWM4 group to EXTSYNC1
    SyncSocRegs.SYNCSELECT.bit.EPWM7SYNCIN = 0b101;//Sync PWM7 group to EXTSYNC1
    SyncSocRegs.SYNCSELECT.bit.EPWM10SYNCIN = 0b101;//Sync PWM10 group to EXTSYNC1
    EDIS;

    /*Force PWM to LOW*/
    EPwm2Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm2Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm7Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm7Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm8Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm8Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm9Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm9Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm10Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm10Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);
    EPwm11Regs.AQCSFRC.bit.CSFA = (uint16_T)(0b01);
    EPwm11Regs.AQCSFRC.bit.CSFB = (uint16_T)(0b01);

    /* SystemInitialize for S-Function (fcgen): '<S191>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S191>/orps&relay'
     */
    /* Start for S-Function (c2802xpwm): '<S376>/ePWM2 - ORPS4' */

    /*** Initialize ePWM6 modules ***/
    {
      /*  // Time Base Control Register
         EPwm6Regs.TBCTL.bit.CTRMODE              = 2U;          // Counter Mode
         EPwm6Regs.TBCTL.bit.SYNCOSEL             = 1U;          // Sync Output Select

         EPwm6Regs.TBCTL.bit.PRDLD                = 0U;          // Shadow select

         EPwm6Regs.TBCTL2.bit.PRDLDSYNC           = 0U;          // Shadow select

         EPwm6Regs.TBCTL.bit.PHSEN                = 1U;          // Phase Load Enable
         EPwm6Regs.TBCTL.bit.PHSDIR               = 0U;          // Phase Direction Bit
         EPwm6Regs.TBCTL.bit.HSPCLKDIV            = 0U;          // High Speed TBCLK Pre-scaler
         EPwm6Regs.TBCTL.bit.CLKDIV               = 0U;          // Time Base Clock Pre-scaler
       */
      EPwm6Regs.TBCTL.all = (EPwm6Regs.TBCTL.all & ~0x3FFFU) | 0x16U;
      EPwm6Regs.TBCTL2.all = (EPwm6Regs.TBCTL2.all & ~0xC000U) | 0x0U;

      /*-- Setup Time-Base (TB) Submodule --*/
      EPwm6Regs.TBPRD = 1538U;         // Time Base Period Register

      /* // Time-Base Phase Register
         EPwm6Regs.TBPHS.bit.TBPHS               = 0U;          // Phase offset register
       */
      EPwm6Regs.TBPHS.all = (EPwm6Regs.TBPHS.all & ~0xFFFF0000U) | 0x0U;

      // Time Base Counter Register
      EPwm6Regs.TBCTR = 0x0000U;       /* Clear counter*/

      /*-- Setup Counter_Compare (CC) Submodule --*/
      /*	// Counter Compare Control Register

         EPwm6Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
         EPwm6Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
         EPwm6Regs.CMPCTL.bit.LOADAMODE           = 1U;          // Active Compare A Load
         EPwm6Regs.CMPCTL.bit.LOADBMODE           = 1U;          // Active Compare B Load
         EPwm6Regs.CMPCTL.bit.SHDWAMODE           = 0U;          // Compare A Register Block Operating Mode
         EPwm6Regs.CMPCTL.bit.SHDWBMODE           = 0U;          // Compare B Register Block Operating Mode
       */
      EPwm6Regs.CMPCTL.all = (EPwm6Regs.CMPCTL.all & ~0x3C5FU) | 0x5U;

      /* EPwm6Regs.CMPCTL2.bit.SHDWCMODE           = 0U;          // Compare C Register Block Operating Mode
         EPwm6Regs.CMPCTL2.bit.SHDWDMODE           = 0U;          // Compare D Register Block Operating Mode
         EPwm6Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
         EPwm6Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
         EPwm6Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
         EPwm6Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
       */
      EPwm6Regs.CMPCTL2.all = (EPwm6Regs.CMPCTL2.all & ~0x3C5FU) | 0x0U;
      EPwm6Regs.CMPA.bit.CMPA = 744U;  // Counter Compare A Register
      EPwm6Regs.CMPB.bit.CMPB = 794U;  // Counter Compare B Register
      EPwm6Regs.CMPC = 500U;           // Counter Compare C Register
      EPwm6Regs.CMPD = 500U;           // Counter Compare D Register

      /*-- Setup Action-Qualifier (AQ) Submodule --*/
      EPwm6Regs.AQCTLA.all = 144U;
                               // Action Qualifier Control Register For Output A
      EPwm6Regs.AQCTLB.all = 1536U;
                               // Action Qualifier Control Register For Output B

      /*	// Action Qualifier Software Force Register
         EPwm6Regs.AQSFRC.bit.RLDCSF              = 1U;          // Reload from Shadow Options
       */
      EPwm6Regs.AQSFRC.all = (EPwm6Regs.AQSFRC.all & ~0xC0U) | 0x40U;

      /*	// Action Qualifier Continuous S/W Force Register
         EPwm6Regs.AQCSFRC.bit.CSFA               = 0U;          // Continuous Software Force on output A
         EPwm6Regs.AQCSFRC.bit.CSFB               = 0U;          // Continuous Software Force on output B
       */
      EPwm6Regs.AQCSFRC.all = (EPwm6Regs.AQCSFRC.all & ~0xFU) | 0x0U;

      /*-- Setup Dead-Band Generator (DB) Submodule --*/
      /*	// Dead-Band Generator Control Register
         EPwm6Regs.DBCTL.bit.OUT_MODE             = 0U;          // Dead Band Output Mode Control
         EPwm6Regs.DBCTL.bit.IN_MODE              = 0U;          // Dead Band Input Select Mode Control
         EPwm6Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
         EPwm6Regs.DBCTL.bit.HALFCYCLE            = 0U;          // Half Cycle Clocking Enable
         EPwm6Regs.DBCTL.bit.SHDWDBREDMODE        = 0U;          // DBRED shadow mode
         EPwm6Regs.DBCTL.bit.SHDWDBFEDMODE        = 0U;          // DBFED shadow mode
         EPwm6Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
         EPwm6Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
       */
      EPwm6Regs.DBCTL.all = (EPwm6Regs.DBCTL.all & ~0x8FFFU) | 0x0U;
      EPwm6Regs.DBRED.bit.DBRED = (uint16_T)(0);
                         // Dead-Band Generator Rising Edge Delay Count Register
      EPwm6Regs.DBFED.bit.DBFED = (uint16_T)(0);
                        // Dead-Band Generator Falling Edge Delay Count Register

      /*-- Setup Event-Trigger (ET) Submodule --*/
      /*	// Event Trigger Selection and Pre-Scale Register
         EPwm6Regs.ETSEL.bit.SOCAEN               = 0U;          // Start of Conversion A Enable
         EPwm6Regs.ETSEL.bit.SOCASELCMP           = 0U;
         EPwm6Regs.ETSEL.bit.SOCASEL              = 1U;          // Start of Conversion A Select
         EPwm6Regs.ETPS.bit.SOCPSSEL              = 1U;          // EPWM6SOC Period Select
         EPwm6Regs.ETSOCPS.bit.SOCAPRD2           = 1U;
         EPwm6Regs.ETSEL.bit.SOCBEN               = 0U;          // Start of Conversion B Enable
         EPwm6Regs.ETSEL.bit.SOCBSELCMP           = 0U;
         EPwm6Regs.ETSEL.bit.SOCBSEL              = 1U;          // Start of Conversion A Select
         EPwm6Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM6SOCB Period Select
         EPwm6Regs.ETSOCPS.bit.SOCBPRD2           = 1U;
         EPwm6Regs.ETSEL.bit.INTEN                = 0U;          // EPWM6INTn Enable
         EPwm6Regs.ETSEL.bit.INTSELCMP            = 0U;
         EPwm6Regs.ETSEL.bit.INTSEL               = 1U;          // Start of Conversion A Select
         EPwm6Regs.ETPS.bit.INTPSSEL              = 1U;          // EPWM6INTn Period Select
         EPwm6Regs.ETINTPS.bit.INTPRD2            = 1U;
       */
      EPwm6Regs.ETSEL.all = (EPwm6Regs.ETSEL.all & ~0xFF7FU) | 0x1101U;
      EPwm6Regs.ETPS.all = (EPwm6Regs.ETPS.all & ~0x30U) | 0x30U;
      EPwm6Regs.ETSOCPS.all = (EPwm6Regs.ETSOCPS.all & ~0xF0FU) | 0x101U;
      EPwm6Regs.ETINTPS.all = (EPwm6Regs.ETINTPS.all & ~0xFU) | 0x1U;

      /*-- Setup PWM-Chopper (PC) Submodule --*/
      /*	// PWM Chopper Control Register
         EPwm6Regs.PCCTL.bit.CHPEN                = 0U;          // PWM chopping enable
         EPwm6Regs.PCCTL.bit.CHPFREQ              = 0U;          // Chopping clock frequency
         EPwm6Regs.PCCTL.bit.OSHTWTH              = 0U;          // One-shot pulse width
         EPwm6Regs.PCCTL.bit.CHPDUTY              = 0U;          // Chopping clock Duty cycle
       */
      EPwm6Regs.PCCTL.all = (EPwm6Regs.PCCTL.all & ~0x7FFU) | 0x0U;

      /*-- Set up Trip-Zone (TZ) Submodule --*/
      EALLOW;
      EPwm6Regs.TZSEL.all = 0U;        // Trip Zone Select Register

      /*	// Trip Zone Control Register
         EPwm6Regs.TZCTL.bit.TZA                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM6A
         EPwm6Regs.TZCTL.bit.TZB                  = 3U;          // TZ1 to TZ6 Trip Action On EPWM6B
         EPwm6Regs.TZCTL.bit.DCAEVT1              = 3U;          // EPWM6A action on DCAEVT1
         EPwm6Regs.TZCTL.bit.DCAEVT2              = 3U;          // EPWM6A action on DCAEVT2
         EPwm6Regs.TZCTL.bit.DCBEVT1              = 3U;          // EPWM6B action on DCBEVT1
         EPwm6Regs.TZCTL.bit.DCBEVT2              = 3U;          // EPWM6B action on DCBEVT2
       */
      EPwm6Regs.TZCTL.all = (EPwm6Regs.TZCTL.all & ~0xFFFU) | 0xFFFU;

      /*	// Trip Zone Enable Interrupt Register
         EPwm6Regs.TZEINT.bit.OST                 = 0U;          // Trip Zones One Shot Int Enable
         EPwm6Regs.TZEINT.bit.CBC                 = 0U;          // Trip Zones Cycle By Cycle Int Enable
         EPwm6Regs.TZEINT.bit.DCAEVT1             = 0U;          // Digital Compare A Event 1 Int Enable
         EPwm6Regs.TZEINT.bit.DCAEVT2             = 0U;          // Digital Compare A Event 2 Int Enable
         EPwm6Regs.TZEINT.bit.DCBEVT1             = 0U;          // Digital Compare B Event 1 Int Enable
         EPwm6Regs.TZEINT.bit.DCBEVT2             = 0U;          // Digital Compare B Event 2 Int Enable
       */
      EPwm6Regs.TZEINT.all = (EPwm6Regs.TZEINT.all & ~0x7EU) | 0x0U;

      /*	// Digital Compare A Control Register
         EPwm6Regs.DCACTL.bit.EVT1SYNCE           = 0U;          // DCAEVT1 SYNC Enable
         EPwm6Regs.DCACTL.bit.EVT1SOCE            = 1U;          // DCAEVT1 SOC Enable
         EPwm6Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCAEVT1 Force Sync Signal
         EPwm6Regs.DCACTL.bit.EVT1SRCSEL          = 0U;          // DCAEVT1 Source Signal
         EPwm6Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCAEVT2 Force Sync Signal
         EPwm6Regs.DCACTL.bit.EVT2SRCSEL          = 0U;          // DCAEVT2 Source Signal
       */
      EPwm6Regs.DCACTL.all = (EPwm6Regs.DCACTL.all & ~0x30FU) | 0x4U;

      /*	// Digital Compare B Control Register
         EPwm6Regs.DCBCTL.bit.EVT1SYNCE           = 0U;          // DCBEVT1 SYNC Enable
         EPwm6Regs.DCBCTL.bit.EVT1SOCE            = 0U;          // DCBEVT1 SOC Enable
         EPwm6Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0U;          // DCBEVT1 Force Sync Signal
         EPwm6Regs.DCBCTL.bit.EVT1SRCSEL          = 0U;          // DCBEVT1 Source Signal
         EPwm6Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0U;          // DCBEVT2 Force Sync Signal
         EPwm6Regs.DCBCTL.bit.EVT2SRCSEL          = 0U;          // DCBEVT2 Source Signal
       */
      EPwm6Regs.DCBCTL.all = (EPwm6Regs.DCBCTL.all & ~0x30FU) | 0x0U;

      /*	// Digital Compare Trip Select Register
         EPwm6Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0U;          // Digital Compare A High COMP Input Select

         EPwm6Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1U;          // Digital Compare A Low COMP Input Select
         EPwm6Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0U;          // Digital Compare B High COMP Input Select
         EPwm6Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1U;          // Digital Compare B Low COMP Input Select
       */
      EPwm6Regs.DCTRIPSEL.all = (EPwm6Regs.DCTRIPSEL.all & ~ 0xFFFFU) | 0x1010U;

      /*	// Trip Zone Digital Comparator Select Register
         EPwm6Regs.TZDCSEL.bit.DCAEVT1            = 0U;          // Digital Compare Output A Event 1
         EPwm6Regs.TZDCSEL.bit.DCAEVT2            = 0U;          // Digital Compare Output A Event 2
         EPwm6Regs.TZDCSEL.bit.DCBEVT1            = 0U;          // Digital Compare Output B Event 1
         EPwm6Regs.TZDCSEL.bit.DCBEVT2            = 0U;          // Digital Compare Output B Event 2
       */
      EPwm6Regs.TZDCSEL.all = (EPwm6Regs.TZDCSEL.all & ~0xFFFU) | 0x0U;

      /*	// Digital Compare Filter Control Register
         EPwm6Regs.DCFCTL.bit.BLANKE              = 0U;          // Blanking Enable/Disable
         EPwm6Regs.DCFCTL.bit.PULSESEL            = 1U;          // Pulse Select for Blanking & Capture Alignment
         EPwm6Regs.DCFCTL.bit.BLANKINV            = 0U;          // Blanking Window Inversion
         EPwm6Regs.DCFCTL.bit.SRCSEL              = 0U;          // Filter Block Signal Source Select
       */
      EPwm6Regs.DCFCTL.all = (EPwm6Regs.DCFCTL.all & ~0x3FU) | 0x10U;
      EPwm6Regs.DCFOFFSET = 0U;        // Digital Compare Filter Offset Register
      EPwm6Regs.DCFWINDOW = 0U;        // Digital Compare Filter Window Register

      /*	// Digital Compare Capture Control Register
         EPwm6Regs.DCCAPCTL.bit.CAPE              = 0U;          // Counter Capture Enable
       */
      EPwm6Regs.DCCAPCTL.all = (EPwm6Regs.DCCAPCTL.all & ~0x1U) | 0x0U;

      /*	// HRPWM Configuration Register
         EPwm6Regs.HRCNFG.bit.SWAPAB              = 0U;          // Swap EPWMA and EPWMB Outputs Bit
         EPwm6Regs.HRCNFG.bit.SELOUTB             = 0U;          // EPWMB Output Selection Bit
       */
      EPwm6Regs.HRCNFG.all = (EPwm6Regs.HRCNFG.all & ~0xA0U) | 0x0U;

      /* Update the Link Registers with the link value for all the Compare values and TBPRD */
      /* No error is thrown if the ePWM register exists in the model or not */
      EPwm6Regs.EPWMXLINK.bit.TBPRDLINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPALINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPBLINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPCLINK = 5U;
      EPwm6Regs.EPWMXLINK.bit.CMPDLINK = 5U;

      /* SYNCPER - Peripheral synchronization output event
         EPwm6Regs.HRPCTL.bit.PWMSYNCSEL            = 0U;          // EPWMSYNCPER selection
         EPwm6Regs.HRPCTL.bit.PWMSYNCSELX           = 0U;          //  EPWMSYNCPER selection
       */
      EPwm6Regs.HRPCTL.all = (EPwm6Regs.HRPCTL.all & ~0x72U) | 0x0U;
      EDIS;
    }

    /* SystemInitialize for S-Function (fcgen): '<S191>/Function-Call Generator1' incorporates:
     *  SubSystem: '<S191>/cmpss'
     */
    /* Start for MATLABSystem: '<S374>/CMPSS4H' */
    COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPH(COMPModuleValue, 0U, 0U, 0U, 0U, 1U, 0U);

    /* Start for MATLABSystem: '<S374>/CMPSS4L' */
    COMPModuleValue = MW_CMPSS4_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPL(COMPModuleValue, 0U, 1U);

    /* Start for MATLABSystem: '<S374>/CMPSS2H' */
    COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPH(COMPModuleValue, 0U, 0U, 0U, 0U, 1U, 0U);

    /* Start for MATLABSystem: '<S374>/CMPSS1H' */
    COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPH(COMPModuleValue, 0U, 0U, 0U, 0U, 1U, 0U);

    /* Start for MATLABSystem: '<S374>/CMPSS2L' */
    COMPModuleValue = MW_CMPSS2_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPL(COMPModuleValue, 0U, 1U);

    /* Start for MATLABSystem: '<S374>/CMPSS1L' */
    COMPModuleValue = MW_CMPSS1_MODULE_SELECT;
    MW_ConfigureCMPSS_COMPL(COMPModuleValue, 0U, 1U);

    /* End of SystemInitialize for S-Function (fcgen): '<S191>/Function-Call Generator1' */
  }
}

/* Model terminate function */
void npc_controller_terminate(void)
{
  /* Terminate for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt2' incorporates:
   *  SubSystem: '<Root>/CONTROL'
   */
  /* Termination for function-call system: '<Root>/CONTROL' */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/configFutEn'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/configFutDis'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/readCmpssOcp'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/updateCalib'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/disablePwm'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/updateSequencePhA_burst'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/updateSequencePhB_burst'
   */

  /* Terminate for Chart: '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' incorporates:
   *  SubSystem: '<S112>/updateSequencePhC_burst'
   */

  /* End of Terminate for S-Function (fcgen): '<S2>/Function-Call Generator' */

  /* Terminate for S-Function (idletask): '<S187>/Idle Task' incorporates:
   *  SubSystem: '<S187>/IDLE'
   */

  /* Termination for function-call system: '<S187>/IDLE' */

  /* Terminate for S-Function (fcgen): '<S190>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S190>/idle_task'
   */
  /* Terminate for IfAction SubSystem: '<S296>/hkeep' */
  /* Terminate for S-Function (fcgen): '<S300>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S300>/tz'
   */

  /* Terminate for S-Function (fcgen): '<S300>/Function-Call Generator1' incorporates:
   *  SubSystem: '<S300>/tfv'
   */
  /* Terminate for Chart: '<S326>/hkeep1' incorporates:
   *  SubSystem: '<S328>/HKEEP.tfvVa'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem);

  /* Terminate for Chart: '<S326>/hkeep1' incorporates:
   *  SubSystem: '<S328>/HKEEP.tfvVb'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n);

  /* Terminate for Chart: '<S326>/hkeep1' incorporates:
   *  SubSystem: '<S328>/HKEEP.tfvVc'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2);

  /* Terminate for Chart: '<S326>/hkeep1' incorporates:
   *  SubSystem: '<S328>/HKEEP.tfvVbulk'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2n);

  /* Terminate for Chart: '<S326>/hkeep1' incorporates:
   *  SubSystem: '<S328>/HKEEP.tfvVmid'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2nv);

  /* Terminate for Chart: '<S326>/hkeep1' incorporates:
   *  SubSystem: '<S328>/HKEEP.tfvVaux'
   */
  npc_contr_MATLABSystem_Term(&npc_controller_DWork.MATLABSystem_n2nvq);

  /* End of Terminate for S-Function (fcgen): '<S300>/Function-Call Generator1' */
  /* End of Terminate for SubSystem: '<S296>/hkeep' */
  /* End of Terminate for S-Function (fcgen): '<S190>/Function-Call Generator1' */

  /* End of Terminate for S-Function (idletask): '<S187>/Idle Task' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
