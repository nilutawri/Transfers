/*
 * File: CANRX.c
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.19
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 24 14:22:57 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "npc_controller.h"
#include "rtwtypes.h"
#include "CANRX.h"
#include "npc_controller_private.h"

/* System initialize for function-call system: '<Root>/CANRX' */
void npc_controller_CANRX_Init(rtB_CANRX_npc_controller *localB)
{
  /* SystemInitialize for IfAction SubSystem: '<S4>/Switch Case Action Subsystem' */
  /* Start for S-Function (c280xcanrcv): '<S5>/eCAN Receive' */
  {
    uint32_t ui32Flags;
    ui32Flags = CAN_MSG_OBJ_RX_INT_ENABLE;
    CAN_setupMessageObject(CANA_BASE, 10, 0x100, CAN_MSG_FRAME_STD,
      CAN_MSG_OBJ_TYPE_RX, 0, ui32Flags, sizeof(unsigned char) * 8);
  }

  /* Initialize out port */
  {
    localB->eCANReceive_o2[0] = (uint16_T)0.0;
    localB->eCANReceive_o2[1] = (uint16_T)0.0;
    localB->eCANReceive_o2[2] = (uint16_T)0.0;
    localB->eCANReceive_o2[3] = (uint16_T)0.0;
    localB->eCANReceive_o2[4] = (uint16_T)0.0;
    localB->eCANReceive_o2[5] = (uint16_T)0.0;
    localB->eCANReceive_o2[6] = (uint16_T)0.0;
    localB->eCANReceive_o2[7] = (uint16_T)0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S4>/Switch Case Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S4>/Switch Case Action Subsystem1' */
  /* Start for S-Function (c280xcanrcv): '<S6>/eCAN Receive1' */
  {
    uint32_t ui32Flags;
    ui32Flags = CAN_MSG_OBJ_RX_INT_ENABLE;
    CAN_setupMessageObject(CANA_BASE, 11, 0x102, CAN_MSG_FRAME_STD,
      CAN_MSG_OBJ_TYPE_RX, 0, ui32Flags, sizeof(unsigned char) * 8);
  }

  /* Initialize out port */
  {
    localB->eCANReceive1_o2[0] = (uint16_T)0.0;
    localB->eCANReceive1_o2[1] = (uint16_T)0.0;
    localB->eCANReceive1_o2[2] = (uint16_T)0.0;
    localB->eCANReceive1_o2[3] = (uint16_T)0.0;
    localB->eCANReceive1_o2[4] = (uint16_T)0.0;
    localB->eCANReceive1_o2[5] = (uint16_T)0.0;
    localB->eCANReceive1_o2[6] = (uint16_T)0.0;
    localB->eCANReceive1_o2[7] = (uint16_T)0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S4>/Switch Case Action Subsystem1' */

  /* SystemInitialize for IfAction SubSystem: '<S4>/Switch Case Action Subsystem2' */
  /* Start for S-Function (c280xcanrcv): '<S7>/eCAN Receive2' */
  {
    uint32_t ui32Flags;
    ui32Flags = CAN_MSG_OBJ_RX_INT_ENABLE;
    CAN_setupMessageObject(CANA_BASE, 12, 0x108, CAN_MSG_FRAME_STD,
      CAN_MSG_OBJ_TYPE_RX, 0, ui32Flags, sizeof(unsigned char) * 8);
  }

  /* Initialize out port */
  {
    localB->eCANReceive2_o2[0] = (uint16_T)0.0;
    localB->eCANReceive2_o2[1] = (uint16_T)0.0;
    localB->eCANReceive2_o2[2] = (uint16_T)0.0;
    localB->eCANReceive2_o2[3] = (uint16_T)0.0;
    localB->eCANReceive2_o2[4] = (uint16_T)0.0;
    localB->eCANReceive2_o2[5] = (uint16_T)0.0;
    localB->eCANReceive2_o2[6] = (uint16_T)0.0;
    localB->eCANReceive2_o2[7] = (uint16_T)0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S4>/Switch Case Action Subsystem2' */
  /* End of SystemInitialize for S-Function (fcgen): '<S1>/Function-Call Generator2' */
}

/* Output and update for function-call system: '<Root>/CANRX' */
void npc_controller_CANRX(boolean_T *rtd_b05_MB10Received, boolean_T
  *rtd_b06_MB11Received, boolean_T *rtd_b07_MB12Received, uint16_T
  rtd_u8CanDataRx10[8], uint16_T rtd_u8CanDataRx11[8], uint16_T
  rtd_u8CanDataRx12[8], rtB_CANRX_npc_controller *localB)
{
  uint32_T rtb_CANA_CAN0INT;
  int16_T i;

  /* S-Function (fcgen): '<S1>/Function-Call Generator2' incorporates:
   *  SubSystem: '<S1>/can_rcv'
   */
  /* S-Function (memorycopy): '<S4>/CANA_CAN0INT' */
  {
    uint32_T *memindsrc1 = (uint32_T *) ((CANA_BASE + CAN_O_INT));
    uint32_T *meminddst1 = (uint32_T *) (&rtb_CANA_CAN0INT);
    *(uint32_T *) (meminddst1) = *(uint32_T *) (memindsrc1);
  }

  /* SwitchCase: '<S4>/Switch Case' incorporates:
   *  S-Function (sfix_bitop): '<S4>/Bitwise AND'
   */
  switch ((int32_T)((int16_T)rtb_CANA_CAN0INT & 63)) {
   case 10L:
    /* Outputs for IfAction SubSystem: '<S4>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S5>/Action Port'
     */
    /* DataStoreWrite: '<S5>/Data Store Write1' incorporates:
     *  Constant: '<S5>/Constant'
     */
    *rtd_b05_MB10Received = true;

    /* S-Function (c280xcanrcv): '<S5>/eCAN Receive' */
    {
      unsigned char ucRXMsgData[8]= { 0, 0, 0, 0, 0, 0, 0, 0 };

      uint16_T status = 0;
      CAN_MsgFrameType frameType;
      uint32_T messageID = 0;
      uint32_T reqNewDataRegValue = (((uint32_T)0x1)<<9);
      uint32_T newDataReg = CAN_getNewDataFlags(CANA_BASE) & reqNewDataRegValue;
      if (newDataReg == reqNewDataRegValue) {
        status = CAN_readMessageWithID(CANA_BASE, 10, &frameType, &messageID,
          (uint16_T*)ucRXMsgData);
      }

      if ((newDataReg == reqNewDataRegValue)&&(status > 0)) {
        localB->eCANReceive_o2[0] = ucRXMsgData[0];
        localB->eCANReceive_o2[1] = ucRXMsgData[1];
        localB->eCANReceive_o2[2] = ucRXMsgData[2];
        localB->eCANReceive_o2[3] = ucRXMsgData[3];
        localB->eCANReceive_o2[4] = ucRXMsgData[4];
        localB->eCANReceive_o2[5] = ucRXMsgData[5];
        localB->eCANReceive_o2[6] = ucRXMsgData[6];
        localB->eCANReceive_o2[7] = ucRXMsgData[7];

        /* -- Call CAN RX Fcn-Call_0 -- */
      }
    }

    /* DataStoreWrite: '<S5>/Data Store Write' incorporates:
     *  S-Function (c280xcanrcv): '<S5>/eCAN Receive'
     */
    for (i = 0; i < 8; i++) {
      rtd_u8CanDataRx10[i] = localB->eCANReceive_o2[i];
    }

    /* End of DataStoreWrite: '<S5>/Data Store Write' */
    /* End of Outputs for SubSystem: '<S4>/Switch Case Action Subsystem' */
    break;

   case 11L:
    /* Outputs for IfAction SubSystem: '<S4>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S6>/Action Port'
     */
    /* DataStoreWrite: '<S6>/Data Store Write1' incorporates:
     *  Constant: '<S6>/Constant2'
     */
    *rtd_b06_MB11Received = true;

    /* S-Function (c280xcanrcv): '<S6>/eCAN Receive1' */
    {
      unsigned char ucRXMsgData[8]= { 0, 0, 0, 0, 0, 0, 0, 0 };

      uint16_T status = 0;
      CAN_MsgFrameType frameType;
      uint32_T messageID = 0;
      uint32_T reqNewDataRegValue = (((uint32_T)0x1)<<10);
      uint32_T newDataReg = CAN_getNewDataFlags(CANA_BASE) & reqNewDataRegValue;
      if (newDataReg == reqNewDataRegValue) {
        status = CAN_readMessageWithID(CANA_BASE, 11, &frameType, &messageID,
          (uint16_T*)ucRXMsgData);
      }

      if ((newDataReg == reqNewDataRegValue)&&(status > 0)) {
        localB->eCANReceive1_o2[0] = ucRXMsgData[0];
        localB->eCANReceive1_o2[1] = ucRXMsgData[1];
        localB->eCANReceive1_o2[2] = ucRXMsgData[2];
        localB->eCANReceive1_o2[3] = ucRXMsgData[3];
        localB->eCANReceive1_o2[4] = ucRXMsgData[4];
        localB->eCANReceive1_o2[5] = ucRXMsgData[5];
        localB->eCANReceive1_o2[6] = ucRXMsgData[6];
        localB->eCANReceive1_o2[7] = ucRXMsgData[7];

        /* -- Call CAN RX Fcn-Call_0 -- */
      }
    }

    /* DataStoreWrite: '<S6>/Data Store Write3' incorporates:
     *  S-Function (c280xcanrcv): '<S6>/eCAN Receive1'
     */
    for (i = 0; i < 8; i++) {
      rtd_u8CanDataRx11[i] = localB->eCANReceive1_o2[i];
    }

    /* End of DataStoreWrite: '<S6>/Data Store Write3' */
    /* End of Outputs for SubSystem: '<S4>/Switch Case Action Subsystem1' */
    break;

   case 12L:
    /* Outputs for IfAction SubSystem: '<S4>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* DataStoreWrite: '<S7>/Data Store Write2' incorporates:
     *  Constant: '<S7>/Constant2'
     */
    *rtd_b07_MB12Received = true;

    /* S-Function (c280xcanrcv): '<S7>/eCAN Receive2' */
    {
      unsigned char ucRXMsgData[8]= { 0, 0, 0, 0, 0, 0, 0, 0 };

      uint16_T status = 0;
      CAN_MsgFrameType frameType;
      uint32_T messageID = 0;
      uint32_T reqNewDataRegValue = (((uint32_T)0x1)<<11);
      uint32_T newDataReg = CAN_getNewDataFlags(CANA_BASE) & reqNewDataRegValue;
      if (newDataReg == reqNewDataRegValue) {
        status = CAN_readMessageWithID(CANA_BASE, 12, &frameType, &messageID,
          (uint16_T*)ucRXMsgData);
      }

      if ((newDataReg == reqNewDataRegValue)&&(status > 0)) {
        localB->eCANReceive2_o2[0] = ucRXMsgData[0];
        localB->eCANReceive2_o2[1] = ucRXMsgData[1];
        localB->eCANReceive2_o2[2] = ucRXMsgData[2];
        localB->eCANReceive2_o2[3] = ucRXMsgData[3];
        localB->eCANReceive2_o2[4] = ucRXMsgData[4];
        localB->eCANReceive2_o2[5] = ucRXMsgData[5];
        localB->eCANReceive2_o2[6] = ucRXMsgData[6];
        localB->eCANReceive2_o2[7] = ucRXMsgData[7];

        /* -- Call CAN RX Fcn-Call_0 -- */
      }
    }

    /* DataStoreWrite: '<S7>/Data Store Write1' incorporates:
     *  S-Function (c280xcanrcv): '<S7>/eCAN Receive2'
     */
    for (i = 0; i < 8; i++) {
      rtd_u8CanDataRx12[i] = localB->eCANReceive2_o2[i];
    }

    /* End of DataStoreWrite: '<S7>/Data Store Write1' */
    /* End of Outputs for SubSystem: '<S4>/Switch Case Action Subsystem2' */
    break;

   default:
    /* no actions */
    break;
  }

  /* End of SwitchCase: '<S4>/Switch Case' */
  /* End of Outputs for S-Function (fcgen): '<S1>/Function-Call Generator2' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
