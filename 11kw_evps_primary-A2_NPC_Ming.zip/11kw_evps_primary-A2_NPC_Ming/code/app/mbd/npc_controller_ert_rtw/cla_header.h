/*
 * File: cla_header.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.19
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 24 14:22:57 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_cla_header_h_
#define RTW_HEADER_cla_header_h_
#include "rtwtypes.h"
#include "npc_controller_types.h"

/* Exported data declaration */

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Declaration for custom storage class: Cla1DataRam */
#if defined(PRAGMA_FLAG_ia_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid1) || !defined(__TMS320C28XX_CLA__)

extern real32_T ia_pid1;               /* '<S27>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid1)
#define PRAGMA_FLAG_ia_pid1
#endif

#if defined(PRAGMA_FLAG_ia_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid2) || !defined(__TMS320C28XX_CLA__)

extern real32_T ia_pid2;               /* '<S27>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid2)
#define PRAGMA_FLAG_ia_pid2
#endif

#if defined(PRAGMA_FLAG_ia_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid3) || !defined(__TMS320C28XX_CLA__)

extern real32_T ia_pid3;               /* '<S27>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid3)
#define PRAGMA_FLAG_ia_pid3
#endif

#if defined(PRAGMA_FLAG_ia_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ia_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ia_pid4) || !defined(__TMS320C28XX_CLA__)

extern real32_T ia_pid4;               /* '<S27>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ia_pid4)
#define PRAGMA_FLAG_ia_pid4
#endif

#if defined(PRAGMA_FLAG_ib_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid1) || !defined(__TMS320C28XX_CLA__)

extern real32_T ib_pid1;               /* '<S28>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid1)
#define PRAGMA_FLAG_ib_pid1
#endif

#if defined(PRAGMA_FLAG_ib_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid2) || !defined(__TMS320C28XX_CLA__)

extern real32_T ib_pid2;               /* '<S28>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid2)
#define PRAGMA_FLAG_ib_pid2
#endif

#if defined(PRAGMA_FLAG_ib_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid3) || !defined(__TMS320C28XX_CLA__)

extern real32_T ib_pid3;               /* '<S28>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid3)
#define PRAGMA_FLAG_ib_pid3
#endif

#if defined(PRAGMA_FLAG_ib_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ib_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ib_pid4) || !defined(__TMS320C28XX_CLA__)

extern real32_T ib_pid4;               /* '<S28>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ib_pid4)
#define PRAGMA_FLAG_ib_pid4
#endif

#if defined(PRAGMA_FLAG_ic_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid1) || !defined(__TMS320C28XX_CLA__)

extern real32_T ic_pid1;               /* '<S29>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid1)
#define PRAGMA_FLAG_ic_pid1
#endif

#if defined(PRAGMA_FLAG_ic_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid2) || !defined(__TMS320C28XX_CLA__)

extern real32_T ic_pid2;               /* '<S29>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid2)
#define PRAGMA_FLAG_ic_pid2
#endif

#if defined(PRAGMA_FLAG_ic_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid3) || !defined(__TMS320C28XX_CLA__)

extern real32_T ic_pid3;               /* '<S29>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid3)
#define PRAGMA_FLAG_ic_pid3
#endif

#if defined(PRAGMA_FLAG_ic_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(ic_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_ic_pid4) || !defined(__TMS320C28XX_CLA__)

extern real32_T ic_pid4;               /* '<S29>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_ic_pid4)
#define PRAGMA_FLAG_ic_pid4
#endif

#if defined(PRAGMA_FLAG_vbulk_delay1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_delay1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay1) || !defined(__TMS320C28XX_CLA__)

extern real32_T vbulk_delay1;          /* '<S21>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay1)
#define PRAGMA_FLAG_vbulk_delay1
#endif

#if defined(PRAGMA_FLAG_vbulk_delay2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_delay2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay2) || !defined(__TMS320C28XX_CLA__)

extern real32_T vbulk_delay2;          /* '<S21>/Delay' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_delay2)
#define PRAGMA_FLAG_vbulk_delay2
#endif

#if defined(PRAGMA_FLAG_vbulk_pid1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid1) || !defined(__TMS320C28XX_CLA__)

extern real32_T vbulk_pid1;            /* '<S31>/Delay2' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid1)
#define PRAGMA_FLAG_vbulk_pid1
#endif

#if defined(PRAGMA_FLAG_vbulk_pid2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid2) || !defined(__TMS320C28XX_CLA__)

extern real32_T vbulk_pid2;            /* '<S31>/Delay3' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid2)
#define PRAGMA_FLAG_vbulk_pid2
#endif

#if defined(PRAGMA_FLAG_vbulk_pid3) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid3,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid3) || !defined(__TMS320C28XX_CLA__)

extern real32_T vbulk_pid3;            /* '<S31>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid3)
#define PRAGMA_FLAG_vbulk_pid3
#endif

#if defined(PRAGMA_FLAG_vbulk_pid4) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vbulk_pid4,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid4) || !defined(__TMS320C28XX_CLA__)

extern real32_T vbulk_pid4;            /* '<S31>/Delay4' */

#endif

#if !defined(PRAGMA_FLAG_vbulk_pid4)
#define PRAGMA_FLAG_vbulk_pid4
#endif

#if defined(PRAGMA_FLAG_vmid_delay1) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vmid_delay1,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vmid_delay1) || !defined(__TMS320C28XX_CLA__)

extern real32_T vmid_delay1;           /* '<S20>/Delay1' */

#endif

#if !defined(PRAGMA_FLAG_vmid_delay1)
#define PRAGMA_FLAG_vmid_delay1
#endif

#if defined(PRAGMA_FLAG_vmid_delay2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(vmid_delay2,"Cla1DataRam0")

#endif

#if !defined(PRAGMA_FLAG_vmid_delay2) || !defined(__TMS320C28XX_CLA__)

extern real32_T vmid_delay2;           /* '<S20>/Delay' */

#endif

#if !defined(PRAGMA_FLAG_vmid_delay2)
#define PRAGMA_FLAG_vmid_delay2
#endif

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Declaration for custom storage class: Cla1ToCpuMsgRAM */
#if defined(PRAGMA_FLAG_cla2cpu_Ipk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla2cpu_Ipk,"Cla1ToCpuMsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Ipk) || !defined(__TMS320C28XX_CLA__)

extern real32_T cla2cpu_Ipk;           /* '<S59>/Switch2' */

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Ipk)
#define PRAGMA_FLAG_cla2cpu_Ipk
#endif

#if defined(PRAGMA_FLAG_cla2cpu_Vpk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cla2cpu_Vpk,"Cla1ToCpuMsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Vpk) || !defined(__TMS320C28XX_CLA__)

extern real_T cla2cpu_Vpk;

#endif

#if !defined(PRAGMA_FLAG_cla2cpu_Vpk)
#define PRAGMA_FLAG_cla2cpu_Vpk
#endif

/* ifdef logic to delare in C28x and CLA , but define only in C28x */
/* Declaration for custom storage class: CpuToCla1MsgRAM */
#if defined(PRAGMA_FLAG_cpu2cla_angle) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_angle,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_angle) || !defined(__TMS320C28XX_CLA__)

extern real_T cpu2cla_angle;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_angle)
#define PRAGMA_FLAG_cpu2cla_angle
#endif

#if defined(PRAGMA_FLAG_cpu2cla_control_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_control_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_control_en) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_control_en;   /* '<S2>/Data Store Read' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_control_en)
#define PRAGMA_FLAG_cpu2cla_control_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ia) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ia,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ia) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_ia;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ia)
#define PRAGMA_FLAG_cpu2cla_ia
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ib) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ib,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ib) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_ib;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ib)
#define PRAGMA_FLAG_cpu2cla_ib
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ic) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ic,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ic) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_ic;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ic)
#define PRAGMA_FLAG_cpu2cla_ic
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pfc_ok2) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pfc_ok2,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pfc_ok2) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_pfc_ok2;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pfc_ok2)
#define PRAGMA_FLAG_cpu2cla_pfc_ok2
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pha_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pha_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pha_en) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_pha_en;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pha_en)
#define PRAGMA_FLAG_cpu2cla_pha_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_phb_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_phb_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phb_en) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_phb_en;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phb_en)
#define PRAGMA_FLAG_cpu2cla_phb_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_phc_en) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_phc_en,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phc_en) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_phc_en;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_phc_en)
#define PRAGMA_FLAG_cpu2cla_phc_en
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pol_pha) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pol_pha,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_pha) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_pol_pha;      /* '<S12>/GreaterThan' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_pha)
#define PRAGMA_FLAG_cpu2cla_pol_pha
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pol_phb) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pol_phb,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phb) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_pol_phb;      /* '<S12>/GreaterThan1' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phb)
#define PRAGMA_FLAG_cpu2cla_pol_phb
#endif

#if defined(PRAGMA_FLAG_cpu2cla_pol_phc) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_pol_phc,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phc) || !defined(__TMS320C28XX_CLA__)

extern boolean_T cpu2cla_pol_phc;      /* '<S12>/GreaterThan2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_pol_phc)
#define PRAGMA_FLAG_cpu2cla_pol_phc
#endif

#if defined(PRAGMA_FLAG_cpu2cla_ref) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_ref,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ref) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_ref;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_ref)
#define PRAGMA_FLAG_cpu2cla_ref
#endif

#if defined(PRAGMA_FLAG_cpu2cla_van) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_van,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_van) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_van;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_van)
#define PRAGMA_FLAG_cpu2cla_van
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vbn) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vbn,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbn) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_vbn;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbn)
#define PRAGMA_FLAG_cpu2cla_vbn
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vbulk) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vbulk,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbulk) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_vbulk;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vbulk)
#define PRAGMA_FLAG_cpu2cla_vbulk
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vcn) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vcn,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vcn) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_vcn;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vcn)
#define PRAGMA_FLAG_cpu2cla_vcn
#endif

#if defined(PRAGMA_FLAG_cpu2cla_vmid) && !defined(__TMS320C28XX_CLA__)

#pragma DATA_SECTION(cpu2cla_vmid,"CpuToCla1MsgRAM")

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vmid) || !defined(__TMS320C28XX_CLA__)

extern real32_T cpu2cla_vmid;

#endif

#if !defined(PRAGMA_FLAG_cpu2cla_vmid)
#define PRAGMA_FLAG_cpu2cla_vmid
#endif
#endif                                 /* RTW_HEADER_cla_header_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
