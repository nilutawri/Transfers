/*
 * File: npc_controller.h
 *
 * Code generated for Simulink model 'npc_controller'.
 *
 * Model version                  : 6.19
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 24 14:22:57 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_npc_controller_h_
#define RTW_HEADER_npc_controller_h_
#ifndef npc_controller_COMMON_INCLUDES_
#define npc_controller_COMMON_INCLUDES_
#include <string.h>
#include <math.h>
#include "rtwtypes.h"
#include "c2000BoardSupport.h"
#include "MW_f2837xS_includes.h"
#include "IQmathLib.h"
#include "can_message.h"
#include "F2837xS_device.h"
#include "MW_c2000DAC.h"
#include "MW_c28xCMPSS.h"
#endif                                 /* npc_controller_COMMON_INCLUDES_ */

#include "npc_controller_types.h"
#include "CANRX.h"
#include "rt_nonfinite.h"
#include <stddef.h>
#include "MW_target_hardware_resources.h"

/* Includes for objects with custom storage classes */
#include "cla_header.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

extern void init_eCAN_A ( uint16_T bitRatePrescaler, uint16_T timeSeg1, uint16_T
  timeSeg2, uint16_T sbg, uint16_T sjw, uint16_T sam);
extern void initializeOverrunService();
extern void executeOverrunService();
extern void config_ePWMSyncSource(void);
extern void config_ePWM_GPIO (void);
extern void config_ePWM_TBSync (void);
extern void config_ePWM_XBAR(void);
extern void configureIXbar(void);

/* user code (top of header file) */
//#include "adc.h"
#include "asysctl.h"

//#include "can.h"
#include "cla.h"
#include "cmpss.h"
#include "cpu.h"
#include "cputimer.h"
#include "dac.h"
#include "dcsm.h"
#include "debug.h"

//#include "dma.h"
//#include "ecap.h"
#include "emif.h"
#include "epwm.h"

//#include "eqep.h"
#include "flash.h"
#include "gpio.h"
#include "hrpwm.h"

//#include "i2c.h"
#include "interrupt.h"
#include "mcbsp.h"
#include "memcfg.h"
#include "pin_map.h"

//#include "sci.h"
//#include "sdfm.h"
//#include "spi.h"
#include "sysctl.h"

//#include "upp.h"
#include "version.h"
#include "xbar.h"

////#include "clb.h"
////#include "clb_config.h"
#include "ThermalModule.h"

/* user code (top of export header file) */
#include "can_message.h"

/* Block signals for system '<S112>/detectZCPhA' */
typedef struct {
  boolean_T Merge1;                    /* '<S117>/Merge1' */
} rtB_detectZCPhA_npc_controller;

/* Block signals for system '<S145>/Chart2' */
typedef struct {
  real32_T PWM_burst_en;               /* '<S145>/Chart2' */
} rtB_Chart2_npc_controller;

/* Block states (default storage) for system '<S145>/Chart2' */
typedef struct {
  uint16_T is_active_c44_npc_controller;/* '<S145>/Chart2' */
  uint16_T is_c44_npc_controller;      /* '<S145>/Chart2' */
} rtDW_Chart2_npc_controller;

/* Block signals for system '<S226>/Bit Shift' */
typedef struct {
  uint16_T y;                          /* '<S229>/bit_shift' */
} rtB_BitShift_npc_controller;

/* Block signals for system '<S187>/CAN_Task' */
typedef struct {
  CAN_DATATYPE CANPack1;               /* '<S248>/CAN Pack1' */
  CAN_DATATYPE CANPack1_p;             /* '<S247>/CAN Pack1' */
  CAN_DATATYPE CANPack1_g;             /* '<S246>/CAN Pack1' */
  CAN_DATATYPE CANPack1_i;             /* '<S245>/CAN Pack1' */
  CAN_DATATYPE CANPack1_c;             /* '<S244>/CAN Pack1' */
  CAN_DATATYPE CANPack1_h;             /* '<S225>/CAN Pack1' */
  CAN_DATATYPE CANPack1_k;             /* '<S224>/CAN Pack1' */
  CAN_DATATYPE CANPack1_l;             /* '<S222>/CAN Pack1' */
  uint16_T VectorConcatenate[8];       /* '<S248>/Vector Concatenate' */
  uint16_T VectorConcatenate_d[8];     /* '<S247>/Vector Concatenate' */
  uint16_T VectorConcatenate_e[8];     /* '<S246>/Vector Concatenate' */
  uint16_T VectorConcatenate_g[8];     /* '<S245>/Vector Concatenate' */
  uint16_T VectorConcatenate_c[8];     /* '<S244>/Vector Concatenate' */
  uint16_T VectorConcatenate_o[8];     /* '<S225>/Vector Concatenate' */
  uint16_T VectorConcatenate_b[8];     /* '<S224>/Vector Concatenate' */
  uint16_T DataStoreRead2[8];          /* '<S222>/Data Store Read2' */
  rtB_BitShift_npc_controller BitShift_ab;/* '<S286>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_cy;/* '<S285>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_g0;/* '<S284>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_jj;/* '<S283>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_a;/* '<S274>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_ij;/* '<S273>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_b;/* '<S272>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_du;/* '<S271>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_c;/* '<S264>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_i;/* '<S263>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_g;/* '<S262>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_ed;/* '<S253>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_d;/* '<S251>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_pb;/* '<S250>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_o;/* '<S249>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_eq;/* '<S237>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_f;/* '<S236>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_e;/* '<S235>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_p;/* '<S228>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_ji;/* '<S227>/Bit Shift' */
  rtB_BitShift_npc_controller BitShift_j;/* '<S226>/Bit Shift' */
} rtB_CAN_Task_npc_controller;

/* Block signals for system '<S302>/Bit Shift1' */
typedef struct {
  uint16_T y;                          /* '<S350>/bit_shift' */
} rtB_BitShift1_npc_controller;

/* Block signals for system '<S302>/Bit Shift2' */
typedef struct {
  uint16_T y;                          /* '<S354>/bit_shift' */
} rtB_BitShift2_npc_controller;

/* Block signals for system '<S302>/Bit Shift3' */
typedef struct {
  uint16_T y;                          /* '<S355>/bit_shift' */
} rtB_BitShift3_npc_controller;

/* Block signals for system '<S302>/Bit Shift4' */
typedef struct {
  uint16_T y;                          /* '<S356>/bit_shift' */
} rtB_BitShift4_npc_controller;

/* Block signals for system '<S302>/Bit Shift5' */
typedef struct {
  uint16_T y;                          /* '<S357>/bit_shift' */
} rtB_BitShift5_npc_controller;

/* Block signals for system '<S302>/Bit Shift6' */
typedef struct {
  uint16_T y;                          /* '<S358>/bit_shift' */
} rtB_BitShift6_npc_controller;

/* Block signals for system '<S302>/Bit Shift7' */
typedef struct {
  uint16_T y;                          /* '<S359>/bit_shift' */
} rtB_BitShift7_npc_controller;

/* Block signals for system '<S302>/Bit Shift8' */
typedef struct {
  uint16_T y;                          /* '<S360>/bit_shift' */
} rtB_BitShift8_npc_controller;

/* Block signals for system '<S329>/MATLAB System' */
typedef struct {
  uint16_T MATLABSystem;               /* '<S329>/MATLAB System' */
} rtB_MATLABSystem_npc_controller;

/* Block states (default storage) for system '<S329>/MATLAB System' */
typedef struct {
  tfv_latch_npc_controller obj;        /* '<S329>/MATLAB System' */
  uint16_T status;                     /* '<S329>/MATLAB System' */
  uint16_T ref;                        /* '<S329>/MATLAB System' */
  uint16_T now;                        /* '<S329>/MATLAB System' */
  uint16_T cnt;                        /* '<S329>/MATLAB System' */
  boolean_T objisempty;                /* '<S329>/MATLAB System' */
} rtDW_MATLABSystem_npc_controlle;

/* Block signals (default storage) */
typedef struct {
  real_T SFunction_o17;                /* '<S326>/hkeep1' */
  real_T SFunction_o18;                /* '<S326>/hkeep1' */
  real_T SFunction_o19;                /* '<S326>/hkeep1' */
  real_T SFunction_o20;                /* '<S326>/hkeep1' */
  real_T SFunction_o21;                /* '<S326>/hkeep1' */
  real_T SFunction_o22;                /* '<S326>/hkeep1' */
  real_T SFunction_o23;                /* '<S326>/hkeep1' */
  real_T SFunction_o24;                /* '<S326>/hkeep1' */
  real_T SFunction_o25;                /* '<S326>/hkeep1' */
  real_T SFunction_o26;                /* '<S326>/hkeep1' */
  real_T SFunction_o27;                /* '<S326>/hkeep1' */
  real_T SFunction_o28;                /* '<S326>/hkeep1' */
  real_T SFunction_o29;                /* '<S326>/hkeep1' */
  real_T SFunction_o30;                /* '<S326>/hkeep1' */
  real_T SFunction_o31;                /* '<S326>/hkeep1' */
  real_T SFunction_o17_n;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o18_k;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o19_g;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o20_g;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o21_i;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o34;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o35;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o39;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o40;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o44;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T SFunction_o45;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T tfv_v_Uvp;                    /* '<S116>/UVP' */
  real_T tfv_v_Ovp;                    /* '<S116>/OVP' */
  real32_T ADC6;                       /* '<S69>/ADC6' */
  real32_T ADC2;                       /* '<S69>/ADC2' */
  real32_T ADC5;                       /* '<S69>/ADC5' */
  real32_T ADC3;                       /* '<S69>/ADC3' */
  real32_T ADC4;                       /* '<S69>/ADC4' */
  real32_T ADC18;                      /* '<S68>/ADC18' */
  real32_T ADC5_b;                     /* '<S68>/ADC5' */
  real32_T ADC7;                       /* '<S68>/ADC7' */
  real32_T ADC3_n;                     /* '<S68>/ADC3' */
  real32_T ADC6_b;                     /* '<S68>/ADC6' */
  real32_T ADC17;                      /* '<S68>/ADC17' */
  real32_T ADC8;                       /* '<S68>/ADC8' */
  uint16_T input;                      /* '<S326>/hkeep1' */
  uint16_T assert_lim;                 /* '<S326>/hkeep1' */
  uint16_T assert_vld;                 /* '<S326>/hkeep1' */
  uint16_T deassert_lim;               /* '<S326>/hkeep1' */
  uint16_T deassert_vld;               /* '<S326>/hkeep1' */
  uint16_T input_a;                    /* '<S326>/hkeep1' */
  uint16_T assert_lim_h;               /* '<S326>/hkeep1' */
  uint16_T assert_vld_f;               /* '<S326>/hkeep1' */
  uint16_T deassert_lim_c;             /* '<S326>/hkeep1' */
  uint16_T deassert_vld_o;             /* '<S326>/hkeep1' */
  uint16_T input_n;                    /* '<S326>/hkeep1' */
  uint16_T assert_lim_c;               /* '<S326>/hkeep1' */
  uint16_T assert_vld_d;               /* '<S326>/hkeep1' */
  uint16_T deassert_lim_e;             /* '<S326>/hkeep1' */
  uint16_T deassert_vld_n;             /* '<S326>/hkeep1' */
  uint16_T input_j;                    /* '<S326>/hkeep1' */
  uint16_T assert_lim_p;               /* '<S326>/hkeep1' */
  uint16_T assert_vld_h;               /* '<S326>/hkeep1' */
  uint16_T deassert_lim_b;             /* '<S326>/hkeep1' */
  uint16_T deassert_vld_e;             /* '<S326>/hkeep1' */
  uint16_T input_m;                    /* '<S326>/hkeep1' */
  uint16_T assert_lim_b;               /* '<S326>/hkeep1' */
  uint16_T assert_vld_m;               /* '<S326>/hkeep1' */
  uint16_T deassert_lim_p;             /* '<S326>/hkeep1' */
  uint16_T deassert_vld_c;             /* '<S326>/hkeep1' */
  uint16_T input_ah;                   /* '<S326>/hkeep1' */
  uint16_T assert_lim_m;               /* '<S326>/hkeep1' */
  uint16_T assert_vld_k;               /* '<S326>/hkeep1' */
  uint16_T deassert_lim_py;            /* '<S326>/hkeep1' */
  uint16_T deassert_vld_j;             /* '<S326>/hkeep1' */
  uint16_T state;      /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T PFC_EN_GPIO60;             /* '<S13>/PFC_EN_GPIO60' */
  boolean_T calib_ok;  /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T control_en;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T burst_en;  /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T eoss;      /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T relay_ctrl;/* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T tfv_v_UvpOvp;
                       /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  rtB_BitShift7_npc_controller BitShift9_l;/* '<S299>/Bit Shift9' */
  rtB_BitShift5_npc_controller BitShift8_h;/* '<S299>/Bit Shift8' */
  rtB_BitShift4_npc_controller BitShift7_h;/* '<S299>/Bit Shift7' */
  rtB_BitShift6_npc_controller BitShift6_l;/* '<S299>/Bit Shift6' */
  rtB_BitShift3_npc_controller BitShift5_o;/* '<S299>/Bit Shift5' */
  rtB_BitShift2_npc_controller BitShift4_b;/* '<S299>/Bit Shift4' */
  rtB_BitShift1_npc_controller BitShift3_g;/* '<S299>/Bit Shift3' */
  rtB_BitShift8_npc_controller BitShift27;/* '<S299>/Bit Shift27' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2nvq;/* '<S329>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2nv;/* '<S329>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2n;/* '<S329>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n2;/* '<S329>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem_n;/* '<S329>/MATLAB System' */
  rtB_MATLABSystem_npc_controller MATLABSystem;/* '<S329>/MATLAB System' */
  rtB_BitShift8_npc_controller BitShift8;/* '<S302>/Bit Shift8' */
  rtB_BitShift7_npc_controller BitShift7;/* '<S302>/Bit Shift7' */
  rtB_BitShift6_npc_controller BitShift6;/* '<S302>/Bit Shift6' */
  rtB_BitShift5_npc_controller BitShift5;/* '<S302>/Bit Shift5' */
  rtB_BitShift4_npc_controller BitShift4;/* '<S302>/Bit Shift4' */
  rtB_BitShift3_npc_controller BitShift3;/* '<S302>/Bit Shift3' */
  rtB_BitShift2_npc_controller BitShift2;/* '<S302>/Bit Shift2' */
  rtB_BitShift1_npc_controller BitShift1;/* '<S302>/Bit Shift1' */
  rtB_CAN_Task_npc_controller CAN_Task;/* '<S187>/CAN_Task' */
  rtB_CANRX_npc_controller CANRX;      /* '<Root>/CANRX' */
  rtB_Chart2_npc_controller sf_Chart2_p;/* '<S173>/Chart2' */
  rtB_Chart2_npc_controller sf_Chart2_g;/* '<S159>/Chart2' */
  rtB_Chart2_npc_controller sf_Chart2; /* '<S145>/Chart2' */
  rtB_detectZCPhA_npc_controller detectZCPhC;/* '<S112>/detectZCPhC' */
  rtB_detectZCPhA_npc_controller detectZCPhB;/* '<S112>/detectZCPhB' */
  rtB_detectZCPhA_npc_controller detectZCPhA;/* '<S112>/detectZCPhA' */
} BlockIO_npc_controller;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T pos_seq;                      /* '<Root>/Data Store Memory71' */
  real_T rec_en;                       /* '<Root>/Data Store Memory72' */
  real_T can_on_cmd;                   /* '<Root>/Data Store Memory73' */
  real_T clllc_ok;                     /* '<Root>/Data Store Memory74' */
  real_T npc_fault;                    /* '<Root>/Data Store Memory75' */
  real_T inv_en;                       /* '<Root>/Data Store Memory76' */
  real_T state_control;                /* '<Root>/Data Store Memory77' */
  real_T can_timeout;                  /* '<Root>/Data Store Memory79' */
  real_T start_cnt;    /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T relayOff_cnt; /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T relay_cnt;    /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T eoss_cnt;     /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real_T delay_cnt;    /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  real32_T Delay1_DSTATE;              /* '<S336>/Delay1' */
  real32_T Delay_DSTATE;               /* '<S336>/Delay' */
  real32_T Delay1_DSTATE_p;            /* '<S337>/Delay1' */
  real32_T Delay_DSTATE_m;             /* '<S337>/Delay' */
  real32_T Delay1_DSTATE_c;            /* '<S335>/Delay1' */
  real32_T Delay_DSTATE_o;             /* '<S335>/Delay' */
  real32_T Delay2_DSTATE;              /* '<S141>/Delay2' */
  real32_T Delay2_DSTATE_l;            /* '<S140>/Delay2' */
  real32_T Delay2_DSTATE_i;            /* '<S139>/Delay2' */
  real32_T Delay2_DSTATE_m;            /* '<S138>/Delay2' */
  real32_T Delay2_DSTATE_j;            /* '<S137>/Delay2' */
  real32_T Delay2_DSTATE_n;            /* '<S136>/Delay2' */
  real32_T Delay_DSTATE_f;             /* '<S109>/Delay' */
  real32_T Delay_DSTATE_l;             /* '<S110>/Delay' */
  real32_T Delay_DSTATE_k;             /* '<S111>/Delay' */
  real32_T Delay_DSTATE_j;             /* '<S103>/Delay' */
  real32_T Delay_DSTATE_lx;            /* '<S104>/Delay' */
  real32_T Delay_DSTATE_mn;            /* '<S105>/Delay' */
  real32_T Delay_DSTATE_e;             /* '<S106>/Delay' */
  real32_T Delay_DSTATE_ef;            /* '<S107>/Delay' */
  real32_T Delay_DSTATE_d;             /* '<S108>/Delay' */
  real32_T f32IinA;                    /* '<Root>/f32IinA' */
  real32_T f32IinB;                    /* '<Root>/f32IinB' */
  real32_T f32IinC;                    /* '<Root>/f32IinC' */
  real32_T f32IphaseA;                 /* '<Root>/f32IphaseA' */
  real32_T f32IphaseB;                 /* '<Root>/f32IphaseB' */
  real32_T f32IphaseC;                 /* '<Root>/f32IphaseC' */
  real32_T f32Vaux;                    /* '<Root>/f32Vaux' */
  real32_T f32VinA;                    /* '<Root>/f32VinA' */
  real32_T f32VinB;                    /* '<Root>/f32VinB' */
  real32_T f32VinC;                    /* '<Root>/f32VinC' */
  real32_T f32Vpfc;                    /* '<Root>/f32Vpfc' */
  real32_T f32VpfcMid;                 /* '<Root>/f32VpfcMid' */
  real32_T adc_vmid;                   /* '<Root>/Data Store Memory1' */
  real32_T adc_va;                     /* '<Root>/Data Store Memory2' */
  real32_T adc_offset_vc;              /* '<Root>/Data Store Memory26' */
  real32_T adc_offset_ic;              /* '<Root>/Data Store Memory27' */
  real32_T adc_offset_vc_tmp;          /* '<Root>/Data Store Memory29' */
  real32_T adc_vb;                     /* '<Root>/Data Store Memory3' */
  real32_T adc_offset_ic_tmp;          /* '<Root>/Data Store Memory30' */
  real32_T adc_offset_vb;              /* '<Root>/Data Store Memory31' */
  real32_T adc_offset_ib;              /* '<Root>/Data Store Memory32' */
  real32_T adc_offset_vb_tmp;          /* '<Root>/Data Store Memory33' */
  real32_T adc_offset_ib_tmp;          /* '<Root>/Data Store Memory34' */
  real32_T adc_offset_va;              /* '<Root>/Data Store Memory35' */
  real32_T adc_offset_ia;              /* '<Root>/Data Store Memory36' */
  real32_T adc_offset_va_tmp;          /* '<Root>/Data Store Memory37' */
  real32_T adc_offset_ia_tmp;          /* '<Root>/Data Store Memory38' */
  real32_T rms_ib;                     /* '<Root>/Data Store Memory41' */
  real32_T rms_ic;                     /* '<Root>/Data Store Memory42' */
  real32_T rms_va;                     /* '<Root>/Data Store Memory43' */
  real32_T rms_vb;                     /* '<Root>/Data Store Memory44' */
  real32_T rms_vc;                     /* '<Root>/Data Store Memory47' */
  real32_T adc_temp_npcb;              /* '<Root>/Data Store Memory51' */
  real32_T adc_temp_npcc;              /* '<Root>/Data Store Memory52' */
  real32_T adc_temp_npca;              /* '<Root>/Data Store Memory53' */
  real32_T adc_vaux;                   /* '<Root>/Data Store Memory54' */
  real32_T rms_ia;                     /* '<Root>/Data Store Memory61' */
  real32_T rms_iphaseb;                /* '<Root>/Data Store Memory62' */
  real32_T rms_iphasec;                /* '<Root>/Data Store Memory63' */
  real32_T rms_iphasea;                /* '<Root>/Data Store Memory64' */
  real32_T adc_vbulk;                  /* '<Root>/Data Store Memory7' */
  real32_T adc_vc;                     /* '<Root>/Data Store Memory8' */
  real32_T otp_fault;                  /* '<Root>/Data Store Memory81' */
  real32_T f32GainLineCurrentCS;       /* '<Root>/f32IoutTarget1' */
  real32_T f32GainVbulk;               /* '<Root>/f32IoutTarget2' */
  real32_T f32GainVmid;                /* '<Root>/f32IoutTarget3' */
  real32_T f32GainLineCurrentHE;       /* '<Root>/f32IoutTarget4' */
  real32_T f32OffsetLineVoltage;       /* '<Root>/f32IoutTarget5' */
  real32_T f32GainLineVoltage;         /* '<Root>/f32IoutTarget6' */
  real32_T f32OffsetLineCurrentHE;     /* '<Root>/f32IoutTarget7' */
  real32_T f32OffsetLineCurrentCS;     /* '<Root>/f32IoutTarget8' */
  int32_T AC_OK_GPIO41_FRAC_LEN;       /* '<S187>/AC_OK_GPIO41' */
  int32_T RELAY_GPIO4_EPWM3A1_FRAC_LEN;/* '<S187>/RELAY_GPIO4_EPWM3A1' */
  int32_T PFC_OK_GPIO58_FRAC_LEN;      /* '<S187>/PFC_OK_GPIO58' */
  int32_T GPIO86_FRAC_LEN;             /* '<S301>/GPIO86' */
  Validate_DI_npc_controller obj_nw;   /* '<S113>/Validate_DI' */
  uint16_T cnt_1ms;                    /* '<Root>/Data Store Memory4' */
  uint16_T sPriFault;                  /* '<Root>/sPriFault' */
  uint16_T sPriStatus;                 /* '<Root>/sPriStatus' */
  uint16_T u16Debug0;                  /* '<Root>/u16Debug0' */
  uint16_T u16Debug1;                  /* '<Root>/u16Debug1' */
  uint16_T u16Debug2;                  /* '<Root>/u16Debug2' */
  uint16_T u16Debug3;                  /* '<Root>/u16Debug3' */
  uint16_T u16Debug4;                  /* '<Root>/u16Debug4' */
  uint16_T u16Debug5;                  /* '<Root>/u16Debug5' */
  uint16_T u16Reserved1;               /* '<Root>/u16Reserved1' */
  uint16_T u16TxDelayCount;            /* '<Root>/u16TxDelayCount' */
  uint16_T tz_ovp;                     /* '<Root>/Data Store Memory20' */
  uint16_T tz_ocp;                     /* '<Root>/Data Store Memory23' */
  uint16_T cnt_calib;                  /* '<Root>/Data Store Memory28' */
  uint16_T theta;                      /* '<Root>/Data Store Memory45' */
  uint16_T tz_cmpssocp;                /* '<Root>/Data Store Memory80' */
  uint16_T cnt_idle;                   /* '<Root>/Data Store Memory5' */
  boolean_T DelayInput1_DSTATE;        /* '<S183>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_j;      /* '<S169>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_a;      /* '<S155>/Delay Input1' */
  uint16_T u8CanDataRx10[8];           /* '<Root>/u8CanDataRx10' */
  uint16_T u8CanDataRx11[8];           /* '<Root>/u8CanDataRx11' */
  uint16_T u8CanDataRx12[8];           /* '<Root>/u8CanDataRx12' */
  uint16_T u8CanTxIndex;               /* '<Root>/u8CanTxIndex' */
  uint16_T u8FwRevData[8];             /* '<Root>/u8FwRevData' */
  uint16_T u8PriFutEnable;             /* '<Root>/u8PriFutEnable' */
  uint16_T u8RdReqMsgPntr;             /* '<Root>/u8RdReqMsgPntr' */
  uint16_T u8Reserved1;                /* '<Root>/u8Reserved1' */
  uint16_T u8TclllcP1;                 /* '<Root>/u8TclllcP1' */
  uint16_T u8TclllcP2;                 /* '<Root>/u8TclllcP2' */
  uint16_T u8ThermalFlags;             /* '<Root>/u8ThermalFlags' */
  uint16_T u8TnpcA;                    /* '<Root>/u8TnpcA' */
  uint16_T u8TnpcB;                    /* '<Root>/u8TnpcB' */
  uint16_T u8TnpcC;                    /* '<Root>/u8TnpcC' */
  uint16_T is_active_c23_npc_controller;/* '<S326>/hkeep1' */
  uint16_T is_active_c3_npc_controller;/* '<S187>/Chart1' */
  boolean_T relay_ctrl;                /* '<Root>/Data Store Memory65' */
  boolean_T pfc_ok;                    /* '<Root>/Data Store Memory66' */
  boolean_T ac_ok;                     /* '<Root>/Data Store Memory68' */
  boolean_T b00_DebugEnabled;          /* '<Root>/b00' */
  boolean_T b01_ReadRequest;           /* '<Root>/b01' */
  boolean_T b05_MB10Received;          /* '<Root>/b05' */
  boolean_T b06_MB11Received;          /* '<Root>/b06' */
  boolean_T b07_MB12Received;          /* '<Root>/b07' */
  boolean_T tfv_vbulk;                 /* '<Root>/Data Store Memory10' */
  boolean_T tfv_vmid;                  /* '<Root>/Data Store Memory11' */
  boolean_T tfv_va;                    /* '<Root>/Data Store Memory12' */
  boolean_T tfv_vb;                    /* '<Root>/Data Store Memory13' */
  boolean_T tfv_vc;                    /* '<Root>/Data Store Memory14' */
  boolean_T control_en;                /* '<Root>/Data Store Memory15' */
  boolean_T tfv_iphaseb;               /* '<Root>/Data Store Memory16' */
  boolean_T tfv_iphasec;               /* '<Root>/Data Store Memory17' */
  boolean_T tfv_vtop;                  /* '<Root>/Data Store Memory21' */
  boolean_T tfv_vaux;                  /* '<Root>/Data Store Memory39' */
  boolean_T tfv_iphasea;               /* '<Root>/Data Store Memory6' */
  boolean_T pfc_en;                    /* '<Root>/Data Store Memory67' */
  boolean_T fault;     /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  boolean_T fut_en;    /* '<S13>/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2nvq;/* '<S329>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2nv;/* '<S329>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2n;/* '<S329>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n2;/* '<S329>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem_n;/* '<S329>/MATLAB System' */
  rtDW_MATLABSystem_npc_controlle MATLABSystem;/* '<S329>/MATLAB System' */
  rtDW_Chart2_npc_controller sf_Chart2_p;/* '<S173>/Chart2' */
  rtDW_Chart2_npc_controller sf_Chart2_g;/* '<S159>/Chart2' */
  rtDW_Chart2_npc_controller sf_Chart2;/* '<S145>/Chart2' */
} D_Work_npc_controller;

/* Invariant block signals (default storage) */
typedef struct {
  const real_T Gain2;                  /* '<S374>/Gain2' */
  const real_T Gain3;                  /* '<S374>/Gain3' */
  const real_T Gain1;                  /* '<S374>/Gain1' */
  const real_T Gain4;                  /* '<S374>/Gain4' */
  const real_T Gain6;                  /* '<S374>/Gain6' */
  const real_T Gain5;                  /* '<S374>/Gain5' */
} ConstBlockIO_npc_controller;

/* Constant parameters (default storage) */
typedef struct {
  /* Pooled Parameter (Expression: [150
     149
     148
     147
     146
     145
     144
     143
     142
     141
     140
     139
     138
     137
     136
     135
     134
     133
     132
     131
     130
     129
     128
     127
     126
     125
     124
     123
     122
     121
     120
     119
     118
     117
     116
     115
     114
     113
     112
     111
     110
     109
     108
     107
     106
     105
     104
     103
     102
     101
     100
     99
     98
     97
     96
     95
     94
     93
     92
     91
     90
     89
     88
     87
     86
     85
     84
     83
     82
     81
     80
     79
     78
     77
     76
     75
     74
     73
     72
     71
     70
     69
     68
     67
     66
     65
     64
     63
     62
     61
     60
     59
     58
     57
     56
     55
     54
     53
     52
     51
     50
     49
     48
     47
     46
     45
     44
     43
     42
     41
     40
     39
     38
     37
     36
     35
     34
     33
     32
     31
     30
     29
     28
     27
     26
     25
     24
     23
     22
     21
     20
     19
     18
     17
     16
     15
     14
     13
     12
     11
     10
     9
     8
     7
     6
     5
     4
     3
     2
     1
     0
     -1
     -2
     -3
     -4
     -5
     -6
     -7
     -8
     -9
     -10
     -11
     -12
     -13
     -14
     -15
     -16
     -17
     -18
     -19
     -20
     -21
     -22
     -23
     -24
     -25
     -26
     -27
     -28
     -29
     -30
     -31
     -32
     -33
     -34
     -35
     -36
     -37
     -38
     -39
     -40
     ])
   * Referenced by:
   *   '<S301>/1-D Lookup Table1'
   *   '<S301>/1-D Lookup Table2'
   *   '<S301>/1-D Lookup Table3'
   */
  real32_T pooled42[191];

  /* Pooled Parameter (Expression: [369
     370
     372
     374
     376
     377
     379
     381
     383
     385
     387
     388
     390
     392
     394
     396
     398
     400
     402
     404
     406
     408
     410
     411
     413
     415
     417
     420
     422
     424
     426
     428
     430
     432
     434
     436
     438
     440
     442
     445
     447
     449
     451
     453
     456
     458
     460
     462
     465
     467
     469
     472
     474
     476
     479
     481
     483
     486
     488
     490
     493
     495
     498
     500
     503
     505
     508
     510
     513
     515
     518
     521
     523
     526
     528
     531
     534
     536
     539
     542
     544
     547
     550
     553
     555
     558
     561
     564
     567
     570
     573
     575
     578
     581
     584
     587
     590
     593
     596
     599
     602
     605
     608
     612
     615
     618
     621
     624
     627
     631
     634
     637
     640
     644
     647
     650
     653
     657
     660
     664
     667
     670
     674
     677
     681
     684
     688
     691
     695
     699
     702
     706
     710
     713
     717
     721
     724
     728
     732
     736
     739
     743
     747
     751
     755
     759
     763
     767
     770
     774
     778
     782
     787
     791
     795
     799
     803
     807
     811
     815
     819
     824
     828
     832
     836
     841
     845
     849
     853
     858
     862
     867
     871
     875
     880
     884
     889
     893
     897
     902
     906
     911
     915
     920
     925
     929
     934
     938
     943
     947
     952
     ])
   * Referenced by:
   *   '<S301>/1-D Lookup Table1'
   *   '<S301>/1-D Lookup Table2'
   *   '<S301>/1-D Lookup Table3'
   */
  real32_T pooled43[191];
} ConstParam_npc_controller;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T sim_adc_quantized;            /* '<Root>/sim_adc_quantized' */
} ExternalInputs_npc_controller;

/* Real-time Model Data Structure */
struct tag_RTM_npc_controller {
  const char_T * volatile errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint16_T TID[3];
    } TaskCounters;
  } Timing;
};

extern CAN_DATATYPE CAN_DATATYPE_GROUND;
extern CAN_DATATYPE CAN_DATATYPE_GROUND;
extern CAN_DATATYPE CAN_DATATYPE_GROUND;

/* Block signals (default storage) */
extern BlockIO_npc_controller npc_controller_B;

/* Block states (default storage) */
extern D_Work_npc_controller npc_controller_DWork;

/* External inputs (root inport signals with default storage) */
extern ExternalInputs_npc_controller npc_controller_U;
extern const ConstBlockIO_npc_controller npc_controller_ConstB;/* constant block i/o */

/* Constant parameters (default storage) */
extern const ConstParam_npc_controller npc_controller_ConstP;

/* External function called from main */
extern void npc_controller_SetEventsForThisBaseStep(boolean_T *eventFlags);

/* Model entry point functions */
extern void npc_controller_initialize(void);
extern void npc_controller_step0(void);
extern void npc_controller_step1(void);
extern void npc_controller_step2(void);
extern void npc_controller_terminate(void);
extern volatile boolean_T runModel;

/* Real-time Model object */
extern RT_MODEL_npc_controller *const npc_controller_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'npc_controller'
 * '<S1>'   : 'npc_controller/CANRX'
 * '<S2>'   : 'npc_controller/CONTROL'
 * '<S3>'   : 'npc_controller/IDLE_AND_TIMER'
 * '<S4>'   : 'npc_controller/CANRX/can_rcv'
 * '<S5>'   : 'npc_controller/CANRX/can_rcv/Switch Case Action Subsystem'
 * '<S6>'   : 'npc_controller/CANRX/can_rcv/Switch Case Action Subsystem1'
 * '<S7>'   : 'npc_controller/CANRX/can_rcv/Switch Case Action Subsystem2'
 * '<S8>'   : 'npc_controller/CONTROL/CONTROL'
 * '<S9>'   : 'npc_controller/CONTROL/GET_ADC'
 * '<S10>'  : 'npc_controller/CONTROL/GPIO_HIGH'
 * '<S11>'  : 'npc_controller/CONTROL/GPIO_LOW'
 * '<S12>'  : 'npc_controller/CONTROL/POLARITY'
 * '<S13>'  : 'npc_controller/CONTROL/STATE-MACHINE'
 * '<S14>'  : 'npc_controller/CONTROL/CONTROL/false'
 * '<S15>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL'
 * '<S16>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL'
 * '<S17>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/GPIO_HIGH'
 * '<S18>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/GPIO_LOW'
 * '<S19>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL'
 * '<S20>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/IIR Filter1'
 * '<S21>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/IIR Filter3'
 * '<S22>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/If Action Subsystem'
 * '<S23>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/If Action Subsystem1'
 * '<S24>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/Subsystem1'
 * '<S25>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/Subsystem2'
 * '<S26>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/midpoint voltage balancing'
 * '<S27>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia'
 * '<S28>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ib'
 * '<S29>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ic'
 * '<S30>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation'
 * '<S31>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole'
 * '<S32>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/2P2Z_para'
 * '<S33>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/Saturation Dynamic1'
 * '<S34>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ia/2P2Z_para/200V'
 * '<S35>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ib/2P2Z_para'
 * '<S36>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ib/Saturation Dynamic1'
 * '<S37>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ib/2P2Z_para/200V'
 * '<S38>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ic/2P2Z_para'
 * '<S39>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ic/Saturation Dynamic1'
 * '<S40>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pid_ic/2P2Z_para/200V'
 * '<S41>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem'
 * '<S42>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem1'
 * '<S43>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem2'
 * '<S44>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty'
 * '<S45>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty1'
 * '<S46>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty2'
 * '<S47>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem/If Action Subsystem'
 * '<S48>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem/If Action Subsystem1'
 * '<S49>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem1/If Action Subsystem'
 * '<S50>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem1/If Action Subsystem1'
 * '<S51>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem2/If Action Subsystem'
 * '<S52>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/Subsystem2/If Action Subsystem1'
 * '<S53>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty/Duty0Pct'
 * '<S54>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty/Duty5Pct'
 * '<S55>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty1/Duty0Pct'
 * '<S56>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty1/Duty5Pct'
 * '<S57>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty2/Duty0Pct'
 * '<S58>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/pwm_generation/min_duty2/Duty5Pct'
 * '<S59>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole/Saturation Dynamic1'
 * '<S60>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole/Vpeak'
 * '<S61>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/CONTROL/vloop_pi_pole/Vpeak/200V'
 * '<S62>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true'
 * '<S63>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true1'
 * '<S64>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true2'
 * '<S65>'  : 'npc_controller/CONTROL/CONTROL/false/CLA_CONTROL/INIT//RESET_CONTROL/true3'
 * '<S66>'  : 'npc_controller/CONTROL/GET_ADC/ADC'
 * '<S67>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen'
 * '<S68>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA'
 * '<S69>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC'
 * '<S70>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem'
 * '<S71>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem1'
 * '<S72>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem2'
 * '<S73>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem3'
 * '<S74>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem4'
 * '<S75>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem5'
 * '<S76>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem6'
 * '<S77>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem7'
 * '<S78>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem8'
 * '<S79>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem10'
 * '<S80>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem11'
 * '<S81>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem18'
 * '<S82>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6'
 * '<S83>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7'
 * '<S84>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8'
 * '<S85>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem9'
 * '<S86>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem1'
 * '<S87>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem2'
 * '<S88>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem1/If Action Subsystem'
 * '<S89>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem6/If Action Subsystem2/If Action Subsystem'
 * '<S90>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem1'
 * '<S91>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem2'
 * '<S92>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem1/If Action Subsystem'
 * '<S93>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem7/If Action Subsystem2/If Action Subsystem'
 * '<S94>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem1'
 * '<S95>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem2'
 * '<S96>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem1/If Action Subsystem'
 * '<S97>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCA/Subsystem8/If Action Subsystem2/If Action Subsystem'
 * '<S98>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem12'
 * '<S99>'  : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem13'
 * '<S100>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem14'
 * '<S101>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem15'
 * '<S102>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/ADCC/Subsystem16'
 * '<S103>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem/IIR Filter1'
 * '<S104>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem1/IIR Filter1'
 * '<S105>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem2/IIR Filter1'
 * '<S106>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem3/IIR Filter1'
 * '<S107>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem4/IIR Filter1'
 * '<S108>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem5/IIR Filter1'
 * '<S109>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem6/IIR Filter1'
 * '<S110>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem7/IIR Filter1'
 * '<S111>' : 'npc_controller/CONTROL/GET_ADC/ADC/codegen/Subsystem8/IIR Filter1'
 * '<S112>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2'
 * '<S113>' : 'npc_controller/CONTROL/STATE-MACHINE/Update_PFC_EN'
 * '<S114>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/configFutDis'
 * '<S115>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/configFutEn'
 * '<S116>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp'
 * '<S117>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhA'
 * '<S118>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhB'
 * '<S119>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhC'
 * '<S120>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/disablePwm'
 * '<S121>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/readCmpssOcp'
 * '<S122>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib'
 * '<S123>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst'
 * '<S124>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst'
 * '<S125>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst'
 * '<S126>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/OVP'
 * '<S127>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectUvpOvp/UVP'
 * '<S128>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhA/false'
 * '<S129>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhA/true'
 * '<S130>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhB/false'
 * '<S131>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhB/true'
 * '<S132>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhC/false'
 * '<S133>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/detectZCPhC/true'
 * '<S134>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt'
 * '<S135>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/done'
 * '<S136>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt/Subsystem1'
 * '<S137>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt/Subsystem2'
 * '<S138>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt/Subsystem3'
 * '<S139>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt/Subsystem4'
 * '<S140>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt/Subsystem5'
 * '<S141>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/cnt/Subsystem6'
 * '<S142>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/done/AUTO-CALIB_DONE'
 * '<S143>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/done/CLEAR_FAULTS'
 * '<S144>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateCalib/done/RESET_TZ'
 * '<S145>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1'
 * '<S146>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/Chart2'
 * '<S147>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/neg'
 * '<S148>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/pos'
 * '<S149>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/zero'
 * '<S150>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/zero_crossing_a'
 * '<S151>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/neg/SR OFF'
 * '<S152>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/neg/SR ON'
 * '<S153>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/pos/SR Force to Low'
 * '<S154>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/pos/SR ON'
 * '<S155>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/Detect Rise Positive'
 * '<S156>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/false'
 * '<S157>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/true'
 * '<S158>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhA_burst/pol_vxn1/zero_crossing_a/Detect Rise Positive/Positive'
 * '<S159>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1'
 * '<S160>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/Chart2'
 * '<S161>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/neg'
 * '<S162>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/pos'
 * '<S163>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/zero'
 * '<S164>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/zero_crossing_a'
 * '<S165>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/neg/SR OFF'
 * '<S166>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/neg/SR ON'
 * '<S167>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/pos/SR Force to Low'
 * '<S168>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/pos/SR ON'
 * '<S169>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/zero_crossing_a/Detect Rise Positive'
 * '<S170>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/zero_crossing_a/false'
 * '<S171>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/zero_crossing_a/true'
 * '<S172>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhB_burst/pol_vxn1/zero_crossing_a/Detect Rise Positive/Positive'
 * '<S173>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1'
 * '<S174>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/Chart2'
 * '<S175>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/neg'
 * '<S176>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/pos'
 * '<S177>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/zero'
 * '<S178>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/zero_crossing_a1'
 * '<S179>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/neg/SR OFF'
 * '<S180>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/neg/SR ON'
 * '<S181>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/pos/SR Force to Low'
 * '<S182>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/pos/SR ON'
 * '<S183>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/zero_crossing_a1/Detect Rise Positive'
 * '<S184>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/zero_crossing_a1/false'
 * '<S185>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/zero_crossing_a1/true'
 * '<S186>' : 'npc_controller/CONTROL/STATE-MACHINE/CPU_CONTROL_750_A2_precharge_pfc_ok2_OL SS2/updateSequencePhC_burst/pol_vxn1/zero_crossing_a1/Detect Rise Positive/Positive'
 * '<S187>' : 'npc_controller/IDLE_AND_TIMER/codegen'
 * '<S188>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task'
 * '<S189>' : 'npc_controller/IDLE_AND_TIMER/codegen/Chart1'
 * '<S190>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE'
 * '<S191>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION'
 * '<S192>' : 'npc_controller/IDLE_AND_TIMER/codegen/TIMER_1MS'
 * '<S193>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler'
 * '<S194>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler'
 * '<S195>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10'
 * '<S196>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB11'
 * '<S197>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12'
 * '<S198>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/All Legs'
 * '<S199>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Bit Shift'
 * '<S200>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Leg A'
 * '<S201>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Leg B'
 * '<S202>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Leg C'
 * '<S203>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Mode_Cmd'
 * '<S204>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Phase Type 1 Phase'
 * '<S205>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Phase Type 3 Phase'
 * '<S206>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ ProcessMB10/Bit Shift/bit_shift'
 * '<S207>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB11/Red_Mode_Cmd'
 * '<S208>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd'
 * '<S209>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Read'
 * '<S210>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Write'
 * '<S211>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/Debug En//Dis'
 * '<S212>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/FUT En Dis'
 * '<S213>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/Debug En//Dis/Debug_Dis'
 * '<S214>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/Debug En//Dis/Debug_En'
 * '<S215>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/FUT En Dis/Disable FUT'
 * '<S216>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Cmd/FUT En Dis/Enable FUT'
 * '<S217>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Rx_Handler/ProcessMB12/Debug_Read/Debug_Cmd'
 * '<S218>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Increment Stored Integer'
 * '<S219>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine'
 * '<S220>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest'
 * '<S221>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData'
 * '<S222>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/ Tx FW Rev ID134'
 * '<S223>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx Cal Data ID135'
 * '<S224>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136'
 * '<S225>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137'
 * '<S226>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes'
 * '<S227>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes1'
 * '<S228>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes2'
 * '<S229>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes/Bit Shift'
 * '<S230>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S231>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes1/Bit Shift'
 * '<S232>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes1/Bit Shift/bit_shift'
 * '<S233>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes2/Bit Shift'
 * '<S234>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat1 136/u16 Data to Bytes2/Bit Shift/bit_shift'
 * '<S235>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes'
 * '<S236>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes1'
 * '<S237>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes2'
 * '<S238>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes/Bit Shift'
 * '<S239>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S240>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes1/Bit Shift'
 * '<S241>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes1/Bit Shift/bit_shift'
 * '<S242>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes2/Bit Shift'
 * '<S243>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxReadRequest/Tx TxDeb Dat2 137/u16 Data to Bytes2/Bit Shift/bit_shift'
 * '<S244>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110'
 * '<S245>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130'
 * '<S246>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131'
 * '<S247>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132'
 * '<S248>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri4 ID133'
 * '<S249>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes'
 * '<S250>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes1'
 * '<S251>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes2'
 * '<S252>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/TxReadRequest'
 * '<S253>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/u16 Data to Bytes'
 * '<S254>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes/Bit Shift'
 * '<S255>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes/Bit Shift/bit_shift'
 * '<S256>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes1/Bit Shift'
 * '<S257>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes1/Bit Shift/bit_shift'
 * '<S258>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes2/Bit Shift'
 * '<S259>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S260>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/u16 Data to Bytes/Bit Shift'
 * '<S261>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri Status ID110/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S262>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/Float Data to Bytes2'
 * '<S263>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes'
 * '<S264>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes1'
 * '<S265>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/Float Data to Bytes2/Bit Shift'
 * '<S266>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S267>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes/Bit Shift'
 * '<S268>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes/Bit Shift/bit_shift'
 * '<S269>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes1/Bit Shift'
 * '<S270>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri1 ID130/u16 Data to Bytes1/Bit Shift/bit_shift'
 * '<S271>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes'
 * '<S272>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes1'
 * '<S273>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes2'
 * '<S274>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes3'
 * '<S275>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes/Bit Shift'
 * '<S276>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes/Bit Shift/bit_shift'
 * '<S277>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes1/Bit Shift'
 * '<S278>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes1/Bit Shift/bit_shift'
 * '<S279>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes2/Bit Shift'
 * '<S280>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S281>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes3/Bit Shift'
 * '<S282>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri2 ID131/Float Data to Bytes3/Bit Shift/bit_shift'
 * '<S283>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes'
 * '<S284>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes1'
 * '<S285>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes2'
 * '<S286>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes3'
 * '<S287>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes/Bit Shift'
 * '<S288>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes/Bit Shift/bit_shift'
 * '<S289>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes1/Bit Shift'
 * '<S290>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes1/Bit Shift/bit_shift'
 * '<S291>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes2/Bit Shift'
 * '<S292>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes2/Bit Shift/bit_shift'
 * '<S293>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes3/Bit Shift'
 * '<S294>' : 'npc_controller/IDLE_AND_TIMER/codegen/CAN_Task/Tx_Handler/Run Tx Routine/TxStatusData/Tx Pri3 ID132/Float Data to Bytes3/Bit Shift/bit_shift'
 * '<S295>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/cnt_idle'
 * '<S296>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task'
 * '<S297>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/cnt_idle/cnt_idle'
 * '<S298>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/cnt_idle/cnt_idle_sat'
 * '<S299>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise'
 * '<S300>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep'
 * '<S301>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc'
 * '<S302>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits'
 * '<S303>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/watchdog'
 * '<S304>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift'
 * '<S305>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift1'
 * '<S306>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift2'
 * '<S307>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift27'
 * '<S308>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift3'
 * '<S309>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift4'
 * '<S310>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift5'
 * '<S311>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift6'
 * '<S312>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift7'
 * '<S313>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift8'
 * '<S314>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift9'
 * '<S315>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift/bit_shift'
 * '<S316>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift1/bit_shift'
 * '<S317>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift2/bit_shift'
 * '<S318>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift27/bit_shift'
 * '<S319>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift3/bit_shift'
 * '<S320>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift4/bit_shift'
 * '<S321>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift5/bit_shift'
 * '<S322>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift6/bit_shift'
 * '<S323>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift7/bit_shift'
 * '<S324>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift8/bit_shift'
 * '<S325>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/fault_bitwise/Bit Shift9/bit_shift'
 * '<S326>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv'
 * '<S327>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tz'
 * '<S328>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1'
 * '<S329>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVa'
 * '<S330>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVaux'
 * '<S331>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVb'
 * '<S332>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVbulk'
 * '<S333>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVc'
 * '<S334>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/hkeep/tfv/hkeep1/HKEEP.tfvVmid'
 * '<S335>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/IIR (1s at 750Hz)'
 * '<S336>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/IIR (1s at 750Hz)1'
 * '<S337>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/IIR (1s at 750Hz)2'
 * '<S338>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/OTP'
 * '<S339>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem1'
 * '<S340>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem10'
 * '<S341>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem11'
 * '<S342>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem2'
 * '<S343>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem3'
 * '<S344>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem4'
 * '<S345>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem5'
 * '<S346>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem6'
 * '<S347>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem7'
 * '<S348>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem8'
 * '<S349>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_adc/Subsystem9'
 * '<S350>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift1'
 * '<S351>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift10'
 * '<S352>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift11'
 * '<S353>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift12'
 * '<S354>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift2'
 * '<S355>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift3'
 * '<S356>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift4'
 * '<S357>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift5'
 * '<S358>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift6'
 * '<S359>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift7'
 * '<S360>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift8'
 * '<S361>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift9'
 * '<S362>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift1/bit_shift'
 * '<S363>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift10/bit_shift'
 * '<S364>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift11/bit_shift'
 * '<S365>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift12/bit_shift'
 * '<S366>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift2/bit_shift'
 * '<S367>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift3/bit_shift'
 * '<S368>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift4/bit_shift'
 * '<S369>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift5/bit_shift'
 * '<S370>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift6/bit_shift'
 * '<S371>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift7/bit_shift'
 * '<S372>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift8/bit_shift'
 * '<S373>' : 'npc_controller/IDLE_AND_TIMER/codegen/IDLE/idle_task/report_status_flag_bits/Bit Shift9/bit_shift'
 * '<S374>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION/cmpss'
 * '<S375>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION/epwm'
 * '<S376>' : 'npc_controller/IDLE_AND_TIMER/codegen/INITIALIZATION/orps&relay'
 * '<S377>' : 'npc_controller/IDLE_AND_TIMER/codegen/TIMER_1MS/codegen'
 * '<S378>' : 'npc_controller/IDLE_AND_TIMER/codegen/TIMER_1MS/codegen/periodic_timer1'
 */
#endif                                 /* RTW_HEADER_npc_controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
