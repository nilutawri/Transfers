/*******************************************************************************
 * Filename              : ThermalModule.h
* Project               :
 * First Author          : vinoth kumar
 * First Created on      : 28 Apr 2023
 *
 * Description           : 
 *
 * Last modification:-
 *      on Date          :
 *      by Author        : 
 *      File Revision    : V1.0
 *
 * Compiler info         :
 * Processor info        :
 *
 * Copyright (c) 2023  EVPS, Liteon Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#ifndef _ThermalModule_H
#define _ThermalModule_H

#include <stdint.h>

/*******************************************************************************
 * Global constants and macros (public to other modules)
 ******************************************************************************/
#define TEMP_REPORTING_OFFSET_NOT_ZERO      0       /* If it Set to Zero then NO offset is Set and reported value will be in Signed integer */

#ifdef TEMP_REPORTING_OFFSET_NOT_ZERO
    #define TEMP_REPORTING_OFFSET_VALUE     0       /*  Define OFFSET  if Integer Value Offset other than 60 in 0.25'C resolution*/
#endif

#define TEMP_REPORTING_RESOLUTION_1_DEG     1       /* 0 = 0.25'C (Default) , 1 = 1'C */

/*******************************************************************************
 * Global data / Variable types (public typedefs / structs / enums)
 ******************************************************************************/


/*******************************************************************************
 * Global Variables (public to other modules)
 ******************************************************************************/


/*******************************************************************************
 * Global function prototypes (public to other modules)
 ******************************************************************************/
int16_t GetTemperatureTMP6131Q(uint16_t u16AdcInput);


#endif /* _ThermalModule_H */


/*
 * End of file
 */
